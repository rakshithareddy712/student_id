"""Persistence layer.

Responsibilities
----------------
* Load/save the canonical JSON store atomically (write-temp-then-rename).
* Mirror to CSV for spreadsheet users.
* Recover gracefully from: missing file, empty file, invalid JSON,
  wrong top-level type, partially corrupt rows, unreadable permissions.
* Keep timestamped backups before destructive operations.
* Append a plain-text audit log of every mutation.
"""

from __future__ import annotations

import csv
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Iterable, Sequence

from . import config
from .models import Student

CSV_FIELDS = [
    "roll_no", "name", "grade", "section", "email", "phone",
    "attendance", "gpa", "fee_status", "fee_due_date", "status",
    "enrolled_on", "notes", "updated_at",
]


class StorageError(Exception):
    """Raised only for unrecoverable I/O problems (e.g. disk full)."""


# --------------------------------------------------------------------------
# Audit log
# --------------------------------------------------------------------------
def audit(action: str, detail: str = "") -> None:
    """Append a timestamped line to the plain-text audit log. Never raises."""
    try:
        config.AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().isoformat(timespec="seconds")
        with open(config.AUDIT_LOG, "a", encoding="utf-8") as fh:
            fh.write(f"{stamp}\t{action}\t{detail}\n")
    except OSError:
        pass  # logging must never break the app


# --------------------------------------------------------------------------
# Atomic write helper
# --------------------------------------------------------------------------
def _atomic_write(path: Path, text: str) -> None:
    """Write text to `path` via a temp file + os.replace (atomic on POSIX)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=path.suffix)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def backup(path: Path) -> Path | None:
    """Copy an existing file into data/backups/ with a timestamp. Returns the copy."""
    if not path.exists():
        return None
    try:
        config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = config.BACKUP_DIR / f"{path.stem}_{stamp}{path.suffix}"
        shutil.copy2(path, dest)
        return dest
    except OSError:
        return None


# --------------------------------------------------------------------------
# JSON load / save
# --------------------------------------------------------------------------
def load_students(path: Path | None = None) -> tuple[list[Student], list[str]]:
    """Load records from JSON.

    Returns (students, notices). `notices` describes any recovery that
    happened, so the UI can tell the user what it did.
    """
    path = path or config.JSON_PATH
    notices: list[str] = []

    if not path.exists():
        notices.append(f"No data file found at {path.name}; starting with an empty roster.")
        save_students([], path=path, write_csv=False)
        return [], notices

    try:
        raw_text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        notices.append(f"Could not read {path.name} ({exc.__class__.__name__}); starting empty.")
        backup(path)
        save_students([], path=path, write_csv=False)
        return [], notices

    if not raw_text.strip():
        notices.append(f"{path.name} was empty; initialised a clean roster.")
        save_students([], path=path, write_csv=False)
        return [], notices

    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        notices.append(
            f"{path.name} contained invalid JSON (line {exc.lineno}); "
            f"backed it up and started a clean roster."
        )
        backup(path)
        save_students([], path=path, write_csv=False)
        return [], notices

    # Accept either a bare list or {"students": [...]}
    if isinstance(payload, dict):
        payload = payload.get("students", payload.get("records", []))
    if not isinstance(payload, list):
        notices.append(f"{path.name} had an unexpected structure; started a clean roster.")
        backup(path)
        save_students([], path=path, write_csv=False)
        return [], notices

    students: list[Student] = []
    skipped = 0
    seen: set[str] = set()
    for item in payload:
        if not isinstance(item, dict):
            skipped += 1
            continue
        try:
            student = Student.from_dict(item)
        except Exception:
            skipped += 1
            continue
        if student.roll_no in seen:
            skipped += 1
            continue
        seen.add(student.roll_no)
        students.append(student)

    if skipped:
        notices.append(f"Skipped {skipped} malformed or duplicate row(s) while loading.")
    return students, notices


def save_students(students: Sequence[Student], *, path: Path | None = None,
                  write_csv: bool = True) -> None:
    """Persist records to JSON (and optionally CSV). Raises StorageError on failure."""
    path = path or config.JSON_PATH
    payload = {
        "meta": {
            "app": config.APP_NAME,
            "project": config.PROJECT_NAME,
            "version": config.VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "count": len(students),
        },
        "students": [s.to_dict() for s in students],
    }
    try:
        _atomic_write(path, json.dumps(payload, indent=2, ensure_ascii=False))
    except OSError as exc:
        raise StorageError(f"Could not write {path.name}: {exc}") from exc

    if write_csv:
        try:
            save_csv(students)
        except OSError:
            pass  # CSV mirror is best-effort


# --------------------------------------------------------------------------
# CSV
# --------------------------------------------------------------------------
def save_csv(students: Sequence[Student], path: Path | None = None) -> None:
    path = path or config.CSV_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=".csv")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS, extrasaction="ignore")
            writer.writeheader()
            for s in students:
                writer.writerow(s.to_dict())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def load_csv(path: Path) -> tuple[list[Student], list[dict]]:
    """Import a legacy CSV. Returns (students, row_errors).

    Each error dict: {"row": n, "reason": str, "raw": dict}
    """
    students: list[Student] = []
    errors: list[dict] = []
    if not path.exists():
        return [], [{"row": 0, "reason": f"File not found: {path}", "raw": {}}]

    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            if not reader.fieldnames:
                return [], [{"row": 0, "reason": "CSV has no header row.", "raw": {}}]
            missing = [f for f in ("roll_no", "name") if f not in reader.fieldnames]
            if missing:
                return [], [{
                    "row": 0,
                    "reason": f"Missing required column(s): {', '.join(missing)}",
                    "raw": {"columns": reader.fieldnames},
                }]

            seen: set[str] = set()
            for i, row in enumerate(reader, start=2):  # row 1 is the header
                try:
                    student = Student.from_dict(row)
                except Exception as exc:
                    errors.append({"row": i, "reason": f"Unparseable row: {exc}", "raw": row})
                    continue

                problems = _validate_import_row(student, row)
                if problems:
                    errors.append({"row": i, "reason": "; ".join(problems), "raw": row})
                    continue
                if student.roll_no in seen:
                    errors.append({"row": i, "reason": f"Duplicate roll_no {student.roll_no}", "raw": row})
                    continue
                seen.add(student.roll_no)
                students.append(student)
    except (OSError, UnicodeDecodeError, csv.Error) as exc:
        return [], [{"row": 0, "reason": f"Could not read CSV: {exc}", "raw": {}}]

    return students, errors


def _validate_import_row(student: Student, raw: dict) -> list[str]:
    """Strict checks applied only to imported rows (not to hand-edited JSON)."""
    problems: list[str] = []
    if not student.roll_no or student.roll_no == "UNKNOWN":
        problems.append("missing roll_no")
    if not student.name or student.name == "Unnamed":
        problems.append("missing name")
    for field_name in ("attendance", "gpa"):
        val = raw.get(field_name, "")
        if val not in (None, ""):
            try:
                float(val)
            except (TypeError, ValueError):
                problems.append(f"{field_name} not numeric ('{val}')")
    if student.fee_status not in config.VALID_FEE_STATUS:
        problems.append(f"invalid fee_status '{student.fee_status}'")
    if student.status not in config.VALID_STATUS:
        problems.append(f"invalid status '{student.status}'")
    return problems


# --------------------------------------------------------------------------
# Template creation
# --------------------------------------------------------------------------
def ensure_templates() -> list[str]:
    """Create clean initial files if any are missing. Returns notices."""
    notices: list[str] = []
    if not config.JSON_PATH.exists():
        save_students([], write_csv=False)
        notices.append("Created a fresh students.json template.")
    if not config.CSV_PATH.exists():
        save_csv([])
        notices.append("Created a fresh students.csv template.")
    return notices
