# Student ID Record Manager

**DataSpark Challenge Project #24 · Domain: Campus & Administration**

A zero-dependency, menu-driven terminal application for managing student records —
with defensive input validation, crash-proof JSON/CSV persistence, keyword and
category search, an executive summary engine, threshold warnings, multi-format
report export, and optional charts.

```
   ____        _        ____                  _
  |  _ \  __ _| |_ __ _/ ___| _ __   __ _ _ __| | __
  | | | |/ _` | __/ _` \___ \| '_ \ / _` | '__| |/ /
  | |_| | (_| | || (_| |___) | |_) | (_| | |  |   <
  |____/ \__,_|\__\__,_|____/| .__/ \__,_|_|  |_|\_\
                             |_|
```

---

## 1. Quick start

```bash
cd student-id-record-manager
python3 main.py
```

That's it. **No `pip install` required** — the entire application runs on the
Python 3.10+ standard library.

Optional, for PNG charts:

```bash
pip install matplotlib
```

Without matplotlib the app still works and falls back to ASCII bar charts.

### Regenerate the sample dataset

```bash
python3 tools/make_sample_data.py
```

### Run the test suite

```bash
python3 tests/test_all.py
```

Expected: `Tests run: 70  Failures: 0  Errors: 0`

---

## 2. Project layout

```
student-id-record-manager/
├── main.py                     # entry point
├── README.md
├── spark/                      # application package
│   ├── __init__.py
│   ├── config.py               # branding, paths, thresholds, ANSI palette
│   ├── ui.py                   # banner, boxes, fixed-width tables, pagination
│   ├── validation.py           # centralised input wrappers (never crash)
│   ├── models.py               # Student dataclass + derived properties
│   ├── storage.py              # atomic JSON/CSV I/O, corruption recovery, audit log
│   ├── repository.py           # business logic: CRUD, search, filter, aggregates
│   ├── analytics.py            # summary, trends, warning engine, anomalies
│   ├── exporters.py            # Markdown / plain-text / CSV reports
│   ├── charts.py               # matplotlib charts + ASCII fallback
│   └── app.py                  # menus, screens, guided workflows
├── data/
│   ├── students.json           # canonical store (40 sample records)
│   ├── students.csv            # CSV mirror / legacy import source
│   └── backups/                # timestamped backups of corrupt files
├── exports/                    # generated reports, charts, audit.log
├── tools/
│   └── make_sample_data.py     # sample dataset generator
└── tests/
    └── test_all.py             # 70 unit + end-to-end tests
```

---

## 3. Feature list

### 3.1 Interactive terminal interface
- Branded ASCII welcome screen with project name, code, domain and version.
- 12-option main menu with inline descriptions and a live record counter.
- Guided multi-step workflows ("Step 1 of 3 · Identity", etc.).
- ANSI colour throughout, **automatically disabled** when output is piped or
  `NO_COLOR` is set — so logs and CI output stay clean.
- `q` at any prompt cancels the current operation safely.

### 3.2 Defensive input validation
Every prompt goes through a centralised wrapper in `validation.py`:

| Wrapper | Guarantees |
|---|---|
| `ask_text` | non-blank, length-bounded, must contain a letter/digit |
| `ask_int` | whole number, range-checked, re-prompts on `abc`/blank |
| `ask_float` | finite number, range-checked, rejects `nan`/`inf`, rounds |
| `ask_choice` | accepts the name **or** a 1-based index |
| `ask_date` | accepts `YYYY-MM-DD`, `DD-MM-YYYY`, `DD/MM/YYYY`, `YYYY/MM/DD` |
| `ask_roll` | 3–12 chars, alphanumeric + `-`/`_`, normalised to upper case |
| `ask_email` | optional, RFC-ish pattern check |
| `ask_yes_no` | `y/n/yes/no/1/0/true/false` |

All input is **sanitised first**: control characters stripped, Unicode NFKC
normalised, whitespace collapsed, length truncated. `EOFError` and
`KeyboardInterrupt` are caught and converted to a clean cancel — the app never
traces back to the user.

### 3.3 Core business logic engine
- `Student` dataclass with 14 fields and derived properties:
  `attendance_band`, `academic_band`, `fee_overdue_days`, `is_fee_overdue`,
  `warnings`, `risk_score` (0–100 composite).
- `Repository` owns the roster and is the only place that mutates it.
- Duplicate roll numbers rejected (`DuplicateRollError`); missing records raise
  `NotFoundError` with a friendly message.

### 3.4 Local data persistence
- **Atomic writes**: temp file + `os.fsync` + `os.replace` — a crash mid-write
  can never leave a half-written JSON file.
- **Corruption recovery** for every failure mode:

| Failure | Behaviour |
|---|---|
| File missing | creates a clean template, tells the user |
| File empty | re-initialises, tells the user |
| Invalid JSON | **backs up** the corrupt file, starts clean |
| Wrong top-level type | backs up, starts clean |
| Bad rows inside a valid file | skips them, reports the count |
| Duplicate roll numbers in file | keeps the first, skips the rest |
| Unreadable / bad encoding | backs up, starts clean |

- CSV mirror written on every save (best-effort — a CSV failure never blocks
  the JSON save).
- Plain-text **audit log** (`exports/audit.log`) records every ADD / UPDATE /
  DELETE / BULK_IMPORT / EXPORT with a timestamp.

### 3.5 Record query & search
- **Keyword search** across roll, name, grade, section, email, notes, status
  and fee status.
- **Category filtering** by grade, section, status, fee status, attendance
  range, GPA range, and "has warnings".
- Paginated results with `n` / `p` / `f` / `l` / page-number navigation.

### 3.6 Executive summary generation
- Composite **health score** (0–100) from attendance, academics and fee hygiene.
- Totals, averages, medians, min/max and standard deviation for attendance and GPA.
- Attendance bands, GPA bands, fee status and grade distribution tables.
- Top performers and at-risk lists.
- Natural-language **key trends** (spread, concentration, outliers, fee follow-up).
- All tables use **fixed column widths** with box-drawing separators; ANSI codes
  are measured by *visible* length so colour never breaks alignment.
- **Pagination** for large result sets (10 rows/page in the roster, 15 in the
  warning register).

### 3.7 Stretch features
- **Multi-format export**: Markdown, plain text, and CSV — individually or all at once.
- **Threshold warnings**: critical / warning / info severity, plus statistical
  anomaly detection (z-score ≥ 2.5 on attendance and GPA).
- **Charts**: four matplotlib PNGs (attendance histogram, GPA histogram, grade
  bar, fee pie) with an ASCII fallback.
- **Bulk CSV import** with a detailed row-by-row error log (missing columns,
  non-numeric values, invalid enums, duplicates, unparseable rows).

---

## 4. Sample dataset

`data/students.json` and `data/students.csv` contain **40 records** covering:

| Category | Examples |
|---|---|
| Normal / healthy | 20 records across grades 6–12, attendance 78–98%, GPA 6.5–9.6 |
| Boundary values | attendance exactly **75.0** and **60.0**; GPA exactly **4.0** and **2.5** |
| Extremes | **0%** attendance / 0 GPA; **100%** attendance / 10 GPA |
| At-risk | chronic absenteeism, GPA 2.1, 60-day overdue fees |
| Status variety | Active, Inactive, Graduated, Suspended |
| Fee variety | Paid, Pending, Overdue, Waived |
| Edge conditions | missing email, 34-character name, Unicode name (`José Fernández`), blank notes |

---

## 5. Demo walkthrough

This matches the "What a Good Demo Looks Like" script.

### Step 1 — Launch

```bash
python3 main.py
```

You see the branded banner, then:

```
ℹ Loaded 40 record(s) from students.json.
ℹ Data directory: .../data
Press Enter to open the main menu…
```

### Step 2 — Add a record while validation catches bad input

Choose `1`. Enter `S2001`, `Ravi Kumar`, grade `10`, section `A`, email
`ravi@school.edu`, skip phone. Then deliberately type bad values:

```
▸ Attendance % (0-100) [100]: abc
✖ Attendance must be a number (got 'abc').
▸ Attendance % (0-100) [100]: 150
✖ Attendance must be between 0 and 100 (got 150).
▸ Attendance % (0-100) [100]: 88.5
▸ GPA (0-10) [0]: xyz
✖ GPA must be a number (got 'xyz').
▸ GPA (0-10) [0]: 7.5
...
✔ Saved S2001 · Ravi Kumar
ℹ Roster now holds 41 record(s).
```

The app never crashes — it re-prompts until the value is valid.

### Step 3 — Run analytics

Choose `8`. You get the roster health badge, then fixed-width tables for
overview, attendance, academics, bands, fees and grade distribution, followed by
key trends and top performers.

Choose `9` for the warning register:

```
  9 critical    13 warning    1 info
│ CRIT │ S1026 │ Zero Attendance │ Attendance │ 0.0% - below critical floor (60%) │
│ CRIT │ S1029 │ Manish Tiwari   │ Academics  │ GPA 2.10 - below critical floor   │
...
```

### Step 4 — Close and relaunch to prove persistence

Exit with `0`. Relaunch and choose `5`, then enter `S2001` — the record is
still there, with its attendance meter and GPA intact.

### Step 5 — Export a report or show a chart

Choose `10` → `4` (all formats):

```
✔ markdown  → summary_20261119_035033.md  (3,912 bytes)
✔ text      → summary_20261119_035033.txt  (3,385 bytes)
✔ csv       → roster_20261119_035033.csv  (5,961 bytes)
```

Choose `11` to render the ASCII charts and save four PNGs to `exports/`.

---

## 6. Fault-tolerance validation

The test suite (`tests/test_all.py`, 70 tests) covers:

- **Validation**: blank, non-numeric, out-of-range, `nan`, `inf`, garbage
  choices, bad dates, EOF, cancel tokens.
- **Storage**: missing file, empty file, invalid JSON, wrong top-level type,
  partially corrupt rows, duplicate rows, atomic-write cleanliness, CSV import
  with 4 distinct error classes.
- **Repository**: add/get/update/delete, duplicate rejection, not-found,
  persistence across reload, search, filter, bulk import.
- **Analytics**: empty dataset, exact averages, health-score bounds, warning
  severity ordering, anomaly detection.
- **Exporters**: all three formats produce non-empty, correctly-titled files.
- **UI**: ANSI-aware padding, table rendering, empty tables, pagination clamping.
- **App smoke tests**: a full scripted session that adds a record through bad
  input, rejects a duplicate roll, cancels cleanly, renders the summary, exports
  reports, and recovers from a corrupt JSON file at startup.

Manual fault-tolerance checks you can run:

```bash
# 1. Corrupt the data file and relaunch — it backs up and recovers
echo '{{{ broken' > data/students.json
python3 main.py        # warns "invalid JSON", starts clean, file is valid again

# 2. Delete the data file and relaunch — it creates a template
rm data/students.json
python3 main.py        # warns "No data file found", creates a clean roster

# 3. Pipe garbage into the menu — it re-prompts, never crashes
printf 'abc\n99\n-1\n0\n' | python3 main.py
```

---

## 7. Design notes

- **Separation of concerns**: `analytics.py` and `exporters.py` are pure
  functions over data — no printing, no I/O beyond the file they write. That is
  what makes them testable without a terminal.
- **ANSI-safe width maths**: `ui.visible_len()` strips escape sequences before
  measuring, so coloured cells align perfectly with plain ones.
- **Colour is opt-out**: piping to a file or setting `NO_COLOR=1` produces clean
  plain text, which is why the demo transcripts above are readable.
- **Fail soft, never silent**: every recovery path tells the user what happened
  and what it did about it.

---

## 8. Requirements

- Python **3.10+** (uses `X | Y` type unions and `dataclasses`)
- Standard library only
- Optional: `matplotlib` for PNG charts

---

*Built for DataSpark Challenge Project #24 — Campus & Administration.*
