"""Domain model: the Student record and its derived properties."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, datetime
from typing import Any

from . import config


@dataclass
class Student:
    """A single student record.

    `roll_no` is the primary key. All numeric fields are range-checked at
    construction time by the validation layer, but `from_dict` is defensive
    because it may be reading a hand-edited or legacy file.
    """

    roll_no: str
    name: str
    grade: str = "10"
    section: str = "A"
    email: str = ""
    phone: str = ""
    attendance: float = 100.0          # percentage 0-100
    gpa: float = 0.0                   # 0-10 scale
    fee_status: str = "Paid"
    fee_due_date: str = ""             # ISO date, optional
    status: str = "Active"
    enrolled_on: str = field(default_factory=lambda: date.today().isoformat())
    notes: str = ""
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    # ------------------------------------------------------------------
    # Derived / computed properties
    # ------------------------------------------------------------------
    @property
    def attendance_band(self) -> str:
        if self.attendance < config.CRITICAL_ATTENDANCE:
            return "critical"
        if self.attendance < config.MIN_ATTENDANCE:
            return "low"
        if self.attendance >= 90:
            return "high"
        return "ok"

    @property
    def academic_band(self) -> str:
        if self.gpa < config.CRITICAL_GPA:
            return "critical"
        if self.gpa < config.MIN_GPA:
            return "risk"
        if self.gpa >= 8.5:
            return "excellent"
        return "ok"

    @property
    def fee_overdue_days(self) -> int:
        """Days past the fee due date (0 if not overdue or no date)."""
        if self.fee_status in ("Paid", "Waived") or not self.fee_due_date:
            return 0
        try:
            due = date.fromisoformat(self.fee_due_date)
        except (ValueError, TypeError):
            return 0
        delta = (date.today() - due).days
        return max(0, delta)

    @property
    def is_fee_overdue(self) -> bool:
        return self.fee_overdue_days > config.FEE_OVERDUE_GRACE_DAYS

    @property
    def warnings(self) -> list[str]:
        """Human-readable warning flags for this record."""
        flags: list[str] = []
        if self.attendance < config.CRITICAL_ATTENDANCE:
            flags.append(f"CRITICAL attendance {self.attendance:.1f}%")
        elif self.attendance < config.MIN_ATTENDANCE:
            flags.append(f"Low attendance {self.attendance:.1f}%")
        if self.gpa < config.CRITICAL_GPA:
            flags.append(f"CRITICAL GPA {self.gpa:.2f}")
        elif self.gpa < config.MIN_GPA:
            flags.append(f"Academic risk GPA {self.gpa:.2f}")
        if self.is_fee_overdue:
            flags.append(f"Fee overdue {self.fee_overdue_days}d")
        if self.status == "Suspended":
            flags.append("Suspended")
        return flags

    @property
    def risk_score(self) -> int:
        """0-100 composite risk score (higher = more at risk)."""
        score = 0.0
        score += max(0.0, (config.MIN_ATTENDANCE - self.attendance)) * 1.2
        score += max(0.0, (config.MIN_GPA - self.gpa)) * 8.0
        if self.is_fee_overdue:
            score += min(20.0, 5.0 + self.fee_overdue_days * 0.5)
        if self.status == "Suspended":
            score += 25.0
        return int(min(100, round(score)))

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Student":
        """Build a Student from a dict, coercing and clamping bad values.

        Never raises: a corrupt row becomes a best-effort record so one bad
        line cannot take down the whole dataset.
        """
        def _s(key: str, default: str = "") -> str:
            v = raw.get(key, default)
            return "" if v is None else str(v).strip()

        def _f(key: str, default: float, lo: float, hi: float) -> float:
            try:
                v = float(raw.get(key, default))
            except (TypeError, ValueError):
                return default
            if v != v:  # NaN
                return default
            return max(lo, min(hi, v))

        roll = _s("roll_no") or _s("roll") or _s("rollno") or "UNKNOWN"
        return cls(
            roll_no=roll.upper(),
            name=_s("name") or "Unnamed",
            grade=_s("grade", "10") or "10",
            section=_s("section", "A") or "A",
            email=_s("email"),
            phone=_s("phone"),
            attendance=_f("attendance", 100.0, 0.0, 100.0),
            gpa=_f("gpa", 0.0, 0.0, config.MAX_GPA),
            fee_status=_s("fee_status", "Paid") or "Paid",
            fee_due_date=_s("fee_due_date"),
            status=_s("status", "Active") or "Active",
            enrolled_on=_s("enrolled_on") or date.today().isoformat(),
            notes=_s("notes"),
            updated_at=_s("updated_at") or datetime.now().isoformat(timespec="seconds"),
        )

    def touch(self) -> None:
        self.updated_at = datetime.now().isoformat(timespec="seconds")
