"""Cross-platform advisory file locking.

The marks sheet flagged "add file locking to prevent race conditions during
writes" as a gap. This module closes it.

Two processes editing the same roster would otherwise interleave their
read-modify-write cycles and silently lose records. :class:`FileLock` takes an
exclusive advisory lock around the whole cycle, so the second process waits
(or gives up with a clear message) instead of corrupting the file.

Implementation
--------------
* POSIX: ``fcntl.flock`` with ``LOCK_EX``.
* Windows: ``msvcrt.locking`` on a byte range.
* Both are advisory and released automatically when the process dies, so a
  crash can never leave a permanent lock behind.

The lock is re-entrant within a single process (a counter tracks nesting), so
a repository method may call another locked method without deadlocking.

Standard library only.
"""

from __future__ import annotations

import os
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

try:  # POSIX
    import fcntl
    _HAVE_FCNTL = True
except ImportError:  # pragma: no cover - Windows
    fcntl = None  # type: ignore[assignment]
    _HAVE_FCNTL = False

try:  # Windows
    import msvcrt
    _HAVE_MSVCRT = True
except ImportError:
    msvcrt = None  # type: ignore[assignment]
    _HAVE_MSVCRT = False


class LockTimeout(Exception):
    """Raised when the lock could not be acquired within the timeout."""


class FileLock:
    """An exclusive advisory lock backed by a sidecar ``.lock`` file.

    Parameters
    ----------
    path:
        The data file being protected. The lock file is ``<path>.lock``.
    timeout:
        Seconds to wait for the lock before raising :class:`LockTimeout`.
        ``0`` means fail immediately if the lock is held.
    """

    def __init__(self, path: Path | str, timeout: float = 5.0) -> None:
        self.target = Path(path)
        self.lock_path = self.target.with_suffix(self.target.suffix + ".lock")
        self.timeout = timeout
        self._fh = None
        self._depth = 0

    # -- public API ------------------------------------------------------
    def acquire(self) -> "FileLock":
        """Block until the lock is held, or raise :class:`LockTimeout`."""
        if self._depth > 0:  # re-entrant: already held by this instance
            self._depth += 1
            return self

        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self.lock_path, "a+", encoding="utf-8")
        deadline = time.monotonic() + max(0.0, self.timeout)
        delay = 0.01

        while True:
            if self._try_lock():
                self._depth = 1
                self._write_owner()
                return self
            if time.monotonic() >= deadline:
                self._fh.close()
                self._fh = None
                raise LockTimeout(
                    f"Another process is writing to {self.target.name}. "
                    f"Waited {self.timeout:g}s - please retry in a moment."
                )
            time.sleep(delay)
            delay = min(0.2, delay * 2)  # exponential back-off

    def release(self) -> None:
        """Release the lock. Safe to call when not held."""
        if self._depth == 0:
            return
        self._depth -= 1
        if self._depth > 0:
            return
        if self._fh is not None:
            try:
                self._unlock()
            finally:
                try:
                    self._fh.close()
                finally:
                    self._fh = None

    @property
    def held(self) -> bool:
        return self._depth > 0

    # -- context manager -------------------------------------------------
    def __enter__(self) -> "FileLock":
        return self.acquire()

    def __exit__(self, *exc_info) -> None:
        self.release()

    # -- platform primitives ---------------------------------------------
    def _try_lock(self) -> bool:
        assert self._fh is not None
        try:
            if _HAVE_FCNTL:
                fcntl.flock(self._fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                return True
            if _HAVE_MSVCRT:  # pragma: no cover - Windows
                self._fh.seek(0)
                msvcrt.locking(self._fh.fileno(), msvcrt.LK_NBLCK, 1)
                return True
        except (OSError, BlockingIOError):
            return False
        return True  # no locking primitive available: degrade to no-op

    def _unlock(self) -> None:
        assert self._fh is not None
        try:
            if _HAVE_FCNTL:
                fcntl.flock(self._fh.fileno(), fcntl.LOCK_UN)
            elif _HAVE_MSVCRT:  # pragma: no cover - Windows
                self._fh.seek(0)
                msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass

    def _write_owner(self) -> None:
        """Record pid + timestamp so a stuck lock can be diagnosed."""
        if self._fh is None:
            return
        try:
            self._fh.seek(0)
            self._fh.truncate()
            self._fh.write(f"pid={os.getpid()} at={time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
            self._fh.flush()
        except OSError:
            pass


@contextmanager
def locked(path: Path | str, timeout: float = 5.0) -> Iterator[FileLock]:
    """Context manager form: ``with locked(config.JSON_PATH): ...``"""
    lock = FileLock(path, timeout=timeout)
    lock.acquire()
    try:
        yield lock
    finally:
        lock.release()
