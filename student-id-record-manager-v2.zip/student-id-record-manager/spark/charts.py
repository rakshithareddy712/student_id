"""Optional charting.

Uses matplotlib when it is installed; otherwise falls back to a pure-ASCII
bar chart so the feature never hard-fails on a zero-dependency machine.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Sequence

from . import config
from .models import Student

try:  # optional dependency
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:  # pragma: no cover - environment dependent
    HAS_MPL = False


def ascii_bar_chart(title: str, counts: Counter, width: int = 40) -> str:
    """Render a horizontal ASCII bar chart. Always available."""
    if not counts:
        return f"{title}\n  (no data)"
    peak = max(counts.values()) or 1
    label_w = max(len(str(k)) for k in counts)
    lines = [title, "─" * min(70, width + label_w + 12)]
    for key in sorted(counts, key=lambda k: (-counts[k], str(k))):
        n = counts[key]
        bar = "█" * max(1, int(round(n / peak * width)))
        lines.append(f"  {str(key):<{label_w}} │ {bar} {n}")
    return "\n".join(lines)


def _save(fig, name: str) -> Path:
    config.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    path = config.EXPORT_DIR / name
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


def attendance_histogram(students: Sequence[Student]) -> Path | None:
    if not HAS_MPL or not students:
        return None
    values = [s.attendance for s in students]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.hist(values, bins=10, range=(0, 100), color="#2E86AB", edgecolor="white")
    ax.axvline(config.MIN_ATTENDANCE, color="#E4572E", linestyle="--", linewidth=1.5,
               label=f"Minimum ({config.MIN_ATTENDANCE:.0f}%)")
    ax.set_title("Attendance distribution")
    ax.set_xlabel("Attendance (%)")
    ax.set_ylabel("Students")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    return _save(fig, "chart_attendance.png")


def gpa_histogram(students: Sequence[Student]) -> Path | None:
    if not HAS_MPL or not students:
        return None
    values = [s.gpa for s in students]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.hist(values, bins=10, range=(0, config.MAX_GPA), color="#6A4C93", edgecolor="white")
    ax.axvline(config.MIN_GPA, color="#E4572E", linestyle="--", linewidth=1.5,
               label=f"Minimum ({config.MIN_GPA:g})")
    ax.set_title("GPA distribution")
    ax.set_xlabel(f"GPA (0-{config.MAX_GPA:g})")
    ax.set_ylabel("Students")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    return _save(fig, "chart_gpa.png")


def grade_bar(students: Sequence[Student]) -> Path | None:
    if not HAS_MPL or not students:
        return None
    counts = Counter(s.grade for s in students)
    grades = sorted(counts, key=lambda g: (len(g), g))
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar([str(g) for g in grades], [counts[g] for g in grades], color="#3D9970")
    ax.set_title("Students per grade")
    ax.set_xlabel("Grade")
    ax.set_ylabel("Students")
    ax.grid(axis="y", alpha=0.25)
    return _save(fig, "chart_grades.png")


def fee_pie(students: Sequence[Student]) -> Path | None:
    if not HAS_MPL or not students:
        return None
    counts = Counter(s.fee_status for s in students)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.pie(list(counts.values()), labels=list(counts.keys()), autopct="%1.0f%%",
           colors=["#3D9970", "#FFB703", "#E4572E", "#8D99AE"])
    ax.set_title("Fee status")
    return _save(fig, "chart_fees.png")


def generate_all(students: Sequence[Student]) -> list[Path]:
    out = []
    for fn in (attendance_histogram, gpa_histogram, grade_bar, fee_pie):
        try:
            p = fn(students)
            if p:
                out.append(p)
        except Exception:
            continue
    return out
