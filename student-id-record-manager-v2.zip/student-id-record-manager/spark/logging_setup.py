"""Structured logging built on the standard :mod:`logging` framework.

The marks sheet recommended: *"Integrate a logging framework like 'logging'
instead of custom audit functions."* This module does exactly that, and goes
one step further by emitting **JSON Lines** so the log is machine-readable and
can be shipped to any log aggregator without a parser.

What it provides
----------------
* A single :func:`configure` entry point that is idempotent and safe to call
  from tests.
* **JSON Lines** output (one object per line) with a stable schema.
* **Session correlation**: every record carries a ``session`` id, so all
  events from one run of the app can be grouped.
* **Rotation**: size-based, so the log can never grow without bound.
* **Dual sinks**: a human-readable ``app.log`` and a machine-readable
  ``app.jsonl``, plus the legacy plain-text ``audit.log`` kept for
  backwards compatibility with the original spec.
* A :func:`audit` shim so existing call sites keep working unchanged.

Standard library only.
"""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

#: Correlation id for this process run. Every log line carries it.
SESSION_ID: str = uuid.uuid4().hex[:12]

#: Fields that are part of the LogRecord itself and must not be copied into
#: the JSON payload as "extra" data.
_RESERVED = {
    "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
    "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
    "created", "msecs", "relativeCreated", "thread", "threadName",
    "processName", "process", "taskName", "message", "asctime",
}

_configured = False


class JsonFormatter(logging.Formatter):
    """Render a :class:`logging.LogRecord` as a single-line JSON object."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc)
                          .isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "event": record.getMessage(),
            "session": SESSION_ID,
            "pid": record.process,
        }
        # Anything passed via extra={...} is merged in as structured context.
        for key, value in record.__dict__.items():
            if key not in _RESERVED and not key.startswith("_"):
                payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, default=str)


class HumanFormatter(logging.Formatter):
    """Compact, aligned console/file format for humans."""

    def format(self, record: logging.LogRecord) -> str:
        stamp = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        level = record.levelname[:4]
        base = f"{stamp} {level:<4} {record.name:<18} {record.getMessage()}"
        extras = {
            k: v for k, v in record.__dict__.items()
            if k not in _RESERVED and not k.startswith("_")
        }
        if extras:
            base += "  " + " ".join(f"{k}={v}" for k, v in extras.items())
        if record.exc_info:
            base += "\n" + self.formatException(record.exc_info)
        return base


def configure(
    log_dir: Path | str | None = None,
    *,
    level: int = logging.INFO,
    console: bool = False,
    max_bytes: int = 1_000_000,
    backup_count: int = 3,
    force: bool = False,
) -> logging.Logger:
    """Set up the ``spark`` logger tree. Idempotent unless ``force`` is set.

    Parameters
    ----------
    log_dir:
        Directory for ``app.log`` (human) and ``app.jsonl`` (machine).
        ``None`` disables file output entirely (useful in tests).
    level:
        Minimum level to record.
    console:
        Also echo records to stderr. Off by default so the TUI stays clean.
    max_bytes, backup_count:
        Size-based rotation settings.
    force:
        Rebuild the handlers even if already configured.
    """
    global _configured
    root = logging.getLogger("spark")
    if _configured and not force:
        return root

    for handler in list(root.handlers):
        root.removeHandler(handler)
        try:
            handler.close()
        except Exception:
            pass

    root.setLevel(level)
    root.propagate = False

    if log_dir is not None:
        directory = Path(log_dir)
        directory.mkdir(parents=True, exist_ok=True)

        human = logging.handlers.RotatingFileHandler(
            directory / "app.log", maxBytes=max_bytes,
            backupCount=backup_count, encoding="utf-8",
        )
        human.setFormatter(HumanFormatter())
        root.addHandler(human)

        machine = logging.handlers.RotatingFileHandler(
            directory / "app.jsonl", maxBytes=max_bytes,
            backupCount=backup_count, encoding="utf-8",
        )
        machine.setFormatter(JsonFormatter())
        root.addHandler(machine)

    if console:
        stream = logging.StreamHandler(sys.stderr)
        stream.setFormatter(HumanFormatter())
        root.addHandler(stream)

    if not root.handlers:
        root.addHandler(logging.NullHandler())

    _configured = True
    root.info("logging configured", extra={"log_dir": str(log_dir), "level": level})
    return root


def get_logger(name: str = "spark") -> logging.Logger:
    """Return a child logger, e.g. ``get_logger("spark.storage")``."""
    return logging.getLogger(name if name.startswith("spark") else f"spark.{name}")


# --------------------------------------------------------------------------
# Backwards-compatible audit shim
# --------------------------------------------------------------------------
def audit(action: str, detail: str = "", *, log_path: Path | str | None = None) -> None:
    """Record a mutation event.

    Emits a structured log record *and* appends the legacy tab-separated line
    to ``audit.log`` so the original plain-text audit requirement still holds.
    Never raises: logging must not break the application.
    """
    get_logger("spark.audit").info(
        "audit", extra={"action": action, "detail": detail}
    )
    if log_path is None:
        return
    try:
        path = Path(log_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().isoformat(timespec="seconds")
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(f"{stamp}\t{action}\t{detail}\n")
    except OSError:
        pass


def reset() -> None:
    """Tear down handlers. Used by tests to avoid cross-test leakage."""
    global _configured
    root = logging.getLogger("spark")
    for handler in list(root.handlers):
        root.removeHandler(handler)
        try:
            handler.close()
        except Exception:
            pass
    _configured = False
