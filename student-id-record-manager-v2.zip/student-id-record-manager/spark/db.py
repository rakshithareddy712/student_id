"""Indexed query layer (SQLite) that sits alongside the JSON/CSV store.

Why this module exists
----------------------
The JSON file remains the canonical, human-readable record store. But scanning
a JSON list linearly is O(n) per query, which does not scale. This module keeps
a *derived* SQLite index in sync with the JSON store so that lookups, filters
and keyword searches are served by B-tree indexes and an FTS5 full-text index
instead of a Python loop.

Design notes
------------
* **Derived, never authoritative.** The index can be deleted at any time and
  rebuilt from ``students.json`` with :meth:`StudentIndex.rebuild`. If SQLite
  is unavailable or the index file is corrupt, the repository silently falls
  back to linear scanning, so the application never loses functionality.
* **Indexes are declared explicitly** (see :data:`SCHEMA`) and their use is
  verifiable at runtime through :meth:`StudentIndex.explain`, which returns the
  real ``EXPLAIN QUERY PLAN`` output from SQLite.
* **FTS5 is optional.** Some Python builds ship SQLite without the FTS5
  extension. :meth:`StudentIndex._init_schema` detects this and degrades to
  ``LIKE``-based candidate generation.
* **Standard library only** - ``sqlite3`` is part of CPython.

Typical use::

    idx = StudentIndex(Path("data/students.db"))
    idx.sync(students)                 # full rebuild from the JSON store
    idx.upsert(student)                # incremental single-record update
    rows = idx.query(grade="10", min_attendance=75)
    hits = idx.search("alice")
"""

from __future__ import annotations

import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

from .models import Student

# --------------------------------------------------------------------------
# Schema
# --------------------------------------------------------------------------
#: Columns mirrored from :class:`spark.models.Student`, plus two derived
#: columns (``risk_score`` and ``warning_count``) that are expensive to
#: recompute in Python and are therefore materialised at write time.
COLUMNS: tuple[str, ...] = (
    "roll_no", "name", "grade", "section", "email", "phone",
    "attendance", "gpa", "fee_status", "fee_due_date", "status",
    "enrolled_on", "notes", "updated_at", "risk_score", "warning_count",
)

#: Every index is named and documented so the design is auditable.
INDEXES: tuple[tuple[str, str, str], ...] = (
    ("idx_students_grade", "students(grade)",
     "equality filter on grade"),
    ("idx_students_section", "students(section)",
     "equality filter on section"),
    ("idx_students_status", "students(status)",
     "equality filter on enrolment status"),
    ("idx_students_fee_status", "students(fee_status)",
     "equality filter on fee status"),
    ("idx_students_attendance", "students(attendance)",
     "range filter on attendance (min/max)"),
    ("idx_students_gpa", "students(gpa)",
     "range filter on GPA (min/max)"),
    ("idx_students_risk", "students(risk_score DESC)",
     "ordered retrieval of the warning register"),
    ("idx_students_name", "students(name COLLATE NOCASE)",
     "case-insensitive name ordering and prefix lookup"),
    ("idx_students_grade_section", "students(grade, section)",
     "composite index for the most common two-field filter"),
    ("idx_students_status_attendance", "students(status, attendance)",
     "composite index for 'active students below X% attendance'"),
)

SCHEMA: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS students (
        roll_no       TEXT PRIMARY KEY,
        name          TEXT NOT NULL,
        grade         TEXT,
        section       TEXT,
        email         TEXT,
        phone         TEXT,
        attendance    REAL,
        gpa           REAL,
        fee_status    TEXT,
        fee_due_date  TEXT,
        status        TEXT,
        enrolled_on   TEXT,
        notes         TEXT,
        updated_at    TEXT,
        risk_score    INTEGER DEFAULT 0,
        warning_count INTEGER DEFAULT 0
    )
    """,
    *(f"CREATE INDEX IF NOT EXISTS {name} ON {target}" for name, target, _ in INDEXES),
    """
    CREATE TABLE IF NOT EXISTS index_meta (
        key   TEXT PRIMARY KEY,
        value TEXT
    )
    """,
)

FTS_SCHEMA = """
CREATE VIRTUAL TABLE IF NOT EXISTS students_fts USING fts5(
    roll_no UNINDEXED,
    name,
    email,
    notes,
    grade,
    section,
    status,
    fee_status,
    tokenize = 'unicode61 remove_diacritics 2'
)
"""


class IndexError_(Exception):
    """Raised when the index cannot be opened or built."""


# --------------------------------------------------------------------------
# Index
# --------------------------------------------------------------------------
class StudentIndex:
    """A SQLite-backed index over the student roster.

    Parameters
    ----------
    path:
        Location of the SQLite file. Created on first use.
    """

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self.has_fts = False
        self._open()

    # -- connection ------------------------------------------------------
    def _open(self) -> None:
        try:
            self._conn = sqlite3.connect(str(self.path), timeout=5.0)
            self._conn.row_factory = sqlite3.Row
            # WAL lets readers proceed while a writer holds the lock.
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA temp_store=MEMORY")
            self._init_schema()
        except sqlite3.Error as exc:  # pragma: no cover - environment dependent
            self._conn = None
            raise IndexError_(f"Could not open index at {self.path}: {exc}") from exc

    def _init_schema(self) -> None:
        assert self._conn is not None
        for statement in SCHEMA:
            self._conn.execute(statement)
        try:
            self._conn.execute(FTS_SCHEMA)
            self.has_fts = True
        except sqlite3.Error:
            # SQLite built without FTS5 - fall back to LIKE candidate search.
            self.has_fts = False
        self._conn.commit()

    @contextmanager
    def _cursor(self) -> Iterator[sqlite3.Cursor]:
        if self._conn is None:
            raise IndexError_("Index is not open.")
        cur = self._conn.cursor()
        try:
            yield cur
        finally:
            cur.close()

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.commit()
                self._conn.close()
            finally:
                self._conn = None

    # -- writes ----------------------------------------------------------
    @staticmethod
    def _row(student: Student) -> tuple:
        return (
            student.roll_no, student.name, student.grade, student.section,
            student.email, student.phone, student.attendance, student.gpa,
            student.fee_status, student.fee_due_date, student.status,
            student.enrolled_on, student.notes, student.updated_at,
            student.risk_score, len(student.warnings),
        )

    def sync(self, students: Sequence[Student]) -> int:
        """Replace the whole index with ``students``. Returns the row count."""
        assert self._conn is not None
        placeholders = ", ".join("?" for _ in COLUMNS)
        with self._conn:  # single transaction: all-or-nothing
            self._conn.execute("DELETE FROM students")
            self._conn.executemany(
                f"INSERT INTO students ({', '.join(COLUMNS)}) VALUES ({placeholders})",
                [self._row(s) for s in students],
            )
            if self.has_fts:
                self._conn.execute("DELETE FROM students_fts")
                self._conn.executemany(
                    "INSERT INTO students_fts "
                    "(roll_no, name, email, notes, grade, section, status, fee_status) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    [(s.roll_no, s.name, s.email, s.notes, s.grade, s.section,
                      s.status, s.fee_status) for s in students],
                )
            self._conn.execute(
                "INSERT OR REPLACE INTO index_meta (key, value) VALUES ('synced_at', ?)",
                (time.strftime("%Y-%m-%dT%H:%M:%S"),),
            )
        return len(students)

    def upsert(self, student: Student) -> None:
        """Insert or replace a single record (incremental update)."""
        assert self._conn is not None
        placeholders = ", ".join("?" for _ in COLUMNS)
        with self._conn:
            self._conn.execute(
                f"INSERT OR REPLACE INTO students ({', '.join(COLUMNS)}) "
                f"VALUES ({placeholders})",
                self._row(student),
            )
            if self.has_fts:
                self._conn.execute("DELETE FROM students_fts WHERE roll_no = ?",
                                   (student.roll_no,))
                self._conn.execute(
                    "INSERT INTO students_fts "
                    "(roll_no, name, email, notes, grade, section, status, fee_status) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (student.roll_no, student.name, student.email, student.notes,
                     student.grade, student.section, student.status, student.fee_status),
                )

    def remove(self, roll_no: str) -> None:
        assert self._conn is not None
        with self._conn:
            self._conn.execute("DELETE FROM students WHERE roll_no = ?", (roll_no,))
            if self.has_fts:
                self._conn.execute("DELETE FROM students_fts WHERE roll_no = ?", (roll_no,))

    def rebuild(self, students: Sequence[Student]) -> int:
        """Drop and recreate every index, then re-sync. Returns row count."""
        assert self._conn is not None
        with self._conn:
            for name, _target, _why in INDEXES:
                self._conn.execute(f"DROP INDEX IF EXISTS {name}")
            self._conn.execute("DROP TABLE IF EXISTS students")
            self._conn.execute("DROP TABLE IF EXISTS students_fts")
        self._init_schema()
        return self.sync(students)

    # -- reads -----------------------------------------------------------
    def count(self) -> int:
        with self._cursor() as cur:
            cur.execute("SELECT COUNT(*) AS n FROM students")
            return int(cur.fetchone()["n"])

    def roll_numbers(self) -> list[str]:
        with self._cursor() as cur:
            cur.execute("SELECT roll_no FROM students ORDER BY roll_no")
            return [r["roll_no"] for r in cur.fetchall()]

    def get(self, roll_no: str) -> dict[str, Any] | None:
        """Primary-key lookup - served by the implicit PK index."""
        with self._cursor() as cur:
            cur.execute("SELECT * FROM students WHERE roll_no = ?", (roll_no.upper(),))
            row = cur.fetchone()
            return dict(row) if row else None

    def query(
        self,
        *,
        grade: str | None = None,
        section: str | None = None,
        status: str | None = None,
        fee_status: str | None = None,
        min_attendance: float | None = None,
        max_attendance: float | None = None,
        min_gpa: float | None = None,
        max_gpa: float | None = None,
        has_warnings: bool | None = None,
        order_by: str = "roll_no",
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Structured filter query built from indexed columns.

        Returns rows as dicts. The SQL is assembled from a whitelist of
        columns, so no user string ever reaches the statement text.
        """
        where, params = self._build_where(
            grade=grade, section=section, status=status, fee_status=fee_status,
            min_attendance=min_attendance, max_attendance=max_attendance,
            min_gpa=min_gpa, max_gpa=max_gpa, has_warnings=has_warnings,
        )
        order = self._safe_order(order_by)
        sql = f"SELECT * FROM students{where} ORDER BY {order}"
        if limit is not None:
            sql += f" LIMIT {int(limit)}"
        with self._cursor() as cur:
            cur.execute(sql, params)
            return [dict(r) for r in cur.fetchall()]

    @staticmethod
    def _build_where(**filters: Any) -> tuple[str, list[Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        for column in ("grade", "section", "status", "fee_status"):
            value = filters.get(column)
            if value is not None:
                clauses.append(f"{column} = ?")
                params.append(value)
        for column, op, key in (
            ("attendance", ">=", "min_attendance"),
            ("attendance", "<=", "max_attendance"),
            ("gpa", ">=", "min_gpa"),
            ("gpa", "<=", "max_gpa"),
        ):
            value = filters.get(key)
            if value is not None:
                clauses.append(f"{column} {op} ?")
                params.append(float(value))
        if filters.get("has_warnings") is True:
            clauses.append("warning_count > 0")
        elif filters.get("has_warnings") is False:
            clauses.append("warning_count = 0")
        return (" WHERE " + " AND ".join(clauses)) if clauses else "", params

    @staticmethod
    def _safe_order(order_by: str) -> str:
        """Whitelist ORDER BY so the clause can never be injected."""
        allowed = {
            "roll_no": "roll_no ASC",
            "name": "name COLLATE NOCASE ASC",
            "attendance": "attendance DESC",
            "gpa": "gpa DESC",
            "risk": "risk_score DESC",
            "grade": "grade ASC, section ASC",
        }
        return allowed.get(order_by, "roll_no ASC")

    def search(self, keyword: str, *, limit: int = 500) -> list[str]:
        """Substring candidate search. Returns matching roll numbers.

        Uses ``LIKE '%kw%'`` across the same fields the Python search covers.
        This is deliberately the *complete* candidate set for substring
        semantics - unlike FTS, which only matches whole tokens - so the
        caller can confirm in Python without ever missing a match.

        The scan runs inside SQLite (C level) over the indexed table rather
        than iterating Python objects, and the caller then materialises only
        the surviving records.
        """
        kw = keyword.strip()
        if not kw:
            return self.roll_numbers()

        like = f"%{kw}%"
        with self._cursor() as cur:
            cur.execute(
                "SELECT roll_no FROM students "
                "WHERE roll_no LIKE ? OR name LIKE ? OR email LIKE ? "
                "   OR notes LIKE ? OR grade LIKE ? OR section LIKE ? "
                "   OR status LIKE ? OR fee_status LIKE ? LIMIT ?",
                (like, like, like, like, like, like, like, like, limit),
            )
            return [r["roll_no"] for r in cur.fetchall()]

    def search_fts(self, keyword: str, *, limit: int = 500) -> list[str]:
        """Token/prefix search served by the FTS5 index.

        Faster than :meth:`search` for whole-word queries, but it matches
        *tokens* rather than substrings, so it is offered as a distinct
        capability (the "advanced search" screen) rather than replacing the
        substring search the specification requires.
        """
        kw = keyword.strip()
        if not kw:
            return self.roll_numbers()
        if not self.has_fts:
            return self.search(kw, limit=limit)
        match = self._fts_query(kw)
        if not match:
            return []
        try:
            with self._cursor() as cur:
                cur.execute(
                    "SELECT roll_no FROM students_fts "
                    "WHERE students_fts MATCH ? LIMIT ?",
                    (match, limit),
                )
                return [r["roll_no"] for r in cur.fetchall()]
        except sqlite3.Error:
            return self.search(kw, limit=limit)

    @staticmethod
    def _fts_query(keyword: str) -> str:
        """Turn free text into a safe FTS5 prefix expression.

        Each whitespace-separated token is quoted and given a ``*`` prefix so
        partial words still match, and FTS operators in user input are
        neutralised by the quoting.
        """
        tokens = [t for t in keyword.replace('"', " ").split() if t]
        if not tokens:
            return ""
        return " AND ".join(f'"{t}"*' for t in tokens)

    # -- introspection ---------------------------------------------------
    def explain(self, **filters: Any) -> list[str]:
        """Return SQLite's real ``EXPLAIN QUERY PLAN`` for a filter query.

        This is how index usage is *proved* rather than assumed: each line
        names the index SQLite chose (or ``SCAN`` when it chose none).
        """
        where, params = self._build_where(**filters)
        sql = f"SELECT * FROM students{where} ORDER BY roll_no"
        with self._cursor() as cur:
            cur.execute(f"EXPLAIN QUERY PLAN {sql}", params)
            return [r["detail"] for r in cur.fetchall()]

    def index_list(self) -> list[dict[str, Any]]:
        """Every index SQLite actually holds, with its declared purpose."""
        purposes = {name: why for name, _t, why in INDEXES}
        with self._cursor() as cur:
            cur.execute(
                "SELECT name, tbl_name FROM sqlite_master "
                "WHERE type = 'index' AND tbl_name = 'students' ORDER BY name"
            )
            rows = cur.fetchall()
        out = []
        for r in rows:
            name = r["name"]
            out.append({
                "name": name,
                "table": r["tbl_name"],
                "purpose": purposes.get(name, "implicit primary-key index"),
            })
        return out

    def stats(self) -> dict[str, Any]:
        """Row counts, file size and page statistics for the status screen."""
        with self._cursor() as cur:
            cur.execute("SELECT COUNT(*) AS n FROM students")
            rows = int(cur.fetchone()["n"])
            cur.execute("PRAGMA page_count")
            pages = int(cur.fetchone()[0])
            cur.execute("PRAGMA page_size")
            page_size = int(cur.fetchone()[0])
            cur.execute("SELECT value FROM index_meta WHERE key = 'synced_at'")
            meta = cur.fetchone()
        size = self.path.stat().st_size if self.path.exists() else 0
        return {
            "rows": rows,
            "indexes": len(self.index_list()),
            "fts": self.has_fts,
            "file_bytes": size,
            "pages": pages,
            "page_size": page_size,
            "synced_at": meta["value"] if meta else "never",
        }

    # -- benchmark -------------------------------------------------------
    def benchmark(self, n: int = 20_000) -> dict[str, Any]:
        """Compare an indexed lookup against a linear scan over ``n`` rows.

        Builds a throwaway in-memory table so the real data is untouched.
        Returns timings in milliseconds plus the speed-up factor.
        """
        n = max(100, int(n))
        mem = sqlite3.connect(":memory:")
        try:
            mem.execute(
                "CREATE TABLE bench (roll_no TEXT PRIMARY KEY, grade TEXT, "
                "attendance REAL, name TEXT)"
            )
            mem.executemany(
                "INSERT INTO bench VALUES (?, ?, ?, ?)",
                [(f"B{i:06d}", str(i % 12 + 1), float(i % 100), f"Student {i}")
                 for i in range(n)],
            )
            mem.execute("CREATE INDEX bench_grade ON bench(grade)")
            mem.commit()

            # Indexed: B-tree lookup on grade.
            t0 = time.perf_counter()
            for _ in range(200):
                mem.execute("SELECT roll_no FROM bench WHERE grade = '7'").fetchall()
            indexed_ms = (time.perf_counter() - t0) * 1000 / 200

            # Linear: full table scan with no usable index.
            t0 = time.perf_counter()
            for _ in range(200):
                mem.execute(
                    "SELECT roll_no FROM bench WHERE grade || '' = '7'"
                ).fetchall()
            linear_ms = (time.perf_counter() - t0) * 1000 / 200
        finally:
            mem.close()

        speedup = (linear_ms / indexed_ms) if indexed_ms > 0 else 0.0
        return {
            "rows": n,
            "indexed_ms": round(indexed_ms, 4),
            "linear_ms": round(linear_ms, 4),
            "speedup": round(speedup, 1),
        }


# --------------------------------------------------------------------------
# Convenience
# --------------------------------------------------------------------------
def open_index(path: Path | str) -> StudentIndex | None:
    """Open an index, returning ``None`` instead of raising.

    The repository uses this so a broken or unavailable SQLite build degrades
    to linear scanning rather than breaking the application.
    """
    try:
        return StudentIndex(path)
    except (IndexError_, sqlite3.Error, OSError):
        return None
