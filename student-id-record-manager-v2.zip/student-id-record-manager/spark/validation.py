"""Defensive input validation.

Every user-facing prompt goes through one of the `ask_*` wrappers below.
Each wrapper loops until it receives a valid value, so the application can
never crash on blank, non-numeric, out-of-range or malformed input.

Design rules
------------
* Never raise on user input - re-prompt instead.
* Sanitise before validating (strip, collapse whitespace, strip control chars).
* Accept an explicit "cancel" token so the user can always back out.
* Return typed values (str / int / float / date), never raw strings.
"""

from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime
from typing import Callable, Iterable, Sequence

from . import ui
from .config import C

CANCEL_TOKENS = {"q", "quit", "cancel", "back", "exit", ":q"}

_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_WS_RE = re.compile(r"\s+")


class Cancelled(Exception):
    """Raised internally when the user types a cancel token."""


# --------------------------------------------------------------------------
# Sanitisation
# --------------------------------------------------------------------------
def sanitize(text: str, *, max_len: int = 200) -> str:
    """Normalise user text: strip control chars, collapse whitespace, trim."""
    if text is None:
        return ""
    text = str(text)
    text = _CONTROL_RE.sub("", text)
    text = unicodedata.normalize("NFKC", text)
    text = _WS_RE.sub(" ", text).strip()
    return text[:max_len]


def is_cancel(text: str) -> bool:
    return sanitize(text).lower() in CANCEL_TOKENS


# --------------------------------------------------------------------------
# Core prompt loop
# --------------------------------------------------------------------------
def _prompt_raw(label: str, default: str | None = None) -> str:
    suffix = f" {C.GREY}[{default}]{C.RESET}" if default not in (None, "") else ""
    try:
        return input(f"{C.CYAN}▸{C.RESET} {label}{suffix}: ")
    except (EOFError, KeyboardInterrupt):
        print()
        raise Cancelled()


def ask(
    label: str,
    *,
    validator: Callable[[str], tuple[bool, str, object]] | None = None,
    default: str | None = None,
    allow_cancel: bool = True,
    hint: str | None = None,
    max_attempts: int = 0,
) -> object:
    """Generic validated prompt.

    `validator` receives the sanitised string and returns
    (is_valid, error_message, parsed_value).
    Loops forever (or `max_attempts` times) until valid.
    """
    attempts = 0
    if hint:
        print(f"  {C.GREY}{hint}{C.RESET}")
    while True:
        attempts += 1
        try:
            raw = _prompt_raw(label, default)
        except Cancelled:
            if allow_cancel:
                raise
            print(ui.err("Input closed. Please type a value."))
            continue

        value = sanitize(raw)
        if value == "" and default not in (None, ""):
            value = sanitize(default)

        if allow_cancel and is_cancel(value):
            raise Cancelled()

        if validator is None:
            if value == "":
                print(ui.err("This field cannot be blank. Please try again."))
                continue
            return value

        valid, message, parsed = validator(value)
        if valid:
            return parsed
        print(ui.err(message or "Invalid input. Please try again."))

        if max_attempts and attempts >= max_attempts:
            raise Cancelled()


# --------------------------------------------------------------------------
# Typed validators
# --------------------------------------------------------------------------
def _v_text(min_len: int = 1, max_len: int = 80, field: str = "Value"):
    def check(value: str):
        if len(value) < min_len:
            return False, f"{field} must be at least {min_len} character(s).", None
        if len(value) > max_len:
            return False, f"{field} must be at most {max_len} characters.", None
        if not re.search(r"[A-Za-z0-9]", value):
            return False, f"{field} must contain at least one letter or digit.", None
        return True, "", value

    return check


def ask_text(label: str, *, min_len: int = 1, max_len: int = 80, field: str = "Value",
             default: str | None = None, allow_cancel: bool = True) -> str:
    return ask(label, validator=_v_text(min_len, max_len, field), default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def _v_int(lo: int, hi: int, field: str = "Value"):
    def check(value: str):
        if value == "":
            return False, f"{field} cannot be blank.", None
        try:
            num = int(value)
        except ValueError:
            return False, f"{field} must be a whole number (got '{value}').", None
        if not (lo <= num <= hi):
            return False, f"{field} must be between {lo} and {hi} (got {num}).", None
        return True, "", num

    return check


def ask_int(label: str, lo: int, hi: int, *, field: str = "Value",
            default: str | None = None, allow_cancel: bool = True) -> int:
    return ask(label, validator=_v_int(lo, hi, field), default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def _v_float(lo: float, hi: float, field: str = "Value", decimals: int = 2):
    def check(value: str):
        if value == "":
            return False, f"{field} cannot be blank.", None
        try:
            num = float(value)
        except ValueError:
            return False, f"{field} must be a number (got '{value}').", None
        if num != num or num in (float("inf"), float("-inf")):
            return False, f"{field} must be a finite number.", None
        if not (lo <= num <= hi):
            return False, f"{field} must be between {lo:g} and {hi:g} (got {num:g}).", None
        return True, "", round(num, decimals)

    return check


def ask_float(label: str, lo: float, hi: float, *, field: str = "Value",
              default: str | None = None, allow_cancel: bool = True) -> float:
    return ask(label, validator=_v_float(lo, hi, field), default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def _v_choice(options: Sequence[str], field: str = "Option", case_sensitive: bool = False):
    lookup = {o.lower(): o for o in options} if not case_sensitive else {o: o for o in options}

    def check(value: str):
        key = value if case_sensitive else value.lower()
        if key in lookup:
            return True, "", lookup[key]
        # allow numeric index (1-based)
        if value.isdigit():
            idx = int(value) - 1
            if 0 <= idx < len(options):
                return True, "", options[idx]
        return False, f"{field} must be one of: {', '.join(options)}.", None

    return check


def ask_choice(label: str, options: Sequence[str], *, field: str = "Option",
               default: str | None = None, allow_cancel: bool = True) -> str:
    return ask(label, validator=_v_choice(options, field), default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def _v_date(field: str = "Date", allow_future: bool = True, allow_past: bool = True):
    def check(value: str):
        if value == "":
            return False, f"{field} cannot be blank.", None
        parsed = None
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d"):
            try:
                parsed = datetime.strptime(value, fmt).date()
                break
            except ValueError:
                continue
        if parsed is None:
            return False, f"{field} must be a date like YYYY-MM-DD (got '{value}').", None
        today = date.today()
        if not allow_future and parsed > today:
            return False, f"{field} cannot be in the future.", None
        if not allow_past and parsed < today:
            return False, f"{field} cannot be in the past.", None
        return True, "", parsed

    return check


def ask_date(label: str, *, field: str = "Date", allow_future: bool = True,
             allow_past: bool = True, default: str | None = None,
             allow_cancel: bool = True) -> date:
    return ask(label, validator=_v_date(field, allow_future, allow_past), default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def _v_roll(field: str = "Roll number"):
    """Roll numbers: 3-12 chars, alphanumeric with optional - or _."""
    pattern = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{2,11}$")

    def check(value: str):
        if not value:
            return False, f"{field} cannot be blank.", None
        if not pattern.match(value):
            return False, (
                f"{field} must be 3-12 characters, letters/digits with optional - or _ "
                f"(got '{value}')."
            ), None
        return True, "", value.upper()

    return check


def ask_roll(label: str = "Roll number", *, default: str | None = None,
             allow_cancel: bool = True) -> str:
    return ask(label, validator=_v_roll(), default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def _v_email(field: str = "Email"):
    pattern = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")

    def check(value: str):
        if value == "":
            return True, "", ""  # optional
        if not pattern.match(value):
            return False, f"{field} looks invalid (got '{value}').", None
        return True, "", value.lower()

    return check


def ask_email(label: str = "Email (optional)", *, default: str | None = None,
              allow_cancel: bool = True) -> str:
    return ask(label, validator=_v_email(), default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def ask_yes_no(label: str, *, default: str = "n", allow_cancel: bool = True) -> bool:
    def check(value: str):
        v = value.lower()
        if v in ("y", "yes", "1", "true"):
            return True, "", True
        if v in ("n", "no", "0", "false"):
            return True, "", False
        return False, "Please answer y or n.", None

    return ask(label, validator=check, default=default,
               allow_cancel=allow_cancel)  # type: ignore[return-value]


def ask_menu(label: str, lo: int, hi: int, *, allow_cancel: bool = True) -> int:
    """Menu selection with a clear range error."""
    return ask_int(label, lo, hi, field="Menu choice", allow_cancel=allow_cancel)


def pause(message: str = "Press Enter to continue…") -> None:
    try:
        input(f"{C.GREY}{message}{C.RESET}")
    except (EOFError, KeyboardInterrupt):
        print()
