"""Analytics engine: executive summary, distributions, trends and warnings.

Pure computation over a list of Students - no printing, no I/O. The UI layer
formats whatever this returns, which keeps the maths testable.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, field
from statistics import mean, median, pstdev
from typing import Sequence

from . import config
from .models import Student


# --------------------------------------------------------------------------
# Summary dataclass
# --------------------------------------------------------------------------
@dataclass
class Summary:
    total: int = 0
    active: int = 0
    inactive: int = 0
    graduated: int = 0
    suspended: int = 0

    avg_attendance: float = 0.0
    median_attendance: float = 0.0
    min_attendance: float = 0.0
    max_attendance: float = 0.0
    attendance_stdev: float = 0.0

    avg_gpa: float = 0.0
    median_gpa: float = 0.0
    min_gpa: float = 0.0
    max_gpa: float = 0.0
    gpa_stdev: float = 0.0

    below_attendance_threshold: int = 0
    below_gpa_threshold: int = 0
    fee_overdue: int = 0
    fee_pending: int = 0
    fee_paid: int = 0
    fee_waived: int = 0
    flagged: int = 0
    critical: int = 0

    grade_distribution: Counter = field(default_factory=Counter)
    section_distribution: Counter = field(default_factory=Counter)
    status_distribution: Counter = field(default_factory=Counter)
    attendance_bands: Counter = field(default_factory=Counter)
    gpa_bands: Counter = field(default_factory=Counter)

    top_performers: list[Student] = field(default_factory=list)
    at_risk: list[Student] = field(default_factory=list)
    health_score: float = 0.0
    health_label: str = "n/a"


def _safe_stats(values: Sequence[float]) -> tuple[float, float, float, float, float]:
    if not values:
        return 0.0, 0.0, 0.0, 0.0, 0.0
    return (
        round(mean(values), 2),
        round(median(values), 2),
        round(min(values), 2),
        round(max(values), 2),
        round(pstdev(values), 2) if len(values) > 1 else 0.0,
    )


def _attendance_band(value: float) -> str:
    if value < config.CRITICAL_ATTENDANCE:
        return "Critical (<60%)"
    if value < config.MIN_ATTENDANCE:
        return "Low (60-75%)"
    if value < 90:
        return "Good (75-90%)"
    return "Excellent (90%+)"


def _gpa_band(value: float) -> str:
    if value < config.CRITICAL_GPA:
        return "Critical (<2.5)"
    if value < config.MIN_GPA:
        return "At risk (2.5-4.0)"
    if value < 7.0:
        return "Average (4.0-7.0)"
    if value < 8.5:
        return "Good (7.0-8.5)"
    return "Excellent (8.5+)"


def build_summary(students: Sequence[Student]) -> Summary:
    s = Summary()
    s.total = len(students)
    if not students:
        return s

    statuses = Counter(x.status for x in students)
    s.active = statuses.get("Active", 0)
    s.inactive = statuses.get("Inactive", 0)
    s.graduated = statuses.get("Graduated", 0)
    s.suspended = statuses.get("Suspended", 0)
    s.status_distribution = statuses

    att = [x.attendance for x in students]
    gpa = [x.gpa for x in students]
    (s.avg_attendance, s.median_attendance, s.min_attendance,
     s.max_attendance, s.attendance_stdev) = _safe_stats(att)
    (s.avg_gpa, s.median_gpa, s.min_gpa, s.max_gpa, s.gpa_stdev) = _safe_stats(gpa)

    s.below_attendance_threshold = sum(1 for x in students if x.attendance < config.MIN_ATTENDANCE)
    s.below_gpa_threshold = sum(1 for x in students if x.gpa < config.MIN_GPA)

    fees = Counter(x.fee_status for x in students)
    s.fee_paid = fees.get("Paid", 0)
    s.fee_pending = fees.get("Pending", 0)
    s.fee_overdue = fees.get("Overdue", 0)
    s.fee_waived = fees.get("Waived", 0)

    s.flagged = sum(1 for x in students if x.warnings)
    s.critical = sum(1 for x in students if x.risk_score >= 60)

    s.grade_distribution = Counter(x.grade for x in students)
    s.section_distribution = Counter(x.section for x in students)
    s.attendance_bands = Counter(_attendance_band(x.attendance) for x in students)
    s.gpa_bands = Counter(_gpa_band(x.gpa) for x in students)

    s.top_performers = sorted(
        [x for x in students if x.status == "Active"],
        key=lambda x: (x.gpa, x.attendance),
        reverse=True,
    )[:5]
    s.at_risk = sorted(
        [x for x in students if x.warnings],
        key=lambda x: x.risk_score,
        reverse=True,
    )[:5]

    # Composite health score: attendance + academic + fee hygiene, 0-100
    att_component = min(100.0, s.avg_attendance) * 0.40
    gpa_component = (s.avg_gpa / config.MAX_GPA * 100.0) * 0.40
    fee_component = (s.fee_paid + s.fee_waived) / s.total * 100.0 * 0.20
    s.health_score = round(att_component + gpa_component + fee_component, 1)
    if s.health_score >= 85:
        s.health_label = "Excellent"
    elif s.health_score >= 70:
        s.health_label = "Healthy"
    elif s.health_score >= 55:
        s.health_label = "Needs attention"
    else:
        s.health_label = "Critical"

    return s


# --------------------------------------------------------------------------
# Trends
# --------------------------------------------------------------------------
def trend_lines(students: Sequence[Student]) -> list[str]:
    """Short natural-language observations about the dataset."""
    if not students:
        return ["No records yet - add students to see trends."]

    s = build_summary(students)
    lines: list[str] = []

    # Attendance
    if s.avg_attendance >= 90:
        lines.append(f"Attendance is strong: average {s.avg_attendance:.1f}% across the roster.")
    elif s.avg_attendance >= config.MIN_ATTENDANCE:
        lines.append(f"Attendance is acceptable but uneven: average {s.avg_attendance:.1f}%.")
    else:
        lines.append(f"Attendance is a concern: average {s.avg_attendance:.1f}% is below the "
                     f"{config.MIN_ATTENDANCE:.0f}% threshold.")

    # Spread
    if s.attendance_stdev > 15:
        lines.append(f"Attendance is highly variable (σ={s.attendance_stdev:.1f}) - "
                     f"a small group is pulling the average down.")
    if s.gpa_stdev > 1.5:
        lines.append(f"Academic performance is widely spread (σ={s.gpa_stdev:.2f}).")

    # Concentration
    if s.grade_distribution:
        top_grade, top_n = s.grade_distribution.most_common(1)[0]
        share = top_n / s.total * 100
        if share >= 40:
            lines.append(f"Grade {top_grade} holds {share:.0f}% of all records "
                         f"({top_n} students) - review capacity there.")

    # Risk
    if s.flagged:
        pct = s.flagged / s.total * 100
        lines.append(f"{s.flagged} student(s) ({pct:.0f}%) carry at least one warning flag; "
                     f"{s.critical} are critical.")
    else:
        lines.append("No warning flags raised - the roster is clean.")

    # Fees
    if s.fee_overdue:
        lines.append(f"{s.fee_overdue} fee record(s) are overdue and need follow-up.")
    if s.fee_pending:
        lines.append(f"{s.fee_pending} fee record(s) are still pending.")

    # Outliers
    if s.total >= 5:
        outliers = [x for x in students if x.attendance < s.avg_attendance - 2 * s.attendance_stdev]
        if outliers:
            names = ", ".join(x.roll_no for x in outliers[:3])
            lines.append(f"{len(outliers)} attendance outlier(s) detected (e.g. {names}).")

    return lines


# --------------------------------------------------------------------------
# Warning engine
# --------------------------------------------------------------------------
@dataclass
class Warning:
    roll_no: str
    name: str
    severity: str      # "critical" | "warning" | "info"
    category: str
    message: str


def collect_warnings(students: Sequence[Student]) -> list[Warning]:
    """Every threshold breach across the roster, most severe first."""
    out: list[Warning] = []
    for s in students:
        if s.attendance < config.CRITICAL_ATTENDANCE:
            out.append(Warning(s.roll_no, s.name, "critical", "Attendance",
                               f"{s.attendance:.1f}% - below critical floor "
                               f"({config.CRITICAL_ATTENDANCE:.0f}%)"))
        elif s.attendance < config.MIN_ATTENDANCE:
            out.append(Warning(s.roll_no, s.name, "warning", "Attendance",
                               f"{s.attendance:.1f}% - below minimum ({config.MIN_ATTENDANCE:.0f}%)"))

        if s.gpa < config.CRITICAL_GPA:
            out.append(Warning(s.roll_no, s.name, "critical", "Academics",
                               f"GPA {s.gpa:.2f} - below critical floor ({config.CRITICAL_GPA})"))
        elif s.gpa < config.MIN_GPA:
            out.append(Warning(s.roll_no, s.name, "warning", "Academics",
                               f"GPA {s.gpa:.2f} - below minimum ({config.MIN_GPA})"))

        if s.is_fee_overdue:
            sev = "critical" if s.fee_overdue_days > 30 else "warning"
            out.append(Warning(s.roll_no, s.name, sev, "Fees",
                               f"Overdue by {s.fee_overdue_days} day(s)"))

        if s.status == "Suspended":
            out.append(Warning(s.roll_no, s.name, "warning", "Status", "Record is suspended"))

        if not s.email:
            out.append(Warning(s.roll_no, s.name, "info", "Data quality", "No email on file"))

    order = {"critical": 0, "warning": 1, "info": 2}
    out.sort(key=lambda w: (order.get(w.severity, 3), w.roll_no))
    return out


def anomaly_check(students: Sequence[Student]) -> list[str]:
    """Statistical anomaly detection (z-score on attendance and GPA)."""
    notes: list[str] = []
    if len(students) < 5:
        return notes
    for field_name, label, threshold in (("attendance", "attendance", 2.5), ("gpa", "GPA", 2.5)):
        values = [getattr(s, field_name) for s in students]
        mu = mean(values)
        sigma = pstdev(values)
        if sigma == 0:
            continue
        for s in students:
            z = (getattr(s, field_name) - mu) / sigma
            if abs(z) >= threshold:
                direction = "unusually high" if z > 0 else "unusually low"
                notes.append(
                    f"{s.roll_no} ({s.name}): {label} {getattr(s, field_name):.2f} is "
                    f"{direction} (z={z:+.1f})"
                )
    return notes
