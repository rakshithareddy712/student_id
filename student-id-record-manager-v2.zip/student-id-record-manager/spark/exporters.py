"""Multi-format report export: Markdown, plain-text, CSV.

All exporters take a list of Students plus a Summary and write a file into
exports/. They return the Path written so the UI can report it.
"""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import Sequence

from . import config
from .analytics import Summary, build_summary, collect_warnings, trend_lines
from .models import Student


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _target(prefix: str, ext: str) -> Path:
    config.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    return config.EXPORT_DIR / f"{prefix}_{_stamp()}.{ext}"


# --------------------------------------------------------------------------
# Markdown
# --------------------------------------------------------------------------
def export_markdown(students: Sequence[Student], summary: Summary | None = None) -> Path:
    s = summary or build_summary(students)
    path = _target("summary", "md")
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines: list[str] = []
    lines.append(f"# {config.PROJECT_NAME} — Executive Summary")
    lines.append("")
    lines.append(f"**Generated:** {now}  ")
    lines.append(f"**Project:** {config.APP_NAME} · {config.PROJECT_CODE} · {config.DOMAIN}  ")
    lines.append(f"**Records:** {s.total}")
    lines.append("")
    lines.append("## Roster health")
    lines.append("")
    lines.append(f"| Metric | Value |")
    lines.append(f"|---|---|")
    lines.append(f"| Composite health score | **{s.health_score}/100** ({s.health_label}) |")
    lines.append(f"| Active students | {s.active} |")
    lines.append(f"| Inactive / Graduated / Suspended | {s.inactive} / {s.graduated} / {s.suspended} |")
    lines.append(f"| Flagged records | {s.flagged} |")
    lines.append(f"| Critical records | {s.critical} |")
    lines.append("")
    lines.append("## Attendance")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("|---|---|")
    lines.append(f"| Average | {s.avg_attendance:.2f}% |")
    lines.append(f"| Median | {s.median_attendance:.2f}% |")
    lines.append(f"| Min / Max | {s.min_attendance:.2f}% / {s.max_attendance:.2f}% |")
    lines.append(f"| Std deviation | {s.attendance_stdev:.2f} |")
    lines.append(f"| Below {config.MIN_ATTENDANCE:.0f}% | {s.below_attendance_threshold} |")
    lines.append("")
    lines.append("### Attendance bands")
    lines.append("")
    lines.append("| Band | Students |")
    lines.append("|---|---|")
    for band in ("Excellent (90%+)", "Good (75-90%)", "Low (60-75%)", "Critical (<60%)"):
        lines.append(f"| {band} | {s.attendance_bands.get(band, 0)} |")
    lines.append("")
    lines.append("## Academics")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("|---|---|")
    lines.append(f"| Average GPA | {s.avg_gpa:.2f} / {config.MAX_GPA:g} |")
    lines.append(f"| Median GPA | {s.median_gpa:.2f} |")
    lines.append(f"| Min / Max | {s.min_gpa:.2f} / {s.max_gpa:.2f} |")
    lines.append(f"| Std deviation | {s.gpa_stdev:.2f} |")
    lines.append(f"| Below {config.MIN_GPA:g} | {s.below_gpa_threshold} |")
    lines.append("")
    lines.append("### GPA bands")
    lines.append("")
    lines.append("| Band | Students |")
    lines.append("|---|---|")
    for band in ("Excellent (8.5+)", "Good (7.0-8.5)", "Average (4.0-7.0)",
                 "At risk (2.5-4.0)", "Critical (<2.5)"):
        lines.append(f"| {band} | {s.gpa_bands.get(band, 0)} |")
    lines.append("")
    lines.append("## Fees")
    lines.append("")
    lines.append("| Status | Count |")
    lines.append("|---|---|")
    lines.append(f"| Paid | {s.fee_paid} |")
    lines.append(f"| Pending | {s.fee_pending} |")
    lines.append(f"| Overdue | {s.fee_overdue} |")
    lines.append(f"| Waived | {s.fee_waived} |")
    lines.append("")
    lines.append("## Grade distribution")
    lines.append("")
    lines.append("| Grade | Students |")
    lines.append("|---|---|")
    for grade in sorted(s.grade_distribution, key=lambda g: (len(g), g)):
        lines.append(f"| {grade} | {s.grade_distribution[grade]} |")
    lines.append("")
    lines.append("## Key trends")
    lines.append("")
    for line in trend_lines(students):
        lines.append(f"- {line}")
    lines.append("")

    warnings = collect_warnings(students)
    lines.append("## Warning register")
    lines.append("")
    if warnings:
        lines.append("| Roll | Name | Severity | Category | Detail |")
        lines.append("|---|---|---|---|---|")
        for w in warnings:
            lines.append(f"| {w.roll_no} | {w.name} | {w.severity.upper()} | {w.category} | {w.message} |")
    else:
        lines.append("_No warnings raised._")
    lines.append("")

    if s.top_performers:
        lines.append("## Top performers")
        lines.append("")
        lines.append("| Roll | Name | GPA | Attendance |")
        lines.append("|---|---|---|---|")
        for st in s.top_performers:
            lines.append(f"| {st.roll_no} | {st.name} | {st.gpa:.2f} | {st.attendance:.1f}% |")
        lines.append("")

    lines.append("---")
    lines.append(f"_Generated by {config.APP_NAME} {config.PROJECT_NAME} v{config.VERSION}._")

    path.write_text("\n".join(lines), encoding="utf-8")
    return path


# --------------------------------------------------------------------------
# Plain text
# --------------------------------------------------------------------------
def export_text(students: Sequence[Student], summary: Summary | None = None) -> Path:
    s = summary or build_summary(students)
    path = _target("summary", "txt")
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    w = 78

    def rule(ch: str = "=") -> str:
        return ch * w

    out: list[str] = []
    out.append(rule())
    out.append(f"{config.PROJECT_NAME.upper()} - EXECUTIVE SUMMARY".center(w))
    out.append(f"{config.APP_NAME} | {config.PROJECT_CODE} | {config.DOMAIN}".center(w))
    out.append(rule())
    out.append(f"Generated : {now}")
    out.append(f"Records   : {s.total}")
    out.append(f"Health    : {s.health_score}/100 ({s.health_label})")
    out.append("")
    out.append("ROSTER STATUS")
    out.append(rule("-"))
    out.append(f"  Active      : {s.active:>4}")
    out.append(f"  Inactive    : {s.inactive:>4}")
    out.append(f"  Graduated   : {s.graduated:>4}")
    out.append(f"  Suspended   : {s.suspended:>4}")
    out.append(f"  Flagged     : {s.flagged:>4}")
    out.append(f"  Critical    : {s.critical:>4}")
    out.append("")
    out.append("ATTENDANCE")
    out.append(rule("-"))
    out.append(f"  Average     : {s.avg_attendance:>6.2f}%")
    out.append(f"  Median      : {s.median_attendance:>6.2f}%")
    out.append(f"  Min / Max   : {s.min_attendance:.2f}% / {s.max_attendance:.2f}%")
    out.append(f"  Std dev     : {s.attendance_stdev:>6.2f}")
    out.append(f"  Below {config.MIN_ATTENDANCE:.0f}%   : {s.below_attendance_threshold:>4}")
    out.append("")
    out.append("ACADEMICS")
    out.append(rule("-"))
    out.append(f"  Average GPA : {s.avg_gpa:>6.2f} / {config.MAX_GPA:g}")
    out.append(f"  Median GPA  : {s.median_gpa:>6.2f}")
    out.append(f"  Min / Max   : {s.min_gpa:.2f} / {s.max_gpa:.2f}")
    out.append(f"  Std dev     : {s.gpa_stdev:>6.2f}")
    out.append(f"  Below {config.MIN_GPA:g}   : {s.below_gpa_threshold:>4}")
    out.append("")
    out.append("FEES")
    out.append(rule("-"))
    out.append(f"  Paid {s.fee_paid} | Pending {s.fee_pending} | Overdue {s.fee_overdue} | Waived {s.fee_waived}")
    out.append("")
    out.append("KEY TRENDS")
    out.append(rule("-"))
    for line in trend_lines(students):
        out.append(f"  * {line}")
    out.append("")
    out.append("WARNING REGISTER")
    out.append(rule("-"))
    warnings = collect_warnings(students)
    if warnings:
        for wobj in warnings:
            out.append(f"  [{wobj.severity.upper():8}] {wobj.roll_no:<10} {wobj.category:<12} {wobj.message}")
    else:
        out.append("  No warnings raised.")
    out.append("")
    out.append(rule())
    out.append(f"End of report - {config.APP_NAME} v{config.VERSION}")

    path.write_text("\n".join(out), encoding="utf-8")
    return path


# --------------------------------------------------------------------------
# CSV
# --------------------------------------------------------------------------
def export_csv(students: Sequence[Student]) -> Path:
    path = _target("roster", "csv")
    fields = [
        "roll_no", "name", "grade", "section", "email", "phone",
        "attendance", "gpa", "fee_status", "fee_due_date", "status",
        "enrolled_on", "risk_score", "warnings", "notes", "updated_at",
    ]
    with open(path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for s in students:
            row = s.to_dict()
            row["risk_score"] = s.risk_score
            row["warnings"] = " | ".join(s.warnings)
            writer.writerow({k: row.get(k, "") for k in fields})
    return path


def export_all(students: Sequence[Student]) -> dict[str, Path]:
    s = build_summary(students)
    return {
        "markdown": export_markdown(students, s),
        "text": export_text(students, s),
        "csv": export_csv(students),
    }
