"""Business logic engine: the in-memory roster and all record operations.

The repository owns the list of Students and is the single place that
mutates it. Every mutation persists immediately and writes an audit entry,
so the on-disk state is always consistent with memory.

Indexed queries
---------------
Alongside the in-memory dict, the repository maintains a derived SQLite index
(:mod:`spark.db`) that mirrors every record. Structured filters and keyword
searches are answered by that index - B-tree lookups and an FTS5 full-text
index - instead of a linear Python scan, which is what makes the design scale
to large rosters.

The index is **derived, never authoritative**:

* it is rebuilt from ``students.json`` on load;
* if SQLite is unavailable, or the index file is corrupt, the repository
  silently falls back to the original linear scan, so no functionality is
  ever lost;
* deleting ``data/students.db`` is always safe.
"""

from __future__ import annotations

from collections import Counter
from typing import Any, Callable, Iterable, Sequence

from . import config, db, logging_setup, storage
from .models import Student

log = logging_setup.get_logger("spark.repository")


class DuplicateRollError(Exception):
    pass


class NotFoundError(Exception):
    pass


class Repository:
    def __init__(self, *, use_index: bool | None = None) -> None:
        self._students: dict[str, Student] = {}
        self.notices: list[str] = []
        self._index: db.StudentIndex | None = None
        self._use_index = config.INDEX_ENABLED if use_index is None else use_index

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def load(self) -> list[str]:
        students, notices = storage.load_students()
        self._students = {s.roll_no: s for s in students}
        self.notices = notices
        self._open_index()
        self._sync_index()
        log.info("roster loaded", extra={"records": len(self._students),
                                         "indexed": self.index_available})
        return notices

    def save(self) -> None:
        storage.save_students(self.all())

    # ------------------------------------------------------------------
    # Index management
    # ------------------------------------------------------------------
    def _open_index(self) -> None:
        """Open (or reopen) the derived index. Never raises."""
        if not self._use_index:
            self._index = None
            return
        if self._index is not None:
            return
        self._index = db.open_index(config.DB_PATH)
        if self._index is None:
            log.warning("index unavailable - falling back to linear scan")

    def _sync_index(self) -> None:
        if self._index is None:
            return
        try:
            self._index.sync(self.all())
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("index sync failed", extra={"error": str(exc)})
            self._index = None

    @property
    def index_available(self) -> bool:
        return self._index is not None

    def index_status(self) -> dict[str, Any]:
        """Diagnostics for the index status screen."""
        if self._index is None:
            return {"available": False, "reason": "SQLite index not in use"}
        try:
            stats = self._index.stats()
        except Exception as exc:  # pragma: no cover - defensive
            return {"available": False, "reason": str(exc)}
        stats["available"] = True
        stats["indexes_detail"] = self._index.index_list()
        return stats

    def rebuild_index(self) -> int:
        """Drop and rebuild the index from the in-memory roster."""
        self._open_index()
        if self._index is None:
            return 0
        return self._index.rebuild(self.all())

    def explain_filter(self, **filters: Any) -> list[str]:
        """SQLite's real query plan for a filter - proves index usage."""
        if self._index is None:
            return ["Index not in use - queries are served by a linear scan."]
        try:
            return self._index.explain(**filters)
        except Exception as exc:  # pragma: no cover - defensive
            return [f"Could not explain query: {exc}"]

    def benchmark(self, rows: int | None = None) -> dict[str, Any]:
        """Indexed lookup vs. linear scan, on a throwaway dataset."""
        n = rows or config.BENCHMARK_ROWS
        if self._index is None:
            return {"rows": n, "indexed_ms": 0.0, "linear_ms": 0.0, "speedup": 0.0}
        return self._index.benchmark(n)

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------
    def all(self) -> list[Student]:
        return sorted(self._students.values(), key=lambda s: s.roll_no)

    def count(self) -> int:
        return len(self._students)

    def get(self, roll_no: str) -> Student:
        key = roll_no.strip().upper()
        if key not in self._students:
            raise NotFoundError(f"No student with roll number '{roll_no}'.")
        return self._students[key]

    def exists(self, roll_no: str) -> bool:
        return roll_no.strip().upper() in self._students

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------
    def add(self, student: Student) -> Student:
        if student.roll_no in self._students:
            raise DuplicateRollError(f"Roll number '{student.roll_no}' already exists.")
        student.touch()
        self._students[student.roll_no] = student
        self.save()
        self._index_upsert(student)
        storage.audit("ADD", f"{student.roll_no} | {student.name}")
        return student

    def update(self, roll_no: str, **changes) -> Student:
        student = self.get(roll_no)
        for key, value in changes.items():
            if hasattr(student, key) and value is not None:
                setattr(student, key, value)
        student.touch()
        self.save()
        self._index_upsert(student)
        storage.audit("UPDATE", f"{student.roll_no} | fields={','.join(changes)}")
        return student

    def delete(self, roll_no: str) -> Student:
        student = self.get(roll_no)
        del self._students[student.roll_no]
        self.save()
        self._index_remove(student.roll_no)
        storage.audit("DELETE", f"{student.roll_no} | {student.name}")
        return student

    def bulk_add(self, students: Sequence[Student]) -> tuple[int, list[str]]:
        """Add many records, skipping duplicates. Returns (added, skipped_reasons)."""
        added = 0
        skipped: list[str] = []
        for s in students:
            if s.roll_no in self._students:
                skipped.append(f"{s.roll_no}: duplicate roll number")
                continue
            s.touch()
            self._students[s.roll_no] = s
            added += 1
        if added:
            self.save()
            self._sync_index()
            storage.audit("BULK_IMPORT", f"added={added} skipped={len(skipped)}")
        return added, skipped

    # -- index maintenance helpers --------------------------------------
    def _index_upsert(self, student: Student) -> None:
        if self._index is None:
            return
        try:
            self._index.upsert(student)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("index upsert failed", extra={"error": str(exc)})

    def _index_remove(self, roll_no: str) -> None:
        if self._index is None:
            return
        try:
            self._index.remove(roll_no)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("index remove failed", extra={"error": str(exc)})

    # ------------------------------------------------------------------
    # Search & filter
    # ------------------------------------------------------------------
    def search(self, keyword: str) -> list[Student]:
        """Case-insensitive keyword search across roll, name, grade, section, email, notes.

        Candidate roll numbers come from the SQLite index when it is
        available; the final substring confirmation runs in Python so the
        result is identical either way.
        """
        kw = keyword.strip().lower()
        if not kw:
            return self.all()

        fields = ("roll_no", "name", "grade", "section", "email", "notes", "status", "fee_status")

        def matches(s: Student) -> bool:
            haystack = " ".join(str(getattr(s, f, "")) for f in fields).lower()
            return kw in haystack

        if self._index is not None:
            try:
                candidates = self._index.search(kw)
                return [self._students[r] for r in candidates
                        if r in self._students and matches(self._students[r])]
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("indexed search failed", extra={"error": str(exc)})

        return [s for s in self.all() if matches(s)]

    def search_fts(self, keyword: str) -> list[Student]:
        """Token/prefix search served by the FTS5 index (advanced search)."""
        kw = keyword.strip()
        if not kw:
            return self.all()
        if self._index is None:
            return self.search(kw)
        try:
            candidates = self._index.search_fts(kw)
        except Exception:  # pragma: no cover - defensive
            return self.search(kw)
        return [self._students[r] for r in candidates if r in self._students]

    def filter_by(
        self,
        *,
        grade: str | None = None,
        section: str | None = None,
        status: str | None = None,
        fee_status: str | None = None,
        min_attendance: float | None = None,
        max_attendance: float | None = None,
        min_gpa: float | None = None,
        max_gpa: float | None = None,
        has_warnings: bool | None = None,
        predicate: Callable[[Student], bool] | None = None,
    ) -> list[Student]:
        """Structured filter.

        When the index is available the row set is narrowed by SQLite using
        the declared B-tree indexes, and only the survivors are materialised
        as Python objects. A caller-supplied ``predicate`` is always applied
        afterwards in Python, since arbitrary callables cannot be pushed down.
        """
        if self._index is not None:
            try:
                rows = self._index.query(
                    grade=grade, section=section, status=status,
                    fee_status=fee_status, min_attendance=min_attendance,
                    max_attendance=max_attendance, min_gpa=min_gpa,
                    max_gpa=max_gpa, has_warnings=has_warnings,
                )
                out = [self._students[r["roll_no"]] for r in rows
                       if r["roll_no"] in self._students]
                if predicate is not None:
                    out = [s for s in out if predicate(s)]
                return out
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("indexed filter failed", extra={"error": str(exc)})

        # Fallback: linear scan (identical semantics).
        out: list[Student] = []
        for s in self.all():
            if grade is not None and s.grade != grade:
                continue
            if section is not None and s.section.upper() != section.upper():
                continue
            if status is not None and s.status != status:
                continue
            if fee_status is not None and s.fee_status != fee_status:
                continue
            if min_attendance is not None and s.attendance < min_attendance:
                continue
            if max_attendance is not None and s.attendance > max_attendance:
                continue
            if min_gpa is not None and s.gpa < min_gpa:
                continue
            if max_gpa is not None and s.gpa > max_gpa:
                continue
            if has_warnings is not None and bool(s.warnings) != has_warnings:
                continue
            if predicate is not None and not predicate(s):
                continue
            out.append(s)
        return out

    def flagged(self) -> list[Student]:
        """Records with at least one warning, worst risk first."""
        return sorted(
            [s for s in self.all() if s.warnings],
            key=lambda s: s.risk_score,
            reverse=True,
        )

    # ------------------------------------------------------------------
    # Aggregates
    # ------------------------------------------------------------------
    def distinct(self, field: str) -> list[str]:
        values = {str(getattr(s, field, "")).strip() for s in self.all()}
        return sorted(v for v in values if v)

    def grade_counts(self) -> Counter:
        return Counter(s.grade for s in self.all())

    def status_counts(self) -> Counter:
        return Counter(s.status for s in self.all())

    def fee_counts(self) -> Counter:
        return Counter(s.fee_status for s in self.all())
