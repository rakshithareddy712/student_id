"""Terminal presentation layer: banner, boxes, fixed-width tables, pagination.

Everything here is pure rendering - no business logic, no I/O beyond stdout.
All widths are computed from *visible* length so ANSI colour codes never
break column alignment.
"""

from __future__ import annotations

import re
import shutil
import sys
from typing import Iterable, Sequence

from . import config
from .config import C

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")


# --------------------------------------------------------------------------
# Low-level helpers
# --------------------------------------------------------------------------
def visible_len(text: str) -> int:
    """Length of a string ignoring ANSI escape sequences."""
    return len(_ANSI_RE.sub("", text))


def term_width(default: int = config.TABLE_WIDTH) -> int:
    try:
        return max(60, min(shutil.get_terminal_size((default, 24)).columns, 140))
    except Exception:
        return default


def pad(text: str, width: int, align: str = "left") -> str:
    """Pad to `width` visible characters, accounting for ANSI codes."""
    text = str(text)
    gap = max(0, width - visible_len(text))
    if align == "right":
        return " " * gap + text
    if align == "center":
        left = gap // 2
        return " " * left + text + " " * (gap - left)
    return text + " " * gap


def truncate(text: str, width: int) -> str:
    text = str(text)
    if visible_len(text) <= width:
        return text
    plain = _ANSI_RE.sub("", text)
    return plain[: max(0, width - 1)] + "…"


def clear() -> None:
    if config.color_enabled():
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def hr(char: str = "─", width: int | None = None, color: str = "") -> str:
    width = width or term_width()
    line = char * width
    return f"{color}{line}{C.RESET}" if color else line


# --------------------------------------------------------------------------
# Banner / boxes
# --------------------------------------------------------------------------
_LOGO = r"""
   ____        _        ____                  _
  |  _ \  __ _| |_ __ _/ ___| _ __   __ _ _ __| | __
  | | | |/ _` | __/ _` \___ \| '_ \ / _` | '__| |/ /
  | |_| | (_| | || (_| |___) | |_) | (_| | |  |   <
  |____/ \__,_|\__\__,_|____/| .__/ \__,_|_|  |_|\_\
                             |_|
"""


def banner() -> str:
    """The branded welcome screen."""
    w = term_width()
    out: list[str] = []
    out.append("")
    out.append(f"{C.CYAN}{C.BOLD}{_LOGO}{C.RESET}".rstrip("\n"))
    out.append(hr("═", w, C.CYAN))
    title = f"{C.BOLD}{C.WHITE}{config.PROJECT_NAME}{C.RESET}"
    out.append(pad(title, w, "center"))
    sub = (
        f"{C.GREY}{config.APP_NAME} · {config.PROJECT_CODE} · "
        f"{config.DOMAIN} · v{config.VERSION}{C.RESET}"
    )
    out.append(pad(sub, w, "center"))
    out.append(pad(f"{C.ITALIC}{C.GREY}{config.TAGLINE}{C.RESET}", w, "center"))
    out.append(hr("═", w, C.CYAN))
    out.append("")
    return "\n".join(out)


def box(title: str, lines: Sequence[str], color: str = C.CYAN) -> str:
    """Draw a titled box around a list of already-formatted lines."""
    w = min(term_width(), 100)
    inner = w - 4
    out = [f"{color}┌{'─' * (w - 2)}┐{C.RESET}"]
    out.append(
        f"{color}│{C.RESET} {C.BOLD}{pad(truncate(title, inner), inner)}{C.RESET} {color}│{C.RESET}"
    )
    out.append(f"{color}├{'─' * (w - 2)}┤{C.RESET}")
    for line in lines:
        out.append(f"{color}│{C.RESET} {pad(truncate(line, inner), inner)} {color}│{C.RESET}")
    out.append(f"{color}└{'─' * (w - 2)}┘{C.RESET}")
    return "\n".join(out)


def section(title: str, color: str = C.CYAN) -> str:
    w = term_width()
    label = f" {title} "
    side = max(0, (w - visible_len(label)) // 2)
    return (
        f"{color}{'─' * side}{C.RESET}{C.BOLD}{color}{label}{C.RESET}"
        f"{color}{'─' * (w - side - visible_len(label))}{C.RESET}"
    )


# --------------------------------------------------------------------------
# Messages
# --------------------------------------------------------------------------
def ok(msg: str) -> str:
    return f"{C.GREEN}✔{C.RESET} {msg}"


def err(msg: str) -> str:
    return f"{C.RED}✖{C.RESET} {msg}"


def warn(msg: str) -> str:
    return f"{C.YELLOW}⚠{C.RESET} {msg}"


def info(msg: str) -> str:
    return f"{C.CYAN}ℹ{C.RESET} {msg}"


def badge(text: str, kind: str = "info") -> str:
    """Coloured status pill."""
    palette = {
        "ok": (C.BG_GREEN, C.BLACK),
        "warn": (C.BG_YELLOW, C.BLACK),
        "crit": (C.BG_RED, C.WHITE),
        "info": (C.BG_BLUE, C.WHITE),
        "muted": (C.GREY, C.WHITE),
    }
    bg, fg = palette.get(kind, palette["info"])
    if not config.color_enabled():
        return f"[{text}]"
    return f"{bg}{fg} {text} {C.RESET}"


# --------------------------------------------------------------------------
# Tables
# --------------------------------------------------------------------------
class Column:
    __slots__ = ("header", "key", "width", "align", "formatter")

    def __init__(self, header: str, key: str, width: int, align: str = "left", formatter=None):
        self.header = header
        self.key = key
        self.width = width
        self.align = align
        self.formatter = formatter


def render_table(
    columns: Sequence[Column],
    rows: Iterable[dict],
    *,
    title: str | None = None,
    color: str = C.CYAN,
    empty_msg: str = "No records to display.",
) -> str:
    """Render a fixed-width table. Column widths are honoured exactly."""
    rows = list(rows)
    out: list[str] = []
    if title:
        out.append(f"{C.BOLD}{color}{title}{C.RESET}")

    total = sum(c.width for c in columns) + 3 * (len(columns) - 1)
    out.append(f"{color}┌{'─' * total}┐{C.RESET}")

    header_cells = [pad(f"{C.BOLD}{c.header}{C.RESET}", c.width, c.align) for c in columns]
    out.append(f"{color}│{C.RESET} " + f" {color}│{C.RESET} ".join(header_cells) + f" {color}│{C.RESET}")
    out.append(f"{color}├{'─' * total}┤{C.RESET}")

    if not rows:
        out.append(f"{color}│{C.RESET} {pad(empty_msg, total - 2)} {color}│{C.RESET}")
    else:
        for row in rows:
            cells = []
            for c in columns:
                raw = row.get(c.key, "")
                val = c.formatter(raw, row) if c.formatter else str(raw)
                cells.append(pad(truncate(val, c.width), c.width, c.align))
            out.append(f"{color}│{C.RESET} " + f" {color}│{C.RESET} ".join(cells) + f" {color}│{C.RESET}")

    out.append(f"{color}└{'─' * total}┘{C.RESET}")
    return "\n".join(out)


def paginate(
    columns: Sequence[Column],
    rows: Sequence[dict],
    *,
    page: int = 1,
    page_size: int = config.PAGE_SIZE,
    title: str | None = None,
    color: str = C.CYAN,
) -> tuple[str, int, int]:
    """Render one page of a table. Returns (rendered, page, total_pages)."""
    rows = list(rows)
    total_pages = max(1, (len(rows) + page_size - 1) // page_size)
    page = max(1, min(page, total_pages))
    start = (page - 1) * page_size
    chunk = rows[start : start + page_size]

    header = title or "Results"
    header = f"{header}  (page {page}/{total_pages} · {len(rows)} record(s))"
    body = render_table(columns, chunk, title=header, color=color)
    return body, page, total_pages


# --------------------------------------------------------------------------
# Progress / meters
# --------------------------------------------------------------------------
def meter(value: float, maximum: float = 100.0, width: int = 20) -> str:
    """A tiny ASCII progress bar, e.g. for attendance."""
    try:
        ratio = max(0.0, min(1.0, float(value) / maximum if maximum else 0.0))
    except (TypeError, ValueError):
        ratio = 0.0
    filled = int(round(ratio * width))
    if ratio >= 0.9:
        col = C.GREEN
    elif ratio >= 0.75:
        col = C.YELLOW
    else:
        col = C.RED
    return f"{col}{'█' * filled}{C.GREY}{'░' * (width - filled)}{C.RESET}"


def kv_block(pairs: Sequence[tuple[str, str]], key_width: int = 26) -> str:
    return "\n".join(f"  {C.GREY}{pad(k + ':', key_width)}{C.RESET}{v}" for k, v in pairs)
