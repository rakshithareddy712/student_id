#!/usr/bin/env python3
"""DataSpark Challenge Project #24 - Student ID Record Manager.

Entry point. Run with:

    python3 main.py                 # interactive terminal application
    python3 main.py --rebuild-index # rebuild the SQLite index and exit
    python3 main.py --benchmark     # run the index benchmark and exit
    python3 main.py --selftest      # run the test suite and exit
    python3 main.py --version       # print version information

Standard library only. Python 3.10+.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from spark import config  # noqa: E402


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="student-id-record-manager",
        description=f"{config.APP_NAME} - {config.PROJECT_NAME} "
                    f"({config.PROJECT_CODE}, {config.DOMAIN})",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python3 main.py                  start the interactive menu\n"
            "  python3 main.py --rebuild-index  rebuild the derived SQLite index\n"
            "  python3 main.py --benchmark      compare indexed vs. linear lookup\n"
            "  python3 main.py --selftest       run the automated test suite\n"
        ),
    )
    parser.add_argument("--version", action="store_true",
                        help="print version information and exit")
    parser.add_argument("--rebuild-index", action="store_true",
                        help="rebuild the derived SQLite index from students.json")
    parser.add_argument("--benchmark", action="store_true",
                        help="run the indexed-vs-linear benchmark and exit")
    parser.add_argument("--benchmark-rows", type=int, default=config.BENCHMARK_ROWS,
                        help=f"rows for --benchmark (default {config.BENCHMARK_ROWS})")
    parser.add_argument("--selftest", action="store_true",
                        help="run the automated test suite and exit")
    parser.add_argument("--no-index", action="store_true",
                        help="disable the SQLite index (force linear scanning)")
    parser.add_argument("--no-color", action="store_true",
                        help="disable ANSI colour output")
    return parser


def _cmd_version() -> int:
    print(f"{config.APP_NAME} - {config.PROJECT_NAME}")
    print(f"Version   : {config.VERSION}")
    print(f"Project   : {config.PROJECT_CODE} ({config.DOMAIN})")
    print(f"Python    : {sys.version.split()[0]}")
    print(f"Data dir  : {config.DATA_DIR}")
    print(f"Index     : {config.DB_PATH}")
    return 0


def _cmd_rebuild_index() -> int:
    from spark.repository import Repository
    repo = Repository()
    repo.load()
    count = repo.rebuild_index()
    if count:
        print(f"Rebuilt the SQLite index: {count} record(s) indexed at {config.DB_PATH}")
        return 0
    print("Index is not available in this environment; the app will use "
          "linear scanning instead.")
    return 1


def _cmd_benchmark(rows: int) -> int:
    from spark.repository import Repository
    repo = Repository()
    repo.load()
    result = repo.benchmark(rows)
    print(f"Dataset        : {result['rows']:,} rows")
    print(f"Indexed lookup : {result['indexed_ms']:.4f} ms per query")
    print(f"Linear scan    : {result['linear_ms']:.4f} ms per query")
    print(f"Speed-up       : {result['speedup']:.1f}x")
    return 0


def _cmd_selftest() -> int:
    import subprocess
    test_file = ROOT / "tests" / "test_all.py"
    if not test_file.exists():
        print(f"Test suite not found at {test_file}", file=sys.stderr)
        return 1
    return subprocess.call([sys.executable, str(test_file)])


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.no_color:
        import os
        os.environ["NO_COLOR"] = "1"
    if args.no_index:
        config.INDEX_ENABLED = False

    if args.version:
        return _cmd_version()
    if args.rebuild_index:
        return _cmd_rebuild_index()
    if args.benchmark:
        return _cmd_benchmark(args.benchmark_rows)
    if args.selftest:
        return _cmd_selftest()

    from spark.app import main as run_app
    try:
        return run_app()
    except KeyboardInterrupt:
        print("\nInterrupted.")
        return 130


if __name__ == "__main__":
    sys.exit(main())
