# API Reference — Student ID Record Manager v2.0.0

Complete reference for every public module, class and function in the
`spark` package. The project is **standard-library only**; nothing here
requires a third-party install.

- [Package layout](#package-layout)
- [`spark.config`](#sparkconfig)
- [`spark.models`](#sparkmodels)
- [`spark.validation`](#sparkvalidation)
- [`spark.storage`](#sparkstorage)
- [`spark.locking`](#sparklocking)
- [`spark.db`](#sparkdb)
- [`spark.repository`](#sparkrepository)
- [`spark.analytics`](#sparkanalytics)
- [`spark.exporters`](#sparkexporters)
- [`spark.logging_setup`](#sparklogging_setup)
- [`spark.ui`](#sparkui)
- [`spark.charts`](#sparkcharts)
- [`spark.app`](#sparkapp)
- [CLI reference](#cli-reference)
- [Data formats](#data-formats)
- [Error handling contract](#error-handling-contract)

---

## Package layout

```
student-id-record-manager/
├── main.py                  CLI entry point (argparse)
├── spark/
│   ├── config.py            branding, paths, thresholds, ANSI palette
│   ├── models.py            Student dataclass + derived properties
│   ├── validation.py        defensive input wrappers
│   ├── storage.py           JSON/CSV persistence, atomic writes, audit
│   ├── locking.py           cross-platform advisory file lock
│   ├── db.py                derived SQLite index (B-tree + FTS5)
│   ├── repository.py        business logic engine
│   ├── analytics.py         summary, trends, warnings, anomalies
│   ├── exporters.py         Markdown / text / CSV reports
│   ├── logging_setup.py     structured JSON Lines logging
│   ├── ui.py                banner, tables, pagination, meters
│   ├── charts.py            optional PNG charts + ASCII fallback
│   └── app.py               interactive terminal application
├── data/                    students.json, students.csv, students.db
├── exports/                 reports, audit.log, logs/
├── tests/test_all.py        automated test suite
└── tools/make_sample_data.py
```

---

## `spark.config`

Module-level constants. Imported everywhere; never mutated except by tests
and the `--no-index` CLI flag.

| Name | Type | Meaning |
|---|---|---|
| `APP_NAME` | `str` | `"DataSpark"` |
| `PROJECT_NAME` | `str` | `"Student ID Record Manager"` |
| `PROJECT_CODE` | `str` | `"Challenge Project #24"` |
| `DOMAIN` | `str` | `"Campus & Administration"` |
| `VERSION` | `str` | `"2.0.0"` |
| `BASE_DIR` | `Path` | Project root, resolved from `__file__` |
| `DATA_DIR` | `Path` | `<root>/data` |
| `EXPORT_DIR` | `Path` | `<root>/exports` |
| `JSON_PATH` | `Path` | `<root>/data/students.json` — canonical store |
| `CSV_PATH` | `Path` | `<root>/data/students.csv` — spreadsheet mirror |
| `DB_PATH` | `Path` | `<root>/data/students.db` — derived index |
| `AUDIT_LOG` | `Path` | `<root>/exports/audit.log` |
| `BACKUP_DIR` | `Path` | `<root>/data/backups` |
| `LOG_DIR` | `Path` | `<root>/exports/logs` |
| `INDEX_ENABLED` | `bool` | Master switch for the SQLite index |
| `LOCK_TIMEOUT` | `float` | Seconds to wait for the write lock (default `5.0`) |
| `BENCHMARK_ROWS` | `int` | Default benchmark size (default `20_000`) |
| `MIN_ATTENDANCE` | `float` | `75.0` — below this raises a warning |
| `CRITICAL_ATTENDANCE` | `float` | `60.0` — below this is critical |
| `MIN_GPA` | `float` | `4.0` |
| `CRITICAL_GPA` | `float` | `2.5` |
| `MAX_GPA` | `float` | `10.0` |
| `VALID_STATUS` | `tuple[str, ...]` | `Active, Inactive, Graduated, Suspended` |
| `VALID_FEE_STATUS` | `tuple[str, ...]` | `Paid, Pending, Overdue, Waived` |
| `VALID_GRADES` | `tuple[str, ...]` | `"1"` … `"12"` |
| `PAGE_SIZE` | `int` | Rows per table page (default `10`) |

### `class C`

ANSI escape helpers. **Every attribute is an empty string when colour is
disabled**, so formatting code never needs a branch.

```python
from spark.config import C
print(f"{C.GREEN}ok{C.RESET}")
```

Attributes: `RESET, BOLD, DIM, ITALIC, UNDERLINE, BLACK, RED, GREEN, YELLOW,
BLUE, MAGENTA, CYAN, WHITE, GREY, BG_BLUE, BG_CYAN, BG_RED, BG_GREEN,
BG_YELLOW`.

### `color_enabled() -> bool`

`True` when ANSI output is safe. Colour is disabled if `NO_COLOR` is set,
`TERM=dumb`, or stdout is not a TTY (unless `FORCE_COLOR` is set).

---

## `spark.models`

### `@dataclass class Student`

The single domain record. `roll_no` is the primary key.

| Field | Type | Default | Notes |
|---|---|---|---|
| `roll_no` | `str` | — | Primary key, stored upper-case |
| `name` | `str` | — | |
| `grade` | `str` | `"10"` | `"1"`–`"12"` |
| `section` | `str` | `"A"` | |
| `email` | `str` | `""` | Optional |
| `phone` | `str` | `""` | Optional |
| `attendance` | `float` | `100.0` | 0–100 |
| `gpa` | `float` | `0.0` | 0–10 |
| `fee_status` | `str` | `"Paid"` | One of `VALID_FEE_STATUS` |
| `fee_due_date` | `str` | `""` | ISO date, optional |
| `status` | `str` | `"Active"` | One of `VALID_STATUS` |
| `enrolled_on` | `str` | today | ISO date |
| `notes` | `str` | `""` | |
| `updated_at` | `str` | now | ISO timestamp |

#### Derived properties

| Property | Returns | Meaning |
|---|---|---|
| `attendance_band` | `str` | `critical` / `low` / `ok` / `high` |
| `academic_band` | `str` | `critical` / `risk` / `ok` / `excellent` |
| `fee_overdue_days` | `int` | Days past due; `0` if paid/waived/no date |
| `is_fee_overdue` | `bool` | `fee_overdue_days > FEE_OVERDUE_GRACE_DAYS` |
| `warnings` | `list[str]` | Human-readable threshold breaches |
| `risk_score` | `int` | Composite 0–100, higher = more at risk |

#### Methods

```python
Student.to_dict() -> dict[str, Any]
Student.from_dict(raw: dict) -> Student      # classmethod, never raises
Student.touch() -> None                      # refresh updated_at
```

`from_dict` is deliberately defensive: it coerces types, clamps numbers into
range, maps `NaN`/`Inf` to defaults, and substitutes `"UNKNOWN"` / `"Unnamed"`
for missing identity fields. **One corrupt row can never take down a load.**

---

## `spark.validation`

Every user-facing prompt goes through these wrappers. Each loops until it
receives a valid value, so the application cannot crash on bad input.

### `sanitize(text, *, max_len=200) -> str`

Strips control characters, applies Unicode NFKC normalisation, collapses
whitespace, trims, and truncates.

### `is_cancel(text) -> bool`

`True` for `q`, `quit`, `cancel`, `back`, `exit`, `:q`.

### `class Cancelled(Exception)`

Raised when the user types a cancel token or closes stdin.

### `ask(label, *, validator=None, default=None, allow_cancel=True, hint=None, max_attempts=0) -> object`

The generic prompt loop. `validator` receives the sanitised string and returns
`(is_valid, error_message, parsed_value)`.

### Typed wrappers

| Function | Returns | Validation |
|---|---|---|
| `ask_text(label, *, min_len=1, max_len=80, field, default)` | `str` | length + must contain a letter/digit |
| `ask_int(label, lo, hi, *, field, default)` | `int` | whole number in `[lo, hi]` |
| `ask_float(label, lo, hi, *, field, default)` | `float` | finite number in `[lo, hi]`, rounded to 2dp |
| `ask_choice(label, options, *, field, default)` | `str` | name (case-insensitive) or 1-based index |
| `ask_date(label, *, field, allow_future, allow_past, default)` | `date` | `YYYY-MM-DD`, `DD-MM-YYYY`, `DD/MM/YYYY`, `YYYY/MM/DD` |
| `ask_roll(label, *, default)` | `str` | 3–12 chars, `[A-Za-z0-9_-]`, upper-cased |
| `ask_email(label, *, default)` | `str` | RFC-ish pattern; blank allowed |
| `ask_yes_no(label, *, default="n")` | `bool` | `y/yes/1/true` or `n/no/0/false` |
| `ask_menu(label, lo, hi)` | `int` | integer in range |
| `pause(message="Press Enter to continue…")` | `None` | swallows EOF/KeyboardInterrupt |

`ask_float` explicitly rejects `nan`, `inf` and `-inf`.

---

## `spark.storage`

Persistence layer. JSON is canonical; CSV is a mirror; both are written
atomically.

### `audit(action, detail="") -> None`

Records a mutation. Delegates to `spark.logging_setup.audit`, which writes a
structured log record **and** appends the legacy tab-separated line to
`audit.log`. Never raises.

### `load_students(path=None) -> tuple[list[Student], list[str]]`

Returns `(students, notices)`. `notices` describes any recovery performed, so
the UI can tell the user what happened. Handles:

| Condition | Behaviour |
|---|---|
| File missing | Creates a clean template, notice raised |
| File empty | Initialises a clean roster |
| Invalid JSON | Backs the file up, starts clean, notice with line number |
| Wrong top-level type | Backs up, starts clean |
| Non-dict rows | Skipped and counted |
| Duplicate `roll_no` | Skipped and counted |
| Unreadable / bad encoding | Backs up, starts clean |

### `save_students(students, *, path=None, write_csv=True, lock=True) -> None`

Writes JSON atomically (temp file + `os.replace` + `fsync`), then mirrors to
CSV. When `lock=True` (the default) the whole write is wrapped in an exclusive
advisory file lock. Raises `StorageError` on unrecoverable I/O failure or lock
timeout.

### `save_csv(students, path=None) -> None`

Atomic CSV write with the canonical column order.

### `load_csv(path) -> tuple[list[Student], list[dict]]`

Bulk import from a legacy CSV. Returns `(students, row_errors)` where each
error is `{"row": int, "reason": str, "raw": dict}`. Validates required
columns, numeric fields, enumerations and duplicates **row by row**, so one
bad line never aborts the import.

### `ensure_templates() -> list[str]`

Creates `students.json` / `students.csv` if absent. Returns notices.

### `backup(path) -> Path | None`

Timestamped copy into `data/backups/`.

### `class StorageError(Exception)`

Raised only for unrecoverable I/O problems.

---

## `spark.locking`

Cross-platform advisory file locking, added to close the "race conditions
during writes" gap.

### `class FileLock(path, timeout=5.0)`

| Member | Behaviour |
|---|---|
| `acquire()` | Blocks until held; raises `LockTimeout` on expiry. Re-entrant. |
| `release()` | Decrements the nesting counter; unlocks at zero. |
| `held` | `bool` — whether this instance holds the lock. |
| `__enter__` / `__exit__` | Context-manager support. |

POSIX uses `fcntl.flock(LOCK_EX | LOCK_NB)`; Windows uses
`msvcrt.locking`. Both are released automatically if the process dies, so a
crash can never leave a permanent lock. Retries use exponential back-off
(10 ms → 200 ms).

### `locked(path, timeout=5.0)` — context manager

```python
from spark.locking import locked
with locked(config.JSON_PATH):
    ...  # exclusive read-modify-write
```

### `class LockTimeout(Exception)`

Raised when the lock cannot be acquired in time.

---

## `spark.db`

The derived SQLite index. **Never authoritative** — it can be deleted at any
time and rebuilt from `students.json`.

### `class StudentIndex(path)`

| Member | Description |
|---|---|
| `sync(students) -> int` | Replace the whole index in one transaction |
| `upsert(student) -> None` | Insert or replace one record |
| `remove(roll_no) -> None` | Delete one record |
| `rebuild(students) -> int` | Drop and recreate all indexes, then sync |
| `count() -> int` | Row count |
| `roll_numbers() -> list[str]` | All keys, ordered |
| `get(roll_no) -> dict \| None` | Primary-key lookup |
| `query(**filters) -> list[dict]` | Structured filter (see below) |
| `search(keyword, limit=500) -> list[str]` | Substring candidates (`LIKE`) |
| `search_fts(keyword, limit=500) -> list[str]` | Token/prefix candidates (FTS5) |
| `explain(**filters) -> list[str]` | Real `EXPLAIN QUERY PLAN` output |
| `index_list() -> list[dict]` | Every index with its declared purpose |
| `stats() -> dict` | Rows, index count, FTS flag, size, pages, sync time |
| `benchmark(n=20_000) -> dict` | Indexed vs. linear timing on a throwaway table |
| `close() -> None` | Commit and close |

`query()` accepts: `grade`, `section`, `status`, `fee_status`,
`min_attendance`, `max_attendance`, `min_gpa`, `max_gpa`, `has_warnings`,
`order_by`, `limit`. The `ORDER BY` clause is whitelisted, and all values are
bound parameters — **no user string ever reaches the statement text**.

### Declared indexes

| Index | Columns | Purpose |
|---|---|---|
| `idx_students_grade` | `grade` | equality filter |
| `idx_students_section` | `section` | equality filter |
| `idx_students_status` | `status` | equality filter |
| `idx_students_fee_status` | `fee_status` | equality filter |
| `idx_students_attendance` | `attendance` | range filter |
| `idx_students_gpa` | `gpa` | range filter |
| `idx_students_risk` | `risk_score DESC` | ordered warning register |
| `idx_students_name` | `name COLLATE NOCASE` | name ordering / prefix |
| `idx_students_grade_section` | `(grade, section)` | composite two-field filter |
| `idx_students_status_attendance` | `(status, attendance)` | composite "active below X%" |

Plus `students_fts` (FTS5) over `name, email, notes, grade, section, status,
fee_status`, and the implicit primary-key index on `roll_no`.

### `open_index(path) -> StudentIndex | None`

Opens an index, returning `None` instead of raising. The repository uses this
so a broken SQLite build degrades to linear scanning.

### `class IndexError_(Exception)`

Raised when the index cannot be opened or built.

---

## `spark.repository`

The business logic engine. Owns the in-memory roster and is the only place
that mutates it.

### `class Repository(use_index=None)`

`use_index` defaults to `config.INDEX_ENABLED`.

#### Lifecycle

| Method | Description |
|---|---|
| `load() -> list[str]` | Load from JSON, open the index, sync it. Returns notices. |
| `save() -> None` | Persist the current roster |

#### Index management

| Method | Description |
|---|---|
| `index_available` | `bool` property |
| `index_status() -> dict` | Diagnostics for the status screen |
| `rebuild_index() -> int` | Drop and rebuild from memory |
| `explain_filter(**filters) -> list[str]` | Query plan for a filter |
| `benchmark(rows=None) -> dict` | Indexed vs. linear timing |

#### Read

| Method | Description |
|---|---|
| `all() -> list[Student]` | Sorted by `roll_no` |
| `count() -> int` | |
| `get(roll_no) -> Student` | Raises `NotFoundError` |
| `exists(roll_no) -> bool` | |

#### Write

| Method | Description |
|---|---|
| `add(student) -> Student` | Raises `DuplicateRollError` |
| `update(roll_no, **changes) -> Student` | |
| `delete(roll_no) -> Student` | |
| `bulk_add(students) -> tuple[int, list[str]]` | Returns `(added, skipped_reasons)` |

Every mutation persists immediately, updates the index, and writes an audit
entry.

#### Search & filter

| Method | Description |
|---|---|
| `search(keyword) -> list[Student]` | Case-insensitive substring across roll, name, grade, section, email, notes, status, fee status |
| `search_fts(keyword) -> list[Student]` | Token/prefix search via FTS5 |
| `filter_by(**filters) -> list[Student]` | Structured filter; accepts an optional `predicate` callable |
| `flagged() -> list[Student]` | Records with warnings, worst risk first |

`filter_by` accepts `grade`, `section`, `status`, `fee_status`,
`min_attendance`, `max_attendance`, `min_gpa`, `max_gpa`, `has_warnings`,
`predicate`.

#### Aggregates

`distinct(field)`, `grade_counts()`, `status_counts()`, `fee_counts()`.

### Exceptions

- `DuplicateRollError` — roll number already present
- `NotFoundError` — no such roll number

---

## `spark.analytics`

Pure computation over a list of `Student`. No printing, no I/O — which is
what makes the maths testable.

### `@dataclass class Summary`

Holds totals, status counts, attendance and GPA statistics (mean, median,
min, max, population standard deviation), threshold counts, fee counts,
distributions, `top_performers`, `at_risk`, `health_score` and `health_label`.

### `build_summary(students) -> Summary`

Computes everything above. The composite health score is:

```
health = 0.40 × avg_attendance
       + 0.40 × (avg_gpa / MAX_GPA × 100)
       + 0.20 × (paid + waived) / total × 100
```

Labels: `≥85 Excellent`, `≥70 Healthy`, `≥55 Needs attention`, else
`Critical`.

### `trend_lines(students) -> list[str]`

Short natural-language observations: attendance level, spread, grade
concentration, risk, fees, attendance outliers.

### `@dataclass class Warning`

`roll_no`, `name`, `severity` (`critical` / `warning` / `info`), `category`,
`message`.

### `collect_warnings(students) -> list[Warning]`

Every threshold breach, sorted most severe first.

### `anomaly_check(students) -> list[str]`

Z-score outlier detection on attendance and GPA (|z| ≥ 2.5). Requires at
least 5 records.

---

## `spark.exporters`

### `export_markdown(students, summary=None) -> Path`

Full executive summary as Markdown: health, attendance, academics, fees,
grade distribution, trends, warning register, top performers.

### `export_text(students, summary=None) -> Path`

The same content as a fixed-width plain-text report.

### `export_csv(students) -> Path`

Roster CSV including derived `risk_score` and `warnings` columns.

### `export_all(students) -> dict[str, Path]`

Returns `{"markdown": Path, "text": Path, "csv": Path}`.

All exporters write into `config.EXPORT_DIR` with a timestamped filename.

---

## `spark.logging_setup`

Structured logging on the standard `logging` framework, emitting **JSON
Lines**.

### `SESSION_ID: str`

A 12-character correlation id generated per process. Every record carries it.

### `configure(log_dir=None, *, level=INFO, console=False, max_bytes=1_000_000, backup_count=3, force=False) -> Logger`

Sets up the `spark` logger tree. Idempotent unless `force=True`. Writes
`app.log` (human) and `app.jsonl` (machine) with size-based rotation.
`log_dir=None` disables file output.

### `get_logger(name="spark") -> Logger`

Returns a child logger, e.g. `get_logger("spark.storage")`.

### `audit(action, detail="", *, log_path=None) -> None`

Emits a structured record and optionally appends the legacy tab-separated
line. Never raises.

### `reset() -> None`

Tears down handlers (used by tests).

### `class JsonFormatter` / `class HumanFormatter`

The two formatters. JSON records have the shape:

```json
{"ts":"2026-11-25T12:00:00.000+00:00","level":"INFO","logger":"spark.audit",
 "event":"audit","session":"a1b2c3d4e5f6","pid":1234,
 "action":"ADD","detail":"S1001 | Aarav Sharma"}
```

---

## `spark.ui`

Pure rendering. All widths are computed from **visible** length, so ANSI
codes never break column alignment.

| Function | Description |
|---|---|
| `visible_len(text) -> int` | Length ignoring ANSI escapes |
| `term_width(default=100) -> int` | Clamped terminal width (60–140) |
| `pad(text, width, align="left") -> str` | ANSI-aware padding |
| `truncate(text, width) -> str` | ANSI-aware truncation with `…` |
| `clear() -> None` | Clear the screen (no-op without colour) |
| `hr(char, width, color) -> str` | Horizontal rule |
| `banner() -> str` | Branded welcome screen |
| `box(title, lines, color) -> str` | Titled box |
| `section(title, color) -> str` | Centred section header |
| `ok/err/warn/info(msg) -> str` | Prefixed message lines |
| `badge(text, kind) -> str` | Coloured status pill |
| `render_table(columns, rows, *, title, color, empty_msg) -> str` | Fixed-width table |
| `paginate(columns, rows, *, page, page_size, title, color) -> tuple[str, int, int]` | One page of a table |
| `meter(value, maximum=100, width=20) -> str` | ASCII progress bar |
| `kv_block(pairs, key_width=26) -> str` | Aligned key/value block |

### `class Column(header, key, width, align="left", formatter=None)`

A table column definition. `formatter(value, row) -> str` allows per-cell
styling.

---

## `spark.charts`

Optional charting. Uses matplotlib when installed; otherwise falls back to
pure-ASCII bar charts so the feature never hard-fails.

| Function | Description |
|---|---|
| `ascii_bar_chart(title, counts, width=40) -> str` | Always available |
| `attendance_histogram(students) -> Path \| None` | PNG |
| `gpa_histogram(students) -> Path \| None` | PNG |
| `grade_bar(students) -> Path \| None` | PNG |
| `fee_pie(students) -> Path \| None` | PNG |
| `generate_all(students) -> list[Path]` | All four, skipping failures |

`HAS_MPL` reports whether matplotlib is importable.

---

## `spark.app`

### `class App`

| Method | Description |
|---|---|
| `start()` | Configure logging, load the roster, show notices |
| `run()` | Main loop with a last-resort exception guard |
| `shutdown()` | Save and print the session summary |
| `main_menu()` | Render the menu and dispatch |

Menu handlers: `add_record`, `view_all`, `search_records`, `filter_records`,
`view_one`, `edit_record`, `delete_record`, `executive_summary`,
`warning_register`, `export_reports`, `generate_charts`, `import_csv`,
`index_status`, `benchmark`, `exit_app`.

### `main() -> int`

Runs the application. Returns the process exit code.

---

## CLI reference

```
python3 main.py [options]

  --version              print version information and exit
  --rebuild-index        rebuild the derived SQLite index from students.json
  --benchmark            run the indexed-vs-linear benchmark and exit
  --benchmark-rows N     rows for --benchmark (default 20000)
  --selftest             run the automated test suite and exit
  --no-index             disable the SQLite index (force linear scanning)
  --no-color             disable ANSI colour output
```

Exit codes: `0` success, `1` failure (e.g. index unavailable), `130`
interrupted.

---

## Data formats

### `data/students.json` (canonical)

```json
{
  "meta": {
    "app": "DataSpark",
    "project": "Student ID Record Manager",
    "version": "2.0.0",
    "saved_at": "2026-11-25T12:00:00",
    "count": 40
  },
  "students": [
    {
      "roll_no": "S1001",
      "name": "Aarav Sharma",
      "grade": "10",
      "section": "A",
      "email": "aarav.sharma@school.edu",
      "phone": "9876500001",
      "attendance": 96.5,
      "gpa": 9.1,
      "fee_status": "Paid",
      "fee_due_date": "",
      "status": "Active",
      "enrolled_on": "2026-05-03",
      "notes": "House captain",
      "updated_at": "2026-11-19T09:00:00"
    }
  ]
}
```

A bare JSON list is also accepted on load.

### `data/students.csv` (mirror / import)

```
roll_no,name,grade,section,email,phone,attendance,gpa,fee_status,fee_due_date,status,enrolled_on,notes,updated_at
```

Only `roll_no` and `name` are required for import; every other column is
optional.

### `data/students.db` (derived index)

SQLite. Safe to delete — it is rebuilt from the JSON on next load.

---

## Error handling contract

| Layer | Guarantee |
|---|---|
| `validation` | Never raises on user input; re-prompts instead |
| `models.from_dict` | Never raises; clamps and substitutes defaults |
| `storage.load_*` | Never raises on corrupt data; backs up and recovers |
| `storage.save_*` | Raises `StorageError` only on unrecoverable I/O |
| `locking` | Raises `LockTimeout` rather than corrupting |
| `db` | Optional; failure degrades to linear scanning |
| `repository` | Raises only `DuplicateRollError` / `NotFoundError` |
| `app` | Last-resort guard returns to the menu, never crashes |
| `logging` | Never raises; a logging failure cannot break the app |
