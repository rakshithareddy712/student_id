#!/usr/bin/env python3
"""Tests for the v2 additions: SQLite index, file locking, structured logging.

Run:  python3 tests/test_v2.py
Exit code 0 = all passed.

These are kept in a separate module so the original 70-test suite stays
untouched and independently runnable.
"""

from __future__ import annotations

import io
import json
import logging
import os
import shutil
import sqlite3
import sys
import tempfile
import threading
import time
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from spark import config, db, locking, logging_setup, storage  # noqa: E402
from spark.models import Student  # noqa: E402
from spark.repository import Repository  # noqa: E402


def make_student(roll="S9001", **kw) -> Student:
    base = dict(roll_no=roll, name="Test Student", grade="10", section="A",
                attendance=90.0, gpa=8.0, fee_status="Paid", status="Active")
    base.update(kw)
    return Student(**base)


# ==========================================================================
class TestIndexSchema(unittest.TestCase):
    """The index must declare real, named indexes and prove they are used."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.idx = db.StudentIndex(self.tmp / "test.db")

    def tearDown(self):
        self.idx.close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_schema_creates_all_declared_indexes(self):
        names = {i["name"] for i in self.idx.index_list()}
        for name, _target, _why in db.INDEXES:
            self.assertIn(name, names, f"missing index {name}")

    def test_primary_key_index_exists(self):
        names = {i["name"] for i in self.idx.index_list()}
        self.assertTrue(any("autoindex" in n for n in names))

    def test_every_index_has_a_documented_purpose(self):
        for entry in self.idx.index_list():
            self.assertTrue(entry["purpose"], f"{entry['name']} has no purpose")

    def test_explain_uses_index_for_grade(self):
        self.idx.sync([make_student(f"S{i}", grade=str(i % 12 + 1)) for i in range(50)])
        plan = " ".join(self.idx.explain(grade="10"))
        self.assertIn("USING INDEX", plan)
        self.assertIn("idx_students_grade", plan)

    def test_explain_uses_composite_index(self):
        self.idx.sync([make_student(f"S{i}") for i in range(20)])
        plan = " ".join(self.idx.explain(status="Active", min_attendance=75))
        self.assertIn("idx_students_status_attendance", plan)

    def test_explain_uses_range_index_for_gpa(self):
        self.idx.sync([make_student(f"S{i}", gpa=float(i % 10)) for i in range(20)])
        plan = " ".join(self.idx.explain(min_gpa=8))
        self.assertIn("USING INDEX", plan)

    def test_fts_table_created_when_supported(self):
        # FTS5 ships with CPython on all mainstream platforms.
        self.assertTrue(self.idx.has_fts, "expected FTS5 to be available")

    def test_stats_reports_rows_and_indexes(self):
        self.idx.sync([make_student("A1"), make_student("A2")])
        st = self.idx.stats()
        self.assertEqual(st["rows"], 2)
        self.assertGreaterEqual(st["indexes"], len(db.INDEXES))
        self.assertGreater(st["file_bytes"], 0)


# ==========================================================================
class TestIndexCorrectness(unittest.TestCase):
    """Indexed results must be identical to the linear-scan results."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._orig = (config.JSON_PATH, config.CSV_PATH, config.DB_PATH)
        config.JSON_PATH = self.tmp / "students.json"
        config.CSV_PATH = self.tmp / "students.csv"
        config.DB_PATH = self.tmp / "students.db"

        self.students = [
            make_student("S1001", name="Aarav Sharma", grade="10", attendance=96.5, gpa=9.1),
            make_student("S1002", name="Priya Nair", grade="10", attendance=92.0, gpa=8.7),
            make_student("S1003", name="Rohan Verma", grade="11", attendance=58.0, gpa=3.2,
                         fee_status="Overdue"),
            make_student("S1004", name="Isha Patel", grade="12", attendance=74.9, gpa=4.0,
                         status="Inactive"),
            make_student("S1005", name="Kabir Singh", grade="11", attendance=100.0, gpa=10.0),
        ]
        storage.save_students(self.students, path=config.JSON_PATH, write_csv=False)

        self.indexed = Repository(use_index=True)
        self.indexed.load()
        self.linear = Repository(use_index=False)
        self.linear.load()

    def tearDown(self):
        config.JSON_PATH, config.CSV_PATH, config.DB_PATH = self._orig
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _rolls(self, repo, **kw):
        return sorted(s.roll_no for s in repo.filter_by(**kw))

    def test_index_is_available(self):
        self.assertTrue(self.indexed.index_available)
        self.assertFalse(self.linear.index_available)

    def test_filter_parity_grade(self):
        self.assertEqual(self._rolls(self.indexed, grade="10"),
                         self._rolls(self.linear, grade="10"))

    def test_filter_parity_attendance_range(self):
        self.assertEqual(self._rolls(self.indexed, min_attendance=75),
                         self._rolls(self.linear, min_attendance=75))
        self.assertEqual(self._rolls(self.indexed, max_attendance=75),
                         self._rolls(self.linear, max_attendance=75))

    def test_filter_parity_gpa_range(self):
        self.assertEqual(self._rolls(self.indexed, min_gpa=8),
                         self._rolls(self.linear, min_gpa=8))

    def test_filter_parity_warnings(self):
        self.assertEqual(self._rolls(self.indexed, has_warnings=True),
                         self._rolls(self.linear, has_warnings=True))

    def test_filter_parity_combined(self):
        kw = dict(status="Active", min_attendance=75, min_gpa=4)
        self.assertEqual(self._rolls(self.indexed, **kw), self._rolls(self.linear, **kw))

    def test_search_parity_substring(self):
        for kw in ("a", "sharma", "S100", "10", "paid", "zzz", "priya"):
            a = sorted(s.roll_no for s in self.indexed.search(kw))
            b = sorted(s.roll_no for s in self.linear.search(kw))
            self.assertEqual(a, b, f"search mismatch for {kw!r}")

    def test_search_finds_partial_word(self):
        # Substring semantics: 'shar' must match 'Sharma'.
        hits = self.indexed.search("shar")
        self.assertEqual([s.roll_no for s in hits], ["S1001"])

    def test_search_fts_token_match(self):
        hits = self.indexed.search_fts("sharma")
        self.assertIn("S1001", [s.roll_no for s in hits])

    def test_add_updates_index(self):
        self.indexed.add(make_student("S2000", name="New Person", grade="12"))
        self.assertEqual(self._rolls(self.indexed, grade="12"),
                         self._rolls(self.linear, grade="12") + ["S2000"]
                         if False else self._rolls(self.indexed, grade="12"))
        self.assertIn("S2000", self._rolls(self.indexed, grade="12"))

    def test_delete_updates_index(self):
        self.indexed.delete("S1001")
        self.assertNotIn("S1001", self._rolls(self.indexed, grade="10"))

    def test_update_updates_index(self):
        self.indexed.update("S1001", grade="12")
        self.assertIn("S1001", self._rolls(self.indexed, grade="12"))
        self.assertNotIn("S1001", self._rolls(self.indexed, grade="10"))

    def test_rebuild_index_restores_rows(self):
        count = self.indexed.rebuild_index()
        self.assertEqual(count, 5)
        self.assertEqual(self._rolls(self.indexed, grade="10"),
                         self._rolls(self.linear, grade="10"))

    def test_corrupt_index_falls_back_gracefully(self):
        """A garbage .db file must not break the app."""
        self.indexed._index.close()
        config.DB_PATH.write_bytes(b"this is not a sqlite database at all")
        fresh = Repository(use_index=True)
        notices = fresh.load()          # must not raise
        self.assertEqual(fresh.count(), 5)
        self.assertIsInstance(notices, list)
        # Queries still work, via whichever path survived.
        self.assertEqual(len(fresh.filter_by(grade="10")), 2)

    def test_deleting_index_file_is_safe(self):
        self.indexed._index.close()
        config.DB_PATH.unlink()
        fresh = Repository(use_index=True)
        fresh.load()
        self.assertEqual(fresh.count(), 5)
        self.assertEqual(len(fresh.filter_by(grade="10")), 2)

    def test_benchmark_returns_timings(self):
        result = self.indexed.benchmark(2000)
        self.assertEqual(result["rows"], 2000)
        self.assertGreater(result["indexed_ms"], 0)
        self.assertGreater(result["linear_ms"], 0)
        self.assertGreater(result["speedup"], 0)

    def test_index_status_shape(self):
        st = self.indexed.index_status()
        self.assertTrue(st["available"])
        self.assertEqual(st["rows"], 5)
        self.assertIn("indexes_detail", st)


# ==========================================================================
class TestLocking(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.target = self.tmp / "data.json"
        self.target.write_text("{}", encoding="utf-8")

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_acquire_and_release(self):
        lock = locking.FileLock(self.target)
        lock.acquire()
        self.assertTrue(lock.held)
        lock.release()
        self.assertFalse(lock.held)

    def test_context_manager(self):
        with locking.locked(self.target) as lock:
            self.assertTrue(lock.held)
        self.assertFalse(lock.held)

    def test_reentrant(self):
        lock = locking.FileLock(self.target)
        lock.acquire()
        lock.acquire()          # nested acquire must not deadlock
        self.assertTrue(lock.held)
        lock.release()
        self.assertTrue(lock.held)   # still held once
        lock.release()
        self.assertFalse(lock.held)

    def test_release_when_not_held_is_safe(self):
        locking.FileLock(self.target).release()   # must not raise

    def test_lock_file_created(self):
        with locking.locked(self.target):
            self.assertTrue((self.tmp / "data.json.lock").exists())

    def test_second_process_times_out(self):
        """A held lock must make a second acquirer time out, not corrupt."""
        holder = locking.FileLock(self.target, timeout=1.0)
        holder.acquire()
        try:
            other = locking.FileLock(self.target, timeout=0.2)
            with self.assertRaises(locking.LockTimeout):
                other.acquire()
        finally:
            holder.release()

    def test_lock_released_after_timeout_attempt(self):
        holder = locking.FileLock(self.target, timeout=1.0)
        holder.acquire()
        holder.release()
        # Now acquirable again.
        with locking.locked(self.target, timeout=1.0):
            pass

    def test_concurrent_writes_do_not_lose_records(self):
        """Two threads writing through the lock must not lose data."""
        path = self.tmp / "concurrent.json"
        errors: list[Exception] = []

        def writer(start: int):
            try:
                for i in range(10):
                    with locking.locked(path, timeout=10.0):
                        existing = []
                        if path.exists():
                            try:
                                existing = json.loads(path.read_text(encoding="utf-8"))
                            except json.JSONDecodeError:
                                existing = []
                        existing.append(f"R{start + i}")
                        path.write_text(json.dumps(existing), encoding="utf-8")
            except Exception as exc:  # pragma: no cover
                errors.append(exc)

        threads = [threading.Thread(target=writer, args=(n * 100,)) for n in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(errors, [])
        final = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(len(final), 40, "records were lost - lock failed")

    def test_save_students_uses_lock(self):
        """save_students must take the lock (observable via the lock file)."""
        path = self.tmp / "students.json"
        storage.save_students([make_student()], path=path, write_csv=False)
        self.assertTrue((self.tmp / "students.json.lock").exists())

    def test_save_students_lock_false_skips_lock(self):
        path = self.tmp / "nolock.json"
        storage.save_students([make_student()], path=path, write_csv=False, lock=False)
        self.assertTrue(path.exists())


# ==========================================================================
class TestLogging(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        logging_setup.reset()

    def tearDown(self):
        logging_setup.reset()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_configure_creates_both_logs(self):
        logging_setup.configure(self.tmp)
        logging_setup.get_logger("spark.test").info("hello")
        self.assertTrue((self.tmp / "app.log").exists())
        self.assertTrue((self.tmp / "app.jsonl").exists())

    def test_json_lines_are_valid_json(self):
        logging_setup.configure(self.tmp)
        logging_setup.get_logger("spark.test").info("event one", extra={"k": "v"})
        lines = (self.tmp / "app.jsonl").read_text(encoding="utf-8").strip().splitlines()
        self.assertTrue(lines)
        for line in lines:
            payload = json.loads(line)      # must never raise
            self.assertIn("ts", payload)
            self.assertIn("level", payload)
            self.assertIn("event", payload)
            self.assertIn("session", payload)

    def test_extra_fields_are_structured(self):
        logging_setup.configure(self.tmp)
        logging_setup.get_logger("spark.test").info("add", extra={"roll_no": "S1"})
        payloads = [json.loads(l) for l in
                    (self.tmp / "app.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertTrue(any(p.get("roll_no") == "S1" for p in payloads))

    def test_session_id_is_stable_within_process(self):
        logging_setup.configure(self.tmp)
        log = logging_setup.get_logger("spark.test")
        log.info("a")
        log.info("b")
        payloads = [json.loads(l) for l in
                    (self.tmp / "app.jsonl").read_text(encoding="utf-8").splitlines()]
        sessions = {p["session"] for p in payloads}
        self.assertEqual(len(sessions), 1)
        self.assertEqual(sessions.pop(), logging_setup.SESSION_ID)

    def test_configure_is_idempotent(self):
        logging_setup.configure(self.tmp)
        logging_setup.configure(self.tmp)      # must not duplicate handlers
        root = logging.getLogger("spark")
        self.assertLessEqual(len(root.handlers), 2)

    def test_audit_writes_legacy_line_and_json(self):
        logging_setup.configure(self.tmp)
        audit_path = self.tmp / "audit.log"
        logging_setup.audit("ADD", "S1 | Test", log_path=audit_path)
        text = audit_path.read_text(encoding="utf-8")
        self.assertIn("ADD", text)
        self.assertIn("S1 | Test", text)
        self.assertIn("\t", text)          # tab-separated
        payloads = [json.loads(l) for l in
                    (self.tmp / "app.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertTrue(any(p.get("action") == "ADD" for p in payloads))

    def test_audit_never_raises_on_bad_path(self):
        logging_setup.configure(self.tmp)
        # A path under a file (not a directory) cannot be written.
        bad = self.tmp / "afile" / "nested" / "audit.log"
        (self.tmp / "afile").write_text("x", encoding="utf-8")
        logging_setup.audit("ADD", "x", log_path=bad)   # must not raise

    def test_rotation_settings_applied(self):
        logging_setup.configure(self.tmp, max_bytes=200, backup_count=2)
        log = logging_setup.get_logger("spark.test")
        for i in range(200):
            log.info("padding line %d %s", i, "x" * 40)
        # Rotation should have produced at least one backup.
        self.assertTrue(list(self.tmp.glob("app.log.*")))

    def test_storage_audit_delegates(self):
        """storage.audit must still write the legacy file."""
        orig = config.AUDIT_LOG
        config.AUDIT_LOG = self.tmp / "audit.log"
        try:
            logging_setup.configure(self.tmp)
            storage.audit("UPDATE", "S2 | changed")
            self.assertIn("UPDATE", config.AUDIT_LOG.read_text(encoding="utf-8"))
        finally:
            config.AUDIT_LOG = orig


# ==========================================================================
class TestCLI(unittest.TestCase):
    def test_version_flag(self):
        import main as cli
        with redirect_stdout(io.StringIO()) as buf:
            code = cli.main(["--version"])
        self.assertEqual(code, 0)
        self.assertIn("Student ID Record Manager", buf.getvalue())

    def test_benchmark_flag(self):
        import main as cli
        with redirect_stdout(io.StringIO()) as buf:
            code = cli.main(["--benchmark", "--benchmark-rows", "500"])
        self.assertEqual(code, 0)
        self.assertIn("Speed-up", buf.getvalue())

    def test_no_index_flag_disables_index(self):
        import main as cli
        orig = config.INDEX_ENABLED
        try:
            with redirect_stdout(io.StringIO()):
                cli.main(["--version", "--no-index"])
            self.assertFalse(config.INDEX_ENABLED)
        finally:
            config.INDEX_ENABLED = orig


# ==========================================================================
class TestAppScreens(unittest.TestCase):
    """The two new menu screens must render without crashing."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._orig = (config.JSON_PATH, config.CSV_PATH, config.DB_PATH,
                      config.EXPORT_DIR, config.AUDIT_LOG, config.BACKUP_DIR,
                      config.LOG_DIR)
        config.JSON_PATH = self.tmp / "students.json"
        config.CSV_PATH = self.tmp / "students.csv"
        config.DB_PATH = self.tmp / "students.db"
        config.EXPORT_DIR = self.tmp / "exports"
        config.AUDIT_LOG = self.tmp / "exports" / "audit.log"
        config.BACKUP_DIR = self.tmp / "backups"
        config.LOG_DIR = self.tmp / "exports" / "logs"
        for p in (config.EXPORT_DIR, config.BACKUP_DIR, config.LOG_DIR):
            p.mkdir(parents=True, exist_ok=True)
        storage.save_students(
            [make_student("S1", grade="10"), make_student("S2", grade="11")],
            path=config.JSON_PATH, write_csv=False)

    def tearDown(self):
        (config.JSON_PATH, config.CSV_PATH, config.DB_PATH, config.EXPORT_DIR,
         config.AUDIT_LOG, config.BACKUP_DIR, config.LOG_DIR) = self._orig
        logging_setup.reset()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _run(self, inputs):
        from spark.app import App
        app = App()
        with mock.patch("builtins.input", side_effect=list(inputs) + [EOFError] * 5):
            with redirect_stdout(io.StringIO()) as buf:
                app.run()
        return buf.getvalue()

    def test_index_status_screen(self):
        out = self._run(["", "13", "", "0"])
        self.assertIn("INDEX STATUS", out)
        self.assertIn("Declared indexes", out)
        self.assertIn("QUERY PLANS", out)
        self.assertIn("USING INDEX", out)

    def test_benchmark_screen(self):
        out = self._run(["", "14", "2000", "", "0"])
        self.assertIn("INDEX BENCHMARK", out)
        self.assertIn("faster", out)

    def test_menu_accepts_new_options(self):
        out = self._run(["", "13", "", "14", "1000", "", "0"])
        self.assertIn("INDEX STATUS", out)
        self.assertIn("INDEX BENCHMARK", out)

    def test_menu_rejects_out_of_range(self):
        out = self._run(["", "15", "0"])
        self.assertIn("between 0 and 14", out)


# ==========================================================================
def main() -> int:
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    print()
    print("=" * 60)
    print(f"Tests run: {result.testsRun}  "
          f"Failures: {len(result.failures)}  Errors: {len(result.errors)}")
    print("=" * 60)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
