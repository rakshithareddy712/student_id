#!/usr/bin/env python3
"""Generate the sample dataset (40 records) in both CSV and JSON.

The dataset deliberately mixes:
  * normal, healthy records
  * boundary values (attendance exactly 75.0 / 60.0, GPA exactly 4.0 / 2.5)
  * edge conditions (0% attendance, 100% attendance, max GPA, suspended,
    overdue fees, missing email, long names, unicode names, blank notes)

Run:  python3 tools/make_sample_data.py
"""

from __future__ import annotations

import csv
import json
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from spark import config  # noqa: E402

TODAY = date.today()


def d(days: int) -> str:
    return (TODAY + timedelta(days=days)).isoformat()


# (roll, name, grade, section, email, phone, attendance, gpa, fee_status,
#  fee_due_offset_days, status, notes)
RAW = [
    # ---- healthy, normal records -------------------------------------
    ("S1001", "Aarav Sharma", "10", "A", "aarav.sharma@school.edu", "9876500001", 96.5, 9.1, "Paid", None, "Active", "House captain"),
    ("S1002", "Priya Nair", "10", "A", "priya.nair@school.edu", "9876500002", 92.0, 8.7, "Paid", None, "Active", "Debate team"),
    ("S1003", "Rohan Mehta", "10", "B", "rohan.mehta@school.edu", "9876500003", 88.4, 7.9, "Paid", None, "Active", ""),
    ("S1004", "Ananya Iyer", "10", "B", "ananya.iyer@school.edu", "9876500004", 94.2, 9.4, "Paid", None, "Active", "Science olympiad"),
    ("S1005", "Kabir Singh", "9", "A", "kabir.singh@school.edu", "9876500005", 85.0, 7.2, "Paid", None, "Active", ""),
    ("S1006", "Meera Krishnan", "9", "A", "meera.k@school.edu", "9876500006", 91.3, 8.2, "Paid", None, "Active", "Music club"),
    ("S1007", "Arjun Reddy", "9", "B", "arjun.reddy@school.edu", "9876500007", 79.5, 6.8, "Pending", 12, "Active", ""),
    ("S1008", "Sneha Patel", "9", "B", "sneha.patel@school.edu", "9876500008", 97.8, 9.6, "Paid", None, "Active", "Topper"),
    ("S1009", "Vikram Rao", "11", "A", "vikram.rao@school.edu", "9876500009", 83.6, 7.5, "Paid", None, "Active", ""),
    ("S1010", "Divya Menon", "11", "A", "divya.menon@school.edu", "9876500010", 90.1, 8.9, "Paid", None, "Active", "Student council"),
    ("S1011", "Aditya Joshi", "11", "B", "aditya.joshi@school.edu", "9876500011", 87.2, 7.8, "Paid", None, "Active", ""),
    ("S1012", "Kavya Pillai", "11", "B", "kavya.pillai@school.edu", "9876500012", 93.7, 8.5, "Paid", None, "Active", "Art club"),
    ("S1013", "Ishaan Gupta", "12", "A", "ishaan.gupta@school.edu", "9876500013", 89.9, 8.1, "Paid", None, "Active", "Prefect"),
    ("S1014", "Riya Desai", "12", "A", "riya.desai@school.edu", "9876500014", 95.4, 9.2, "Paid", None, "Active", ""),
    ("S1015", "Nikhil Verma", "12", "B", "nikhil.verma@school.edu", "9876500015", 81.0, 7.0, "Pending", 20, "Active", ""),
    ("S1016", "Tanvi Bhatt", "12", "B", "tanvi.bhatt@school.edu", "9876500016", 92.6, 8.8, "Paid", None, "Active", "Quiz team"),
    ("S1017", "Siddharth Kulkarni", "8", "A", "sid.kulkarni@school.edu", "9876500017", 86.3, 7.4, "Paid", None, "Active", ""),
    ("S1018", "Pooja Shetty", "8", "A", "pooja.shetty@school.edu", "9876500018", 90.8, 8.3, "Paid", None, "Active", ""),
    ("S1019", "Harsh Agarwal", "8", "B", "harsh.agarwal@school.edu", "9876500019", 78.9, 6.5, "Pending", 5, "Active", ""),
    ("S1020", "Nandini Rao", "8", "B", "nandini.rao@school.edu", "9876500020", 94.9, 9.0, "Paid", None, "Active", "Dance troupe"),

    # ---- boundary values ---------------------------------------------
    ("S1021", "Boundary Attendance 75", "10", "C", "b75@school.edu", "9876500021", 75.0, 6.0, "Paid", None, "Active", "Exactly at minimum attendance"),
    ("S1022", "Boundary Attendance 60", "10", "C", "b60@school.edu", "9876500022", 60.0, 5.5, "Paid", None, "Active", "Exactly at critical attendance"),
    ("S1023", "Boundary GPA 4", "10", "C", "g4@school.edu", "9876500023", 80.0, 4.0, "Paid", None, "Active", "Exactly at minimum GPA"),
    ("S1024", "Boundary GPA 2.5", "10", "C", "g25@school.edu", "9876500024", 80.0, 2.5, "Paid", None, "Active", "Exactly at critical GPA"),
    ("S1025", "Perfect Attendance", "9", "C", "perfect@school.edu", "9876500025", 100.0, 10.0, "Paid", None, "Active", "100% attendance, max GPA"),
    ("S1026", "Zero Attendance", "9", "C", "zero@school.edu", "9876500026", 0.0, 0.0, "Overdue", -45, "Inactive", "Long absence - medical leave"),

    # ---- at-risk / warning records -----------------------------------
    ("S1027", "Rahul Yadav", "11", "C", "rahul.yadav@school.edu", "9876500027", 68.4, 3.8, "Overdue", -12, "Active", "Needs counselling"),
    ("S1028", "Simran Kaur", "11", "C", "simran.kaur@school.edu", "9876500028", 72.1, 3.2, "Pending", 3, "Active", "Academic support plan"),
    ("S1029", "Manish Tiwari", "12", "C", "manish.tiwari@school.edu", "9876500029", 55.0, 2.1, "Overdue", -60, "Active", "Chronic absenteeism"),
    ("S1030", "Deepa Nambiar", "12", "C", "deepa.nambiar@school.edu", "9876500030", 64.7, 3.9, "Overdue", -8, "Active", ""),
    ("S1031", "Farhan Khan", "8", "C", "farhan.khan@school.edu", "9876500031", 58.2, 2.4, "Overdue", -35, "Suspended", "Disciplinary review"),
    ("S1032", "Anjali Bose", "9", "D", "anjali.bose@school.edu", "9876500032", 70.5, 3.5, "Pending", 8, "Active", ""),

    # ---- edge conditions ---------------------------------------------
    ("S1033", "Graduated Student", "12", "D", "grad@school.edu", "9876500033", 88.0, 8.0, "Paid", None, "Graduated", "Alumni - class of last year"),
    ("S1034", "Inactive Transfer", "10", "D", "transfer@school.edu", "9876500034", 76.0, 6.2, "Waived", None, "Inactive", "Transferred out"),
    ("S1035", "Fee Waiver Case", "7", "A", "waiver@school.edu", "9876500035", 84.0, 7.1, "Waived", None, "Active", "Scholarship recipient"),
    ("S1036", "No Email On File", "7", "A", "", "9876500036", 82.5, 6.9, "Paid", None, "Active", "Guardian has no email"),
    ("S1037", "Lakshmi Venkataraman Subramaniam", "7", "B", "lakshmi.vs@school.edu", "9876500037", 91.0, 8.4, "Paid", None, "Active", "Long name edge case"),
    ("S1038", "José Fernández", "6", "A", "jose.f@school.edu", "9876500038", 87.5, 7.6, "Paid", None, "Active", "Unicode name edge case"),
    ("S1039", "Aarohi Chatterjee", "6", "A", "aarohi.c@school.edu", "9876500039", 93.0, 8.6, "Paid", None, "Active", ""),
    ("S1040", "Dev Malhotra", "6", "B", "dev.malhotra@school.edu", "9876500040", 77.7, 5.9, "Pending", 15, "Active", "New admission"),
]


def build_rows() -> list[dict]:
    rows = []
    for (roll, name, grade, section, email, phone, att, gpa, fee, due_off,
         status, notes) in RAW:
        rows.append({
            "roll_no": roll,
            "name": name,
            "grade": grade,
            "section": section,
            "email": email,
            "phone": phone,
            "attendance": att,
            "gpa": gpa,
            "fee_status": fee,
            "fee_due_date": d(due_off) if due_off is not None else "",
            "status": status,
            "enrolled_on": d(-200),
            "notes": notes,
            "updated_at": f"{TODAY.isoformat()}T09:00:00",
        })
    return rows


def main() -> int:
    rows = build_rows()
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)

    # CSV
    fields = ["roll_no", "name", "grade", "section", "email", "phone",
              "attendance", "gpa", "fee_status", "fee_due_date", "status",
              "enrolled_on", "notes", "updated_at"]
    with open(config.CSV_PATH, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

    # JSON
    payload = {
        "meta": {
            "app": config.APP_NAME,
            "project": config.PROJECT_NAME,
            "version": config.VERSION,
            "saved_at": f"{TODAY.isoformat()}T09:00:00",
            "count": len(rows),
            "note": "Sample dataset: normal, boundary and edge-case records.",
        },
        "students": rows,
    }
    with open(config.JSON_PATH, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)

    print(f"Wrote {len(rows)} records")
    print(f"  CSV : {config.CSV_PATH}")
    print(f"  JSON: {config.JSON_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
