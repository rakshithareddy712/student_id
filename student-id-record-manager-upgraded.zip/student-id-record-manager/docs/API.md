# API Reference

The application is organized as a small Python package named `spark`. The
terminal interface calls the repository; the repository delegates durable
writes to `storage.py`. JSON is the canonical portable store, CSV is a
spreadsheet mirror, and SQLite is an indexed query mirror.

## Public modules

### `spark.models`
- `Student`: dataclass representing one student record.
- `Student.from_dict(mapping)`: constructs a defensive model from a mapping.
- `Student.to_dict()`: returns a JSON/CSV-compatible mapping.
- Derived properties: `attendance_band`, `academic_band`, `fee_overdue_days`,
  `is_fee_overdue`, `warnings`, and `risk_score`.

### `spark.repository`
- `Repository.load() -> list[str]`: load the roster and return recovery notices.
- `Repository.add(student) -> Student`: add a unique roll number and persist.
- `Repository.get(roll_no) -> Student`: retrieve by normalized roll number.
- `Repository.update(roll_no, **changes) -> Student`: update and persist.
- `Repository.delete(roll_no) -> Student`: remove and persist.
- `Repository.search(keyword) -> list[Student]`: case-insensitive keyword search.
- `Repository.filter_by(**criteria) -> list[Student]`: category/range filtering.
- `DuplicateRollError`, `NotFoundError`: expected domain exceptions.

### `spark.storage`
- `load_students(path=None) -> (students, notices)`: recover and load JSON.
- `save_students(students, path=None, write_csv=True)`: atomically save JSON,
  mirror CSV, and refresh the SQLite index.
- `load_csv(path) -> (students, errors)`: validate a legacy CSV import.
- `audit(action, detail="")`: append a best-effort audit event.

Writes use a process lock file, a temporary file, `fsync`, and atomic rename.
The lock wait is bounded; callers receive `StorageError` if the lock remains
busy beyond the timeout.

### `spark.sqlite_store`
- `replace_all(students, path=None)`: transactionally rebuild the indexed mirror.
- `get_by_roll(roll_no, path=None) -> Student | None`: primary-key lookup.
- `search_name(prefix, limit=50, path=None) -> list[Student]`: indexed prefix query.
- `explain_roll_lookup(path=None) -> list[str]`: return SQLite query-plan details.

### `spark.analytics`
- `build_summary(students)`: calculate totals, averages, distribution and health.
- `collect_warnings(students)`: return severity-ranked warning records.
- `anomaly_check(students)`: flag statistical outliers.
- `trend_lines(students)`: produce concise trend statements.

### `spark.exporters`
- `export_markdown(students)`, `export_text(students)`, and
  `export_csv(students)`: create timestamped reports.
- `export_all(students)`: create all supported report formats.

## Data and reliability contract

1. `data/students.json` is the source of truth and remains human-readable.
2. `data/students.csv` is a best-effort export/import format.
3. `data/students.db` is rebuildable and can be regenerated from JSON.
4. SQLite uses a primary key on `roll_no` and indexes for name, grade/section,
   status and fee status.
5. A failure to refresh a secondary mirror does not discard a successful JSON
   save; a warning is written to the audit log.
