#!/usr/bin/env python3
"""DataSpark Challenge Project #24 - Student ID Record Manager.

Entry point. Run with:

    python3 main.py

Standard library only. Python 3.10+.
"""

from __future__ import annotations

import sys

from spark.app import main

if __name__ == "__main__":
    sys.exit(main())
