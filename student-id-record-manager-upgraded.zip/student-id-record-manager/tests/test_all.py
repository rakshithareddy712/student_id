#!/usr/bin/env python3
"""End-to-end and unit tests. Standard library only.

Run:  python3 tests/test_all.py
Exit code 0 = all passed.
"""

from __future__ import annotations

import io
import json
import os
import shutil
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import date, timedelta
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from spark import analytics, config, exporters, storage, validation, sqlite_store  # noqa: E402
from spark.models import Student  # noqa: E402
from spark.repository import DuplicateRollError, NotFoundError, Repository  # noqa: E402


def make_student(roll="S9001", **kw) -> Student:
    base = dict(roll_no=roll, name="Test Student", grade="10", section="A",
                attendance=90.0, gpa=8.0, fee_status="Paid", status="Active")
    base.update(kw)
    return Student(**base)


# ==========================================================================
class TestValidation(unittest.TestCase):
    def _feed(self, *inputs):
        """Patch input() to return the given sequence."""
        return mock.patch("builtins.input", side_effect=list(inputs))

    def test_sanitize_strips_control_and_collapses_ws(self):
        self.assertEqual(validation.sanitize("  Aarav \t  Sharma \n"), "Aarav Sharma")
        self.assertEqual(validation.sanitize("bad\x00\x07text"), "badtext")
        self.assertEqual(validation.sanitize(None), "")

    def test_sanitize_truncates(self):
        self.assertEqual(len(validation.sanitize("x" * 500, max_len=10)), 10)

    def test_int_rejects_blank_then_accepts(self):
        with self._feed("", "abc", "999", "42"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_int("n", 1, 100), 42)

    def test_int_range_enforced(self):
        with self._feed("0", "101", "50"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_int("n", 1, 100), 50)

    def test_float_rejects_nan_and_inf(self):
        with self._feed("nan", "inf", "55.5"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_float("f", 0, 100), 55.5)

    def test_float_rounds(self):
        with self._feed("12.3456"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_float("f", 0, 100), 12.35)

    def test_choice_accepts_name_and_index(self):
        with self._feed("active"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_choice("s", config.VALID_STATUS), "Active")
        with self._feed("2"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_choice("s", config.VALID_STATUS), "Inactive")

    def test_choice_rejects_garbage(self):
        with self._feed("nonsense", "Paid"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_choice("s", config.VALID_FEE_STATUS), "Paid")

    def test_roll_normalises_and_validates(self):
        with self._feed("ab", "s-1001"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_roll(), "S-1001")

    def test_date_multiple_formats(self):
        for raw in ("2026-01-15", "15-01-2026", "15/01/2026"):
            with self._feed(raw):
                with redirect_stdout(io.StringIO()):
                    self.assertEqual(validation.ask_date("d"), date(2026, 1, 15))

    def test_date_rejects_future_when_disallowed(self):
        future = (date.today() + timedelta(days=30)).isoformat()
        with self._feed(future, "2020-01-01"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_date("d", allow_future=False), date(2020, 1, 1))

    def test_cancel_token_raises(self):
        with self._feed("q"):
            with redirect_stdout(io.StringIO()):
                with self.assertRaises(validation.Cancelled):
                    validation.ask_text("name")

    def test_eof_does_not_crash(self):
        with mock.patch("builtins.input", side_effect=EOFError):
            with redirect_stdout(io.StringIO()):
                with self.assertRaises(validation.Cancelled):
                    validation.ask_text("name")

    def test_yes_no(self):
        with self._feed("maybe", "y"):
            with redirect_stdout(io.StringIO()):
                self.assertTrue(validation.ask_yes_no("ok?"))

    def test_email_optional_and_validated(self):
        with self._feed(""):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_email(), "")
        with self._feed("bad", "a@b.co"):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(validation.ask_email(), "a@b.co")


# ==========================================================================
class TestModel(unittest.TestCase):
    def test_bands(self):
        self.assertEqual(make_student(attendance=50).attendance_band, "critical")
        self.assertEqual(make_student(attendance=70).attendance_band, "low")
        self.assertEqual(make_student(attendance=80).attendance_band, "ok")
        self.assertEqual(make_student(attendance=95).attendance_band, "high")

    def test_boundary_attendance_75_is_not_low(self):
        self.assertEqual(make_student(attendance=75.0).attendance_band, "ok")

    def test_boundary_gpa_4_is_not_risk(self):
        self.assertEqual(make_student(gpa=4.0).academic_band, "ok")

    def test_fee_overdue_days(self):
        past = (date.today() - timedelta(days=10)).isoformat()
        s = make_student(fee_status="Overdue", fee_due_date=past)
        self.assertEqual(s.fee_overdue_days, 10)
        self.assertTrue(s.is_fee_overdue)

    def test_paid_fee_never_overdue(self):
        past = (date.today() - timedelta(days=10)).isoformat()
        s = make_student(fee_status="Paid", fee_due_date=past)
        self.assertFalse(s.is_fee_overdue)

    def test_bad_fee_date_does_not_crash(self):
        s = make_student(fee_status="Overdue", fee_due_date="not-a-date")
        self.assertEqual(s.fee_overdue_days, 0)

    def test_from_dict_clamps_bad_numbers(self):
        s = Student.from_dict({"roll_no": "x1", "name": "A", "attendance": "999",
                               "gpa": "abc"})
        self.assertEqual(s.attendance, 100.0)
        self.assertEqual(s.gpa, 0.0)
        self.assertEqual(s.roll_no, "X1")

    def test_from_dict_handles_none(self):
        s = Student.from_dict({"roll_no": None, "name": None, "attendance": None})
        self.assertEqual(s.roll_no, "UNKNOWN")
        self.assertEqual(s.name, "Unnamed")

    def test_risk_score_bounds(self):
        self.assertEqual(make_student(attendance=100, gpa=10).risk_score, 0)
        self.assertLessEqual(make_student(attendance=0, gpa=0, status="Suspended").risk_score, 100)


# ==========================================================================
class TestStorage(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.json = self.tmp / "students.json"
        self.csv = self.tmp / "students.csv"

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_missing_file_creates_template(self):
        students, notices = storage.load_students(self.json)
        self.assertEqual(students, [])
        self.assertTrue(self.json.exists())
        self.assertTrue(any("No data file" in n for n in notices))

    def test_empty_file_recovers(self):
        self.json.write_text("", encoding="utf-8")
        students, notices = storage.load_students(self.json)
        self.assertEqual(students, [])
        self.assertTrue(any("empty" in n for n in notices))

    def test_invalid_json_recovers_and_backs_up(self):
        self.json.write_text("{not valid json", encoding="utf-8")
        students, notices = storage.load_students(self.json)
        self.assertEqual(students, [])
        self.assertTrue(any("invalid JSON" in n for n in notices))
        backups = list(config.BACKUP_DIR.glob("students_*.json"))
        self.assertTrue(backups, "expected a backup of the corrupt file")

    def test_wrong_top_level_type_recovers(self):
        self.json.write_text('"just a string"', encoding="utf-8")
        students, notices = storage.load_students(self.json)
        self.assertEqual(students, [])
        self.assertTrue(any("unexpected structure" in n for n in notices))

    def test_partial_corruption_skips_bad_rows(self):
        payload = {"students": [
            {"roll_no": "A1", "name": "Good"},
            "not a dict",
            {"roll_no": "A1", "name": "Duplicate"},
            {"roll_no": "A2", "name": "Also Good"},
        ]}
        self.json.write_text(json.dumps(payload), encoding="utf-8")
        students, notices = storage.load_students(self.json)
        self.assertEqual(len(students), 2)
        self.assertTrue(any("Skipped" in n for n in notices))

    def test_roundtrip(self):
        students = [make_student("R1"), make_student("R2", attendance=50)]
        storage.save_students(students, path=self.json, write_csv=False)
        loaded, _ = storage.load_students(self.json)
        self.assertEqual(len(loaded), 2)
        self.assertEqual(loaded[0].roll_no, "R1")

    def test_atomic_write_leaves_no_temp_files(self):
        storage.save_students([make_student()], path=self.json, write_csv=False)
        temps = list(self.tmp.glob(".tmp_*"))
        self.assertEqual(temps, [])

    def test_csv_import_valid(self):
        self.csv.write_text(
            "roll_no,name,attendance,gpa,fee_status,status\n"
            "C1,Alice,90,8.0,Paid,Active\n"
            "C2,Bob,70,3.0,Pending,Active\n",
            encoding="utf-8")
        students, errors = storage.load_csv(self.csv)
        self.assertEqual(len(students), 2)
        self.assertEqual(errors, [])

    def test_csv_import_reports_bad_rows(self):
        self.csv.write_text(
            "roll_no,name,attendance,gpa,fee_status,status\n"
            "C1,Alice,90,8.0,Paid,Active\n"
            ",NoRoll,90,8.0,Paid,Active\n"
            "C3,Carol,abc,8.0,Paid,Active\n"
            "C4,Dave,90,8.0,Bogus,Active\n"
            "C1,Duplicate,90,8.0,Paid,Active\n",
            encoding="utf-8")
        students, errors = storage.load_csv(self.csv)
        self.assertEqual(len(students), 1)
        self.assertEqual(len(errors), 4)
        reasons = " ".join(e["reason"] for e in errors)
        self.assertIn("missing roll_no", reasons)
        self.assertIn("not numeric", reasons)
        self.assertIn("invalid fee_status", reasons)
        self.assertIn("Duplicate", reasons)

    def test_csv_missing_columns(self):
        self.csv.write_text("foo,bar\n1,2\n", encoding="utf-8")
        students, errors = storage.load_csv(self.csv)
        self.assertEqual(students, [])
        self.assertIn("Missing required column", errors[0]["reason"])

    def test_csv_missing_file(self):
        students, errors = storage.load_csv(self.tmp / "nope.csv")
        self.assertEqual(students, [])
        self.assertIn("not found", errors[0]["reason"].lower())


# ==========================================================================
class TestRepository(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._orig_json = config.JSON_PATH
        self._orig_csv = config.CSV_PATH
        self._orig_sqlite = config.SQLITE_PATH
        config.JSON_PATH = self.tmp / "students.json"
        config.CSV_PATH = self.tmp / "students.csv"
        config.SQLITE_PATH = self.tmp / "students.db"
        self.repo = Repository()
        self.repo.load()

    def tearDown(self):
        config.JSON_PATH = self._orig_json
        config.CSV_PATH = self._orig_csv
        config.SQLITE_PATH = self._orig_sqlite
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_add_and_get(self):
        self.repo.add(make_student("A1"))
        self.assertEqual(self.repo.count(), 1)
        self.assertEqual(self.repo.get("a1").roll_no, "A1")

    def test_duplicate_raises(self):
        self.repo.add(make_student("A1"))
        with self.assertRaises(DuplicateRollError):
            self.repo.add(make_student("A1"))

    def test_not_found_raises(self):
        with self.assertRaises(NotFoundError):
            self.repo.get("ZZZ")

    def test_persistence_across_reload(self):
        self.repo.add(make_student("P1", name="Persisted"))
        fresh = Repository()
        fresh.load()
        self.assertEqual(fresh.count(), 1)
        self.assertEqual(fresh.get("P1").name, "Persisted")

    def test_update(self):
        self.repo.add(make_student("U1"))
        self.repo.update("U1", attendance=55.0)
        self.assertEqual(self.repo.get("U1").attendance, 55.0)

    def test_delete(self):
        self.repo.add(make_student("D1"))
        self.repo.delete("D1")
        self.assertEqual(self.repo.count(), 0)

    def test_search(self):
        self.repo.add(make_student("S1", name="Alice Wonder"))
        self.repo.add(make_student("S2", name="Bob Builder"))
        self.assertEqual(len(self.repo.search("alice")), 1)
        self.assertEqual(len(self.repo.search("builder")), 1)
        self.assertEqual(len(self.repo.search("")), 2)

    def test_filter(self):
        self.repo.add(make_student("F1", grade="10", attendance=50))
        self.repo.add(make_student("F2", grade="11", attendance=95))
        self.assertEqual(len(self.repo.filter_by(grade="10")), 1)
        self.assertEqual(len(self.repo.filter_by(min_attendance=90)), 1)
        self.assertEqual(len(self.repo.filter_by(has_warnings=True)), 1)

    def test_bulk_add_skips_duplicates(self):
        self.repo.add(make_student("B1"))
        added, skipped = self.repo.bulk_add([make_student("B1"), make_student("B2")])
        self.assertEqual(added, 1)
        self.assertEqual(len(skipped), 1)


# ==========================================================================
class TestAnalytics(unittest.TestCase):
    def test_empty_summary(self):
        s = analytics.build_summary([])
        self.assertEqual(s.total, 0)
        self.assertEqual(s.health_score, 0.0)

    def test_summary_math(self):
        students = [
            make_student("A", attendance=100, gpa=10),
            make_student("B", attendance=50, gpa=2),
        ]
        s = analytics.build_summary(students)
        self.assertEqual(s.total, 2)
        self.assertEqual(s.avg_attendance, 75.0)
        self.assertEqual(s.min_attendance, 50.0)
        self.assertEqual(s.max_attendance, 100.0)
        self.assertEqual(s.avg_gpa, 6.0)
        self.assertEqual(s.below_attendance_threshold, 1)
        self.assertEqual(s.below_gpa_threshold, 1)

    def test_health_score_range(self):
        students = [make_student(f"S{i}", attendance=90, gpa=8) for i in range(5)]
        s = analytics.build_summary(students)
        self.assertGreaterEqual(s.health_score, 0)
        self.assertLessEqual(s.health_score, 100)

    def test_warnings_collected(self):
        students = [make_student("W1", attendance=40, gpa=1.0, email="a@b.co")]
        warnings = analytics.collect_warnings(students)
        self.assertGreaterEqual(len(warnings), 2)
        self.assertTrue(all(w.severity == "critical" for w in warnings))

    def test_missing_email_is_info_not_critical(self):
        warnings = analytics.collect_warnings([make_student("W2", email="")])
        self.assertEqual(len(warnings), 1)
        self.assertEqual(warnings[0].severity, "info")

    def test_warnings_sorted_by_severity(self):
        students = [
            make_student("I1", attendance=90, gpa=8, email=""),   # info
            make_student("C1", attendance=30, gpa=1),             # critical
        ]
        warnings = analytics.collect_warnings(students)
        self.assertEqual(warnings[0].severity, "critical")

    def test_anomaly_detection(self):
        students = [make_student(f"A{i}", attendance=90) for i in range(10)]
        students.append(make_student("OUT", attendance=10))
        notes = analytics.anomaly_check(students)
        self.assertTrue(any("OUT" in n for n in notes))

    def test_trends_non_empty(self):
        self.assertTrue(analytics.trend_lines([]))
        self.assertTrue(analytics.trend_lines([make_student()]))


# ==========================================================================
class TestExporters(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._orig = config.EXPORT_DIR
        config.EXPORT_DIR = self.tmp
        self.students = [
            make_student("E1", name="Alice", attendance=95, gpa=9),
            make_student("E2", name="Bob", attendance=50, gpa=2, fee_status="Overdue",
                         fee_due_date=(date.today() - timedelta(days=20)).isoformat()),
        ]

    def tearDown(self):
        config.EXPORT_DIR = self._orig
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_markdown_export(self):
        p = exporters.export_markdown(self.students)
        self.assertTrue(p.exists())
        text = p.read_text(encoding="utf-8")
        self.assertIn("Executive Summary", text)
        self.assertIn("Alice", text)
        self.assertIn("Warning register", text)

    def test_text_export(self):
        p = exporters.export_text(self.students)
        self.assertTrue(p.exists())
        text = p.read_text(encoding="utf-8")
        self.assertIn("EXECUTIVE SUMMARY", text)
        self.assertIn("WARNING REGISTER", text)

    def test_csv_export(self):
        p = exporters.export_csv(self.students)
        self.assertTrue(p.exists())
        text = p.read_text(encoding="utf-8")
        self.assertIn("risk_score", text)
        self.assertIn("E1", text)

    def test_export_all(self):
        paths = exporters.export_all(self.students)
        self.assertEqual(set(paths), {"markdown", "text", "csv"})
        for p in paths.values():
            self.assertTrue(p.exists())


# ==========================================================================
class TestUI(unittest.TestCase):
    def test_visible_len_ignores_ansi(self):
        from spark import ui
        self.assertEqual(ui.visible_len("\033[31mred\033[0m"), 3)

    def test_pad_aligns_with_ansi(self):
        from spark import ui
        self.assertEqual(ui.visible_len(ui.pad("\033[31mab\033[0m", 10)), 10)

    def test_table_renders(self):
        from spark import ui
        cols = [ui.Column("A", "a", 5), ui.Column("B", "b", 5)]
        out = ui.render_table(cols, [{"a": "x", "b": "y"}])
        self.assertIn("x", out)
        self.assertIn("y", out)

    def test_table_empty(self):
        from spark import ui
        cols = [ui.Column("A", "a", 5)]
        out = ui.render_table(cols, [], empty_msg="nothing here")
        self.assertIn("nothing here", out)

    def test_pagination(self):
        from spark import ui
        cols = [ui.Column("A", "a", 5)]
        rows = [{"a": str(i)} for i in range(25)]
        body, page, total = ui.paginate(cols, rows, page=1, page_size=10)
        self.assertEqual(total, 3)
        self.assertEqual(page, 1)
        body, page, total = ui.paginate(cols, rows, page=99, page_size=10)
        self.assertEqual(page, 3)  # clamped

    def test_meter(self):
        from spark import ui
        self.assertIn("█", ui.meter(100))
        self.assertIn("░", ui.meter(0))


# ==========================================================================
class TestAppSmoke(unittest.TestCase):
    """Drive the real App through a scripted session."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._orig = (config.JSON_PATH, config.CSV_PATH, config.EXPORT_DIR,
                      config.AUDIT_LOG, config.BACKUP_DIR)
        config.JSON_PATH = self.tmp / "students.json"
        config.CSV_PATH = self.tmp / "students.csv"
        config.EXPORT_DIR = self.tmp / "exports"
        config.AUDIT_LOG = self.tmp / "exports" / "audit.log"
        config.BACKUP_DIR = self.tmp / "backups"
        for p in (config.EXPORT_DIR, config.BACKUP_DIR):
            p.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        (config.JSON_PATH, config.CSV_PATH, config.EXPORT_DIR,
         config.AUDIT_LOG, config.BACKUP_DIR) = self._orig
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _run(self, inputs):
        from spark.app import App
        app = App()
        with mock.patch("builtins.input", side_effect=list(inputs) + [EOFError] * 5):
            with redirect_stdout(io.StringIO()) as buf:
                app.run()
        return buf.getvalue()

    def test_full_session_add_then_persist(self):
        # start -> pause -> add record (with bad inputs) -> pause -> exit
        inputs = [
            "",                      # startup pause
            "1",                     # add
            "S7777",                 # roll
            "Test Person",           # name
            "10",                    # grade
            "A",                     # section
            "",                      # email
            "",                      # phone
            "abc", "150", "88.5",    # attendance: bad, out of range, good
            "xyz", "7.5",            # gpa: bad, good
            "Paid",                  # fee
            "Active",                # status
            "",                      # notes
            "",                      # pause after add
            "0",                     # exit
        ]
        out = self._run(inputs)
        self.assertIn("Saved S7777", out)
        # persisted?
        data = json.loads(config.JSON_PATH.read_text(encoding="utf-8"))
        self.assertEqual(data["meta"]["count"], 1)
        self.assertEqual(data["students"][0]["roll_no"], "S7777")

    def test_duplicate_roll_rejected(self):
        inputs = [
            "", "1", "S100", "First", "10", "A", "", "", "90", "8", "Paid", "Active", "",
            "", "1", "S100", "q", "", "0",
        ]
        out = self._run(inputs)
        self.assertIn("already taken", out)

    def test_cancel_add(self):
        inputs = ["", "1", "q", "", "0"]
        out = self._run(inputs)
        self.assertIn("cancelled", out.lower())

    def test_summary_screen(self):
        inputs = ["", "8", "", "0"]
        out = self._run(inputs)
        self.assertIn("EXECUTIVE SUMMARY", out)

    def test_export_screen(self):
        # seed one record so the export has something to write
        storage.save_students([make_student("X1")], path=config.JSON_PATH, write_csv=False)
        inputs = ["", "10", "4", "", "0"]
        out = self._run(inputs)
        self.assertIn("markdown", out.lower())
        self.assertTrue(list(config.EXPORT_DIR.glob("summary_*.md")))

    def test_warning_screen(self):
        inputs = ["", "9", "", "0"]
        out = self._run(inputs)
        self.assertIn("WARNING REGISTER", out)

    def test_garbage_menu_input_does_not_crash(self):
        inputs = ["", "abc", "99", "-1", "0"]
        out = self._run(inputs)
        self.assertIn("MAIN MENU", out)

    def test_corrupt_json_startup_recovers(self):
        config.JSON_PATH.write_text("{{{ broken", encoding="utf-8")
        inputs = ["", "0"]
        out = self._run(inputs)
        self.assertIn("invalid JSON", out)
        # file was rewritten as valid
        json.loads(config.JSON_PATH.read_text(encoding="utf-8"))


# ==========================================================================
def main() -> int:
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    print()
    print("=" * 60)
    print(f"Tests run: {result.testsRun}  "
          f"Failures: {len(result.failures)}  Errors: {len(result.errors)}")
    print("=" * 60)
    return 0 if result.wasSuccessful() else 1




class TestSQLiteIndex(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.db = self.tmp / "students.db"

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_indexed_roll_lookup_and_name_search(self):
        students = [make_student("DB1", name="Asha Rao"),
                    make_student("DB2", name="Arjun Das")]
        sqlite_store.replace_all(students, self.db)
        self.assertEqual(sqlite_store.get_by_roll("db1", self.db).name, "Asha Rao")
        self.assertEqual(len(sqlite_store.search_name("As", path=self.db)), 1)
        plan = " ".join(sqlite_store.explain_roll_lookup(self.db)).upper()
        self.assertIn("USING INDEX", plan)

    def test_replace_all_removes_stale_records(self):
        sqlite_store.replace_all([make_student("OLD")], self.db)
        sqlite_store.replace_all([make_student("NEW")], self.db)
        self.assertIsNone(sqlite_store.get_by_roll("OLD", self.db))
        self.assertIsNotNone(sqlite_store.get_by_roll("NEW", self.db))


if __name__ == "__main__":
    sys.exit(main())
