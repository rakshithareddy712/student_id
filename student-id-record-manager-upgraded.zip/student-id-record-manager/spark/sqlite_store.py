"""Indexed SQLite read model mirrored from the canonical JSON roster.

JSON remains the portable source of truth; SQLite is rebuilt transactionally
after successful JSON saves. It adds indexed lookup for larger rosters.
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Sequence

from . import config
from .models import Student


def connect(path: Path | None = None) -> sqlite3.Connection:
    """Open the local database and ensure schema/indexes exist."""
    db_path = path or config.SQLITE_PATH
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS students (
            roll_no TEXT PRIMARY KEY COLLATE NOCASE,
            name TEXT NOT NULL,
            grade TEXT NOT NULL,
            section TEXT NOT NULL,
            status TEXT NOT NULL,
            fee_status TEXT NOT NULL,
            attendance REAL NOT NULL,
            gpa REAL NOT NULL,
            payload TEXT NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_students_name ON students(name COLLATE NOCASE)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_students_grade_section ON students(grade, section)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_students_status ON students(status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_students_fee_status ON students(fee_status)")
    return conn


def replace_all(students: Sequence[Student], path: Path | None = None) -> None:
    """Atomically replace the indexed mirror with the supplied roster."""
    with connect(path) as conn:
        conn.execute("DELETE FROM students")
        conn.executemany(
            """INSERT INTO students
               (roll_no,name,grade,section,status,fee_status,attendance,gpa,payload)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            [(s.roll_no, s.name, s.grade, s.section, s.status, s.fee_status,
              s.attendance, s.gpa, json.dumps(s.to_dict(), ensure_ascii=False))
             for s in students],
        )


def get_by_roll(roll_no: str, path: Path | None = None) -> Student | None:
    """Fetch one student using the primary-key index."""
    with connect(path) as conn:
        row = conn.execute(
            "SELECT payload FROM students WHERE roll_no = ?", (roll_no.strip().upper(),)
        ).fetchone()
    return Student.from_dict(json.loads(row["payload"])) if row else None


def search_name(prefix: str, limit: int = 50, path: Path | None = None) -> list[Student]:
    """Find names by case-insensitive prefix using the name index."""
    safe_limit = max(1, min(int(limit), 500))
    with connect(path) as conn:
        rows = conn.execute(
            "SELECT payload FROM students WHERE name LIKE ? COLLATE NOCASE "
            "ORDER BY name LIMIT ?", (prefix.strip() + "%", safe_limit)
        ).fetchall()
    return [Student.from_dict(json.loads(row["payload"])) for row in rows]


def explain_roll_lookup(path: Path | None = None) -> list[str]:
    """Return SQLite's query plan, useful for demonstrating index usage."""
    with connect(path) as conn:
        rows = conn.execute(
            "EXPLAIN QUERY PLAN SELECT * FROM students WHERE roll_no = ?", ("DEMO",)
        ).fetchall()
    return [str(row["detail"]) for row in rows]
