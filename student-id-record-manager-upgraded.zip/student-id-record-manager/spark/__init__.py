"""DataSpark Challenge Project #24 - Student ID Record Manager.

A zero-dependency, standard-library-only campus administration tool.
"""

__version__ = "1.0.0"
__project__ = "Student ID Record Manager"
