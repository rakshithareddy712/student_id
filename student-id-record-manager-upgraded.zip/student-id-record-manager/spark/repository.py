"""Business logic engine: the in-memory roster and all record operations.

The repository owns the list of Students and is the single place that
mutates it. Every mutation persists immediately and writes an audit entry,
so the on-disk state is always consistent with memory.
"""

from __future__ import annotations

from collections import Counter
from typing import Callable, Iterable, Sequence

from . import config, storage
from .models import Student


class DuplicateRollError(Exception):
    pass


class NotFoundError(Exception):
    pass


class Repository:
    def __init__(self) -> None:
        self._students: dict[str, Student] = {}
        self.notices: list[str] = []

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def load(self) -> list[str]:
        students, notices = storage.load_students()
        self._students = {s.roll_no: s for s in students}
        self.notices = notices
        return notices

    def save(self) -> None:
        storage.save_students(self.all())

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------
    def all(self) -> list[Student]:
        return sorted(self._students.values(), key=lambda s: s.roll_no)

    def count(self) -> int:
        return len(self._students)

    def get(self, roll_no: str) -> Student:
        key = roll_no.strip().upper()
        if key not in self._students:
            raise NotFoundError(f"No student with roll number '{roll_no}'.")
        return self._students[key]

    def exists(self, roll_no: str) -> bool:
        return roll_no.strip().upper() in self._students

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------
    def add(self, student: Student) -> Student:
        if student.roll_no in self._students:
            raise DuplicateRollError(f"Roll number '{student.roll_no}' already exists.")
        student.touch()
        self._students[student.roll_no] = student
        self.save()
        storage.audit("ADD", f"{student.roll_no} | {student.name}")
        return student

    def update(self, roll_no: str, **changes) -> Student:
        student = self.get(roll_no)
        for key, value in changes.items():
            if hasattr(student, key) and value is not None:
                setattr(student, key, value)
        student.touch()
        self.save()
        storage.audit("UPDATE", f"{student.roll_no} | fields={','.join(changes)}")
        return student

    def delete(self, roll_no: str) -> Student:
        student = self.get(roll_no)
        del self._students[student.roll_no]
        self.save()
        storage.audit("DELETE", f"{student.roll_no} | {student.name}")
        return student

    def bulk_add(self, students: Sequence[Student]) -> tuple[int, list[str]]:
        """Add many records, skipping duplicates. Returns (added, skipped_reasons)."""
        added = 0
        skipped: list[str] = []
        for s in students:
            if s.roll_no in self._students:
                skipped.append(f"{s.roll_no}: duplicate roll number")
                continue
            s.touch()
            self._students[s.roll_no] = s
            added += 1
        if added:
            self.save()
            storage.audit("BULK_IMPORT", f"added={added} skipped={len(skipped)}")
        return added, skipped

    # ------------------------------------------------------------------
    # Search & filter
    # ------------------------------------------------------------------
    def search(self, keyword: str) -> list[Student]:
        """Case-insensitive keyword search across roll, name, grade, section, email, notes."""
        kw = keyword.strip().lower()
        if not kw:
            return self.all()
        fields = ("roll_no", "name", "grade", "section", "email", "notes", "status", "fee_status")
        out = []
        for s in self.all():
            haystack = " ".join(str(getattr(s, f, "")) for f in fields).lower()
            if kw in haystack:
                out.append(s)
        return out

    def filter_by(
        self,
        *,
        grade: str | None = None,
        section: str | None = None,
        status: str | None = None,
        fee_status: str | None = None,
        min_attendance: float | None = None,
        max_attendance: float | None = None,
        min_gpa: float | None = None,
        max_gpa: float | None = None,
        has_warnings: bool | None = None,
        predicate: Callable[[Student], bool] | None = None,
    ) -> list[Student]:
        out: list[Student] = []
        for s in self.all():
            if grade is not None and s.grade != grade:
                continue
            if section is not None and s.section.upper() != section.upper():
                continue
            if status is not None and s.status != status:
                continue
            if fee_status is not None and s.fee_status != fee_status:
                continue
            if min_attendance is not None and s.attendance < min_attendance:
                continue
            if max_attendance is not None and s.attendance > max_attendance:
                continue
            if min_gpa is not None and s.gpa < min_gpa:
                continue
            if max_gpa is not None and s.gpa > max_gpa:
                continue
            if has_warnings is not None and bool(s.warnings) != has_warnings:
                continue
            if predicate is not None and not predicate(s):
                continue
            out.append(s)
        return out

    def flagged(self) -> list[Student]:
        """Records with at least one warning, worst risk first."""
        return sorted(
            [s for s in self.all() if s.warnings],
            key=lambda s: s.risk_score,
            reverse=True,
        )

    # ------------------------------------------------------------------
    # Aggregates
    # ------------------------------------------------------------------
    def distinct(self, field: str) -> list[str]:
        values = {str(getattr(s, field, "")).strip() for s in self.all()}
        return sorted(v for v in values if v)

    def grade_counts(self) -> Counter:
        return Counter(s.grade for s in self.all())

    def status_counts(self) -> Counter:
        return Counter(s.status for s in self.all())

    def fee_counts(self) -> Counter:
        return Counter(s.fee_status for s in self.all())
