"""Central configuration: branding, paths, thresholds and colour palette."""

from __future__ import annotations

import os
from pathlib import Path

# --------------------------------------------------------------------------
# Branding
# --------------------------------------------------------------------------
APP_NAME = "DataSpark"
PROJECT_NAME = "Student ID Record Manager"
PROJECT_CODE = "Challenge Project #24"
DOMAIN = "Campus & Administration"
VERSION = "1.0.0"
TAGLINE = "Every student, one clean record."

# --------------------------------------------------------------------------
# Paths (all resolved relative to the project root, never the CWD)
# --------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
EXPORT_DIR = BASE_DIR / "exports"
JSON_PATH = DATA_DIR / "students.json"
CSV_PATH = DATA_DIR / "students.csv"
SQLITE_PATH = DATA_DIR / "students.db"
AUDIT_LOG = EXPORT_DIR / "audit.log"
BACKUP_DIR = DATA_DIR / "backups"

for _d in (DATA_DIR, EXPORT_DIR, BACKUP_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------
# Business thresholds (used by the warning engine)
# --------------------------------------------------------------------------
MIN_ATTENDANCE = 75.0          # below this -> attendance warning
CRITICAL_ATTENDANCE = 60.0     # below this -> critical
MIN_GPA = 4.0                  # below this -> academic risk
CRITICAL_GPA = 2.5
MAX_GPA = 10.0
FEE_OVERDUE_GRACE_DAYS = 0     # days past due before flagging

# --------------------------------------------------------------------------
# Valid enumerations
# --------------------------------------------------------------------------
VALID_STATUS = ("Active", "Inactive", "Graduated", "Suspended")
VALID_FEE_STATUS = ("Paid", "Pending", "Overdue", "Waived")
VALID_GRADES = tuple(str(n) for n in range(1, 13))  # 1..12

# --------------------------------------------------------------------------
# UI
# --------------------------------------------------------------------------
PAGE_SIZE = 10
TABLE_WIDTH = 100

# ANSI palette. Disabled automatically when NO_COLOR is set or output is piped.
_COLOR_ENABLED = (
    os.environ.get("NO_COLOR") is None
    and os.environ.get("TERM") != "dumb"
    and (os.environ.get("FORCE_COLOR") is not None or os.isatty(1))
)


class C:
    """ANSI escape helpers. All attributes are empty strings when colour is off."""

    RESET = "\033[0m" if _COLOR_ENABLED else ""
    BOLD = "\033[1m" if _COLOR_ENABLED else ""
    DIM = "\033[2m" if _COLOR_ENABLED else ""
    ITALIC = "\033[3m" if _COLOR_ENABLED else ""
    UNDERLINE = "\033[4m" if _COLOR_ENABLED else ""

    BLACK = "\033[30m" if _COLOR_ENABLED else ""
    RED = "\033[31m" if _COLOR_ENABLED else ""
    GREEN = "\033[32m" if _COLOR_ENABLED else ""
    YELLOW = "\033[33m" if _COLOR_ENABLED else ""
    BLUE = "\033[34m" if _COLOR_ENABLED else ""
    MAGENTA = "\033[35m" if _COLOR_ENABLED else ""
    CYAN = "\033[36m" if _COLOR_ENABLED else ""
    WHITE = "\033[37m" if _COLOR_ENABLED else ""
    GREY = "\033[90m" if _COLOR_ENABLED else ""

    BG_BLUE = "\033[44m" if _COLOR_ENABLED else ""
    BG_CYAN = "\033[46m" if _COLOR_ENABLED else ""
    BG_RED = "\033[41m" if _COLOR_ENABLED else ""
    BG_GREEN = "\033[42m" if _COLOR_ENABLED else ""
    BG_YELLOW = "\033[43m" if _COLOR_ENABLED else ""


def color_enabled() -> bool:
    return _COLOR_ENABLED
