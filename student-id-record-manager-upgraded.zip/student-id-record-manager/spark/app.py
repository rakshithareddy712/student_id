"""Interactive terminal application: menus, workflows and screens."""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

from . import analytics, charts, config, exporters, storage, ui, validation
from .config import C
from .models import Student
from .repository import DuplicateRollError, NotFoundError, Repository
from .validation import Cancelled

MENU = [
    ("1", "Add a new student record", "guided form with live validation"),
    ("2", "View all records", "paginated roster table"),
    ("3", "Search records", "keyword search across all fields"),
    ("4", "Filter records", "by grade, status, attendance, GPA, warnings"),
    ("5", "View one student", "look up by roll number"),
    ("6", "Edit a record", "update fields on an existing student"),
    ("7", "Delete a record", "remove a student (with confirmation)"),
    ("8", "Executive summary", "totals, averages, trends and health score"),
    ("9", "Warning register", "threshold breaches and anomalies"),
    ("10", "Export reports", "Markdown, plain text and CSV"),
    ("11", "Generate charts", "PNG charts (ASCII fallback)"),
    ("12", "Import legacy CSV", "bulk import with row-by-row error log"),
    ("0", "Exit", "save and quit"),
]


# ==========================================================================
# Table column definitions
# ==========================================================================
def roster_columns() -> list[ui.Column]:
    return [
        ui.Column("ROLL", "roll_no", 10),
        ui.Column("NAME", "name", 22),
        ui.Column("GR", "grade", 4, "center"),
        ui.Column("SEC", "section", 4, "center"),
        ui.Column("ATT%", "attendance", 7, "right",
                  lambda v, r: _att_cell(v)),
        ui.Column("GPA", "gpa", 6, "right", lambda v, r: _gpa_cell(v)),
        ui.Column("FEES", "fee_status", 9),
        ui.Column("STATUS", "status", 10),
        ui.Column("FLAGS", "roll_no", 8, "center",
                  lambda v, r: _flag_cell(r)),
    ]


def _att_cell(v) -> str:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if f < config.CRITICAL_ATTENDANCE:
        return f"{C.RED}{f:>6.1f}{C.RESET}"
    if f < config.MIN_ATTENDANCE:
        return f"{C.YELLOW}{f:>6.1f}{C.RESET}"
    return f"{f:>6.1f}"


def _gpa_cell(v) -> str:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if f < config.CRITICAL_GPA:
        return f"{C.RED}{f:>5.2f}{C.RESET}"
    if f < config.MIN_GPA:
        return f"{C.YELLOW}{f:>5.2f}{C.RESET}"
    return f"{f:>5.2f}"


def _flag_cell(row: dict) -> str:
    n = row.get("_flag_count", 0)
    if not n:
        return f"{C.GREEN}·{C.RESET}"
    if row.get("_critical"):
        return f"{C.RED}▲{n}{C.RESET}"
    return f"{C.YELLOW}▲{n}{C.RESET}"


def _decorate(students) -> list[dict]:
    rows = []
    for s in students:
        d = s.to_dict()
        d["_flag_count"] = len(s.warnings)
        d["_critical"] = s.risk_score >= 60
        rows.append(d)
    return rows


# ==========================================================================
# Application
# ==========================================================================
class App:
    def __init__(self) -> None:
        self.repo = Repository()
        self.running = True

    # ------------------------------------------------------------------
    # Startup
    # ------------------------------------------------------------------
    def start(self) -> None:
        ui.clear()
        print(ui.banner())
        # load() already creates clean templates for missing/corrupt files and
        # reports what it did, so we do not pre-create them here.
        notices = self.repo.load()
        notices += storage.ensure_templates()
        for n in notices:
            print(ui.warn(n))
        if notices:
            print()
        print(ui.info(f"Loaded {self.repo.count()} record(s) from "
                      f"{config.JSON_PATH.name}."))
        print(ui.info(f"Data directory: {config.DATA_DIR}"))
        print()
        validation.pause("Press Enter to open the main menu…")

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------
    def run(self) -> None:
        self.start()
        while self.running:
            try:
                self.main_menu()
            except Cancelled:
                self.running = False
            except KeyboardInterrupt:
                print()
                self.running = False
            except Exception as exc:  # last-resort guard: never crash the loop
                print()
                print(ui.err(f"Unexpected error: {exc.__class__.__name__}: {exc}"))
                print(ui.info("Your data is safe. Returning to the main menu."))
                validation.pause()
        self.shutdown()

    def shutdown(self) -> None:
        try:
            self.repo.save()
        except Exception:
            pass
        print()
        print(ui.box("Session closed", [
            f"Records saved: {self.repo.count()}",
            f"Data file:     {config.JSON_PATH}",
            f"Audit log:     {config.AUDIT_LOG}",
            "",
            f"{C.CYAN}Thanks for using {config.APP_NAME}.{C.RESET}",
        ]))
        print()

    # ------------------------------------------------------------------
    # Menu
    # ------------------------------------------------------------------
    def main_menu(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("MAIN MENU"))
        print()
        for key, label, hint in MENU:
            key_s = f"{C.BOLD}{C.CYAN}{key:>2}{C.RESET}"
            print(f"  {key_s}  {ui.pad(label, 30)}{C.GREY}{hint}{C.RESET}")
        print()
        print(f"  {C.GREY}Records: {self.repo.count()} · "
              f"Flagged: {len(self.repo.flagged())}{C.RESET}")
        print()
        choice = validation.ask_menu("Select an option", 0, 12)
        handlers = {
            1: self.add_record,
            2: self.view_all,
            3: self.search_records,
            4: self.filter_records,
            5: self.view_one,
            6: self.edit_record,
            7: self.delete_record,
            8: self.executive_summary,
            9: self.warning_register,
            10: self.export_reports,
            11: self.generate_charts,
            12: self.import_csv,
            0: self.exit_app,
        }
        handler = handlers.get(choice)
        if handler:
            handler()

    def exit_app(self) -> None:
        self.running = False

    # ------------------------------------------------------------------
    # 1. Add
    # ------------------------------------------------------------------
    def add_record(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("ADD STUDENT RECORD"))
        print(f"  {C.GREY}Step 1 of 3 · Identity{C.RESET}")
        print(f"  {C.GREY}Type 'q' at any prompt to cancel.{C.RESET}")
        print()
        try:
            roll = self._ask_unique_roll()
            name = validation.ask_text("Full name", min_len=2, max_len=60, field="Name")
            grade = validation.ask_choice("Grade (1-12)", config.VALID_GRADES, field="Grade")
            section = validation.ask_text("Section", min_len=1, max_len=3, field="Section").upper()

            print()
            print(f"  {C.GREY}Step 2 of 3 · Contact{C.RESET}")
            email = validation.ask_email("Email (optional, Enter to skip)", default="")
            phone = self._ask_optional("Phone (optional, Enter to skip)", 20)

            print()
            print(f"  {C.GREY}Step 3 of 3 · Academic & fees{C.RESET}")
            attendance = validation.ask_float("Attendance % (0-100)", 0, 100,
                                              field="Attendance", default="100")
            gpa = validation.ask_float(f"GPA (0-{config.MAX_GPA:g})", 0, config.MAX_GPA,
                                       field="GPA", default="0")
            fee_status = validation.ask_choice("Fee status", config.VALID_FEE_STATUS,
                                               field="Fee status", default="Paid")
            fee_due = ""
            if fee_status in ("Pending", "Overdue"):
                d = validation.ask_date("Fee due date (YYYY-MM-DD)", field="Fee due date",
                                        allow_future=True, allow_past=True)
                fee_due = d.isoformat()
            status = validation.ask_choice("Enrolment status", config.VALID_STATUS,
                                           field="Status", default="Active")
            notes = self._ask_optional("Notes (optional)", 120)

            student = Student(
                roll_no=roll, name=name, grade=grade, section=section,
                email=email, phone=phone, attendance=attendance, gpa=gpa,
                fee_status=fee_status, fee_due_date=fee_due, status=status,
                notes=notes, enrolled_on=date.today().isoformat(),
            )
            self.repo.add(student)
        except Cancelled:
            print()
            print(ui.warn("Add cancelled - nothing was saved."))
            validation.pause()
            return
        except DuplicateRollError as exc:
            print(ui.err(str(exc)))
            validation.pause()
            return

        print()
        print(ui.ok(f"Saved {student.roll_no} · {student.name}"))
        if student.warnings:
            for w in student.warnings:
                print(ui.warn(w))
        print(ui.info(f"Roster now holds {self.repo.count()} record(s)."))
        validation.pause()

    def _ask_unique_roll(self) -> str:
        while True:
            roll = validation.ask_roll("Roll number (e.g. S1001)")
            if self.repo.exists(roll):
                print(ui.err(f"Roll number '{roll}' is already taken. Try another."))
                continue
            return roll

    def _ask_optional(self, label: str, max_len: int) -> str:
        """Optional free-text field: blank is allowed."""
        def check(value: str):
            if len(value) > max_len:
                return False, f"Must be at most {max_len} characters.", None
            return True, "", value
        return validation.ask(label, validator=check, default="")  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # 2. View all
    # ------------------------------------------------------------------
    def view_all(self) -> None:
        students = self.repo.all()
        self._paged_view(students, "ALL RECORDS")

    def _paged_view(self, students, title: str) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section(title))
        print()
        if not students:
            print(ui.warn("No records match."))
            validation.pause()
            return
        rows = _decorate(students)
        page = 1
        while True:
            ui.clear()
            print(ui.banner())
            body, page, total = ui.paginate(roster_columns(), rows, page=page,
                                            title=title)
            print(body)
            print()
            print(f"  {C.GREY}n = next · p = previous · f = first · l = last · "
                  f"q = back{C.RESET}")
            try:
                cmd = input(f"{C.CYAN}▸{C.RESET} Page [{page}/{total}]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                return
            if cmd in ("q", "", "b", "back"):
                return
            if cmd in ("n", "next"):
                page = min(total, page + 1)
            elif cmd in ("p", "prev", "previous"):
                page = max(1, page - 1)
            elif cmd in ("f", "first"):
                page = 1
            elif cmd in ("l", "last"):
                page = total
            elif cmd.isdigit():
                page = max(1, min(total, int(cmd)))

    # ------------------------------------------------------------------
    # 3. Search
    # ------------------------------------------------------------------
    def search_records(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("SEARCH RECORDS"))
        print(f"  {C.GREY}Matches roll, name, grade, section, email, notes, "
              f"status and fee status.{C.RESET}")
        print()
        try:
            kw = validation.ask_text("Search keyword", min_len=1, max_len=60,
                                     field="Keyword")
        except Cancelled:
            return
        results = self.repo.search(kw)
        print()
        print(ui.info(f"{len(results)} match(es) for '{kw}'."))
        validation.pause()
        self._paged_view(results, f"SEARCH: {kw}")

    # ------------------------------------------------------------------
    # 4. Filter
    # ------------------------------------------------------------------
    def filter_records(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("FILTER RECORDS"))
        print(f"  {C.GREY}Press Enter to skip any filter.{C.RESET}")
        print()
        try:
            grade = self._optional_choice("Grade", self.repo.distinct("grade"))
            section = self._optional_choice("Section", self.repo.distinct("section"))
            status = self._optional_choice("Status", list(config.VALID_STATUS))
            fee = self._optional_choice("Fee status", list(config.VALID_FEE_STATUS))

            print()
            min_att = self._optional_float("Minimum attendance %", 0, 100)
            max_att = self._optional_float("Maximum attendance %", 0, 100)
            min_gpa = self._optional_float(f"Minimum GPA (0-{config.MAX_GPA:g})", 0, config.MAX_GPA)
            max_gpa = self._optional_float(f"Maximum GPA (0-{config.MAX_GPA:g})", 0, config.MAX_GPA)

            print()
            only_flagged = validation.ask_yes_no("Only records with warnings?", default="n")
        except Cancelled:
            return

        results = self.repo.filter_by(
            grade=grade, section=section, status=status, fee_status=fee,
            min_attendance=min_att, max_attendance=max_att,
            min_gpa=min_gpa, max_gpa=max_gpa,
            has_warnings=True if only_flagged else None,
        )
        print()
        print(ui.info(f"{len(results)} record(s) match your filters."))
        validation.pause()
        self._paged_view(results, "FILTERED RESULTS")

    def _optional_choice(self, label: str, options) -> str | None:
        if not options:
            return None
        print(f"  {C.GREY}Available: {', '.join(options)}{C.RESET}")
        def check(value: str):
            if value == "":
                return True, "", None
            return validation._v_choice(options, label)(value)
        return validation.ask(label, validator=check, default="")  # type: ignore[return-value]

    def _optional_float(self, label: str, lo: float, hi: float) -> float | None:
        def check(value: str):
            if value == "":
                return True, "", None
            return validation._v_float(lo, hi, label)(value)
        return validation.ask(label, validator=check, default="")  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # 5. View one
    # ------------------------------------------------------------------
    def view_one(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("STUDENT DETAIL"))
        print()
        try:
            roll = validation.ask_roll("Roll number")
        except Cancelled:
            return
        try:
            s = self.repo.get(roll)
        except NotFoundError as exc:
            print(ui.err(str(exc)))
            validation.pause()
            return
        self._print_detail(s)
        validation.pause()

    def _print_detail(self, s: Student) -> None:
        print()
        risk_kind = "crit" if s.risk_score >= 60 else ("warn" if s.warnings else "ok")
        print(f"  {C.BOLD}{C.WHITE}{s.name}{C.RESET}  "
              f"{ui.badge(s.status, 'info')}  {ui.badge(f'risk {s.risk_score}', risk_kind)}")
        print()
        print(ui.kv_block([
            ("Roll number", s.roll_no),
            ("Grade / Section", f"{s.grade} / {s.section}"),
            ("Email", s.email or f"{C.GREY}—{C.RESET}"),
            ("Phone", s.phone or f"{C.GREY}—{C.RESET}"),
            ("Attendance", f"{s.attendance:.1f}%  {ui.meter(s.attendance)}"),
            ("GPA", f"{s.gpa:.2f} / {config.MAX_GPA:g}"),
            ("Fee status", s.fee_status + (f"  ({s.fee_overdue_days}d overdue)"
                                           if s.is_fee_overdue else "")),
            ("Fee due date", s.fee_due_date or f"{C.GREY}—{C.RESET}"),
            ("Enrolled on", s.enrolled_on),
            ("Last updated", s.updated_at),
            ("Notes", s.notes or f"{C.GREY}—{C.RESET}"),
        ]))
        print()
        if s.warnings:
            print(f"  {C.BOLD}Warnings{C.RESET}")
            for w in s.warnings:
                print(f"    {ui.warn(w)}")
        else:
            print(f"  {ui.ok('No warnings - record is healthy.')}")

    # ------------------------------------------------------------------
    # 6. Edit
    # ------------------------------------------------------------------
    def edit_record(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("EDIT RECORD"))
        print()
        try:
            roll = validation.ask_roll("Roll number to edit")
            s = self.repo.get(roll)
        except Cancelled:
            return
        except NotFoundError as exc:
            print(ui.err(str(exc)))
            validation.pause()
            return

        self._print_detail(s)
        print()
        print(f"  {C.GREY}Press Enter to keep the current value.{C.RESET}")
        print()
        changes: dict = {}
        try:
            name = validation.ask_text("Name", min_len=2, max_len=60, field="Name",
                                       default=s.name)
            if name != s.name:
                changes["name"] = name

            grade = validation.ask_choice("Grade", config.VALID_GRADES, field="Grade",
                                          default=s.grade)
            if grade != s.grade:
                changes["grade"] = grade

            section = validation.ask_text("Section", min_len=1, max_len=3,
                                          field="Section", default=s.section).upper()
            if section != s.section:
                changes["section"] = section

            email = validation.ask_email("Email", default=s.email)
            if email != s.email:
                changes["email"] = email

            att = validation.ask_float("Attendance %", 0, 100, field="Attendance",
                                       default=f"{s.attendance:g}")
            if att != s.attendance:
                changes["attendance"] = att

            gpa = validation.ask_float(f"GPA (0-{config.MAX_GPA:g})", 0, config.MAX_GPA,
                                       field="GPA", default=f"{s.gpa:g}")
            if gpa != s.gpa:
                changes["gpa"] = gpa

            fee = validation.ask_choice("Fee status", config.VALID_FEE_STATUS,
                                        field="Fee status", default=s.fee_status)
            if fee != s.fee_status:
                changes["fee_status"] = fee

            status = validation.ask_choice("Enrolment status", config.VALID_STATUS,
                                           field="Status", default=s.status)
            if status != s.status:
                changes["status"] = status

            notes = self._ask_optional(f"Notes [{s.notes or 'empty'}]", 120)
            if notes and notes != s.notes:
                changes["notes"] = notes
        except Cancelled:
            print()
            print(ui.warn("Edit cancelled - no changes saved."))
            validation.pause()
            return

        if not changes:
            print()
            print(ui.info("No changes made."))
            validation.pause()
            return

        print()
        print(f"  {C.BOLD}Pending changes:{C.RESET}")
        for k, v in changes.items():
            print(f"    {C.GREY}{k}{C.RESET}: {getattr(s, k)} → {C.GREEN}{v}{C.RESET}")
        if not validation.ask_yes_no("Apply these changes?", default="y"):
            print(ui.warn("Discarded."))
            validation.pause()
            return

        self.repo.update(roll, **changes)
        print(ui.ok(f"Updated {roll} ({len(changes)} field(s))."))
        validation.pause()

    # ------------------------------------------------------------------
    # 7. Delete
    # ------------------------------------------------------------------
    def delete_record(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("DELETE RECORD"))
        print()
        try:
            roll = validation.ask_roll("Roll number to delete")
            s = self.repo.get(roll)
        except Cancelled:
            return
        except NotFoundError as exc:
            print(ui.err(str(exc)))
            validation.pause()
            return

        self._print_detail(s)
        print()
        print(ui.warn("This permanently removes the record from the roster."))
        if not validation.ask_yes_no(f"Delete {s.roll_no} · {s.name}?", default="n"):
            print(ui.info("Cancelled - record kept."))
            validation.pause()
            return
        self.repo.delete(roll)
        print(ui.ok(f"Deleted {roll}."))
        validation.pause()

    # ------------------------------------------------------------------
    # 8. Executive summary
    # ------------------------------------------------------------------
    def executive_summary(self) -> None:
        students = self.repo.all()
        ui.clear()
        print(ui.banner())
        print(ui.section("EXECUTIVE SUMMARY"))
        print()
        if not students:
            print(ui.warn("No records yet - add students first."))
            validation.pause()
            return

        s = analytics.build_summary(students)
        health_kind = ("ok" if s.health_score >= 85 else
                       "info" if s.health_score >= 70 else
                       "warn" if s.health_score >= 55 else "crit")

        print(f"  {C.BOLD}Roster health{C.RESET}  "
              f"{ui.badge(f'{s.health_score}/100 · {s.health_label}', health_kind)}")
        print()

        # KPI table
        kpi_cols = [
            ui.Column("METRIC", "metric", 26),
            ui.Column("VALUE", "value", 14, "right"),
            ui.Column("STATUS", "status", 18),
        ]
        kpi_rows = [
            {"metric": "Total records", "value": s.total, "status": ""},
            {"metric": "Active", "value": s.active, "status": _pct(s.active, s.total)},
            {"metric": "Inactive", "value": s.inactive, "status": _pct(s.inactive, s.total)},
            {"metric": "Graduated", "value": s.graduated, "status": _pct(s.graduated, s.total)},
            {"metric": "Suspended", "value": s.suspended,
             "status": f"{C.RED}{_pct(s.suspended, s.total)}{C.RESET}" if s.suspended else ""},
            {"metric": "Flagged records", "value": s.flagged,
             "status": f"{C.YELLOW}{_pct(s.flagged, s.total)}{C.RESET}" if s.flagged else "clean"},
            {"metric": "Critical records", "value": s.critical,
             "status": f"{C.RED}{_pct(s.critical, s.total)}{C.RESET}" if s.critical else "none"},
        ]
        print(ui.render_table(kpi_cols, kpi_rows, title="Roster overview"))
        print()

        # Attendance
        att_cols = [
            ui.Column("ATTENDANCE", "metric", 26),
            ui.Column("VALUE", "value", 14, "right"),
            ui.Column("NOTE", "note", 30),
        ]
        att_rows = [
            {"metric": "Average", "value": f"{s.avg_attendance:.2f}%",
             "note": _att_note(s.avg_attendance)},
            {"metric": "Median", "value": f"{s.median_attendance:.2f}%", "note": ""},
            {"metric": "Minimum", "value": f"{s.min_attendance:.2f}%", "note": ""},
            {"metric": "Maximum", "value": f"{s.max_attendance:.2f}%", "note": ""},
            {"metric": "Std deviation", "value": f"{s.attendance_stdev:.2f}",
             "note": "high spread" if s.attendance_stdev > 15 else "consistent"},
            {"metric": f"Below {config.MIN_ATTENDANCE:.0f}%", "value": s.below_attendance_threshold,
             "note": f"{_pct(s.below_attendance_threshold, s.total)} of roster"},
        ]
        print(ui.render_table(att_cols, att_rows, title="Attendance", color=C.BLUE))
        print()

        # Academics
        gpa_rows = [
            {"metric": "Average GPA", "value": f"{s.avg_gpa:.2f}",
             "note": _gpa_note(s.avg_gpa)},
            {"metric": "Median GPA", "value": f"{s.median_gpa:.2f}", "note": ""},
            {"metric": "Minimum", "value": f"{s.min_gpa:.2f}", "note": ""},
            {"metric": "Maximum", "value": f"{s.max_gpa:.2f}", "note": ""},
            {"metric": "Std deviation", "value": f"{s.gpa_stdev:.2f}",
             "note": "high spread" if s.gpa_stdev > 1.5 else "consistent"},
            {"metric": f"Below {config.MIN_GPA:g}", "value": s.below_gpa_threshold,
             "note": f"{_pct(s.below_gpa_threshold, s.total)} of roster"},
        ]
        gpa_cols = [
            ui.Column("ACADEMICS", "metric", 26),
            ui.Column("VALUE", "value", 14, "right"),
            ui.Column("NOTE", "note", 30),
        ]
        print(ui.render_table(gpa_cols, gpa_rows, title="Academics", color=C.MAGENTA))
        print()

        # Distributions side by side
        print(ui.render_table(
            [ui.Column("ATTENDANCE BAND", "band", 22),
             ui.Column("STUDENTS", "n", 10, "right"),
             ui.Column("SHARE", "share", 10, "right")],
            [{"band": b, "n": s.attendance_bands.get(b, 0),
              "share": _pct(s.attendance_bands.get(b, 0), s.total)}
             for b in ("Excellent (90%+)", "Good (75-90%)", "Low (60-75%)", "Critical (<60%)")],
            title="Attendance bands", color=C.BLUE,
        ))
        print()
        print(ui.render_table(
            [ui.Column("GPA BAND", "band", 22),
             ui.Column("STUDENTS", "n", 10, "right"),
             ui.Column("SHARE", "share", 10, "right")],
            [{"band": b, "n": s.gpa_bands.get(b, 0),
              "share": _pct(s.gpa_bands.get(b, 0), s.total)}
             for b in ("Excellent (8.5+)", "Good (7.0-8.5)", "Average (4.0-7.0)",
                       "At risk (2.5-4.0)", "Critical (<2.5)")],
            title="GPA bands", color=C.MAGENTA,
        ))
        print()

        # Fees
        print(ui.render_table(
            [ui.Column("FEE STATUS", "status", 16),
             ui.Column("COUNT", "n", 8, "right"),
             ui.Column("SHARE", "share", 10, "right")],
            [{"status": k, "n": v, "share": _pct(v, s.total)}
             for k, v in (("Paid", s.fee_paid), ("Pending", s.fee_pending),
                          ("Overdue", s.fee_overdue), ("Waived", s.fee_waived))],
            title="Fee status", color=C.GREEN,
        ))
        print()

        # Grade distribution
        print(ui.render_table(
            [ui.Column("GRADE", "grade", 8, "center"),
             ui.Column("STUDENTS", "n", 10, "right"),
             ui.Column("BAR", "bar", 30)],
            [{"grade": g, "n": s.grade_distribution[g],
              "bar": "█" * max(1, int(s.grade_distribution[g] / max(1, max(s.grade_distribution.values())) * 28))}
             for g in sorted(s.grade_distribution, key=lambda x: (len(x), x))],
            title="Grade distribution", color=C.CYAN,
        ))
        print()

        # Trends
        print(ui.section("KEY TRENDS", C.YELLOW))
        for line in analytics.trend_lines(students):
            print(f"  {C.YELLOW}•{C.RESET} {line}")
        print()

        # Top performers
        if s.top_performers:
            print(ui.render_table(
                [ui.Column("ROLL", "roll_no", 10),
                 ui.Column("NAME", "name", 24),
                 ui.Column("GPA", "gpa", 7, "right"),
                 ui.Column("ATT%", "attendance", 8, "right")],
                [{"roll_no": x.roll_no, "name": x.name, "gpa": f"{x.gpa:.2f}",
                  "attendance": f"{x.attendance:.1f}"} for x in s.top_performers],
                title="Top performers", color=C.GREEN,
            ))
            print()

        validation.pause()

    # ------------------------------------------------------------------
    # 9. Warnings
    # ------------------------------------------------------------------
    def warning_register(self) -> None:
        students = self.repo.all()
        ui.clear()
        print(ui.banner())
        print(ui.section("WARNING REGISTER"))
        print()
        if not students:
            print(ui.warn("No records yet."))
            validation.pause()
            return

        warnings = analytics.collect_warnings(students)
        crit = sum(1 for w in warnings if w.severity == "critical")
        warn_n = sum(1 for w in warnings if w.severity == "warning")
        info_n = sum(1 for w in warnings if w.severity == "info")

        print(f"  {ui.badge(f'{crit} critical', 'crit')}  "
              f"{ui.badge(f'{warn_n} warning', 'warn')}  "
              f"{ui.badge(f'{info_n} info', 'info')}")
        print()

        if warnings:
            cols = [
                ui.Column("SEV", "sev", 9),
                ui.Column("ROLL", "roll_no", 10),
                ui.Column("NAME", "name", 20),
                ui.Column("CATEGORY", "category", 13),
                ui.Column("DETAIL", "message", 34),
            ]
            rows = []
            for w in warnings:
                sev = {"critical": f"{C.RED}CRIT{C.RESET}",
                       "warning": f"{C.YELLOW}WARN{C.RESET}",
                       "info": f"{C.CYAN}INFO{C.RESET}"}[w.severity]
                rows.append({"sev": sev, "roll_no": w.roll_no, "name": w.name,
                             "category": w.category, "message": w.message})
            body, page, total = ui.paginate(cols, rows, page=1, page_size=15,
                                            title="Threshold breaches", color=C.RED)
            print(body)
            if total > 1:
                print(f"  {C.GREY}({total} pages - showing page 1){C.RESET}")
        else:
            print(ui.ok("No threshold breaches - every record is within limits."))

        print()
        anomalies = analytics.anomaly_check(students)
        if anomalies:
            print(ui.section("STATISTICAL ANOMALIES", C.MAGENTA))
            for a in anomalies:
                print(f"  {C.MAGENTA}◆{C.RESET} {a}")
        else:
            print(ui.info("No statistical anomalies detected (|z| < 2.5)."))
        print()
        validation.pause()

    # ------------------------------------------------------------------
    # 10. Export
    # ------------------------------------------------------------------
    def export_reports(self) -> None:
        students = self.repo.all()
        ui.clear()
        print(ui.banner())
        print(ui.section("EXPORT REPORTS"))
        print()
        if not students:
            print(ui.warn("No records to export."))
            validation.pause()
            return

        print("  1  Markdown summary (.md)")
        print("  2  Plain-text summary (.txt)")
        print("  3  CSV roster (.csv)")
        print("  4  All three formats")
        print("  0  Back")
        print()
        choice = validation.ask_menu("Choose a format", 0, 4)
        if choice == 0:
            return

        try:
            if choice == 1:
                paths = {"markdown": exporters.export_markdown(students)}
            elif choice == 2:
                paths = {"text": exporters.export_text(students)}
            elif choice == 3:
                paths = {"csv": exporters.export_csv(students)}
            else:
                paths = exporters.export_all(students)
        except OSError as exc:
            print(ui.err(f"Export failed: {exc}"))
            validation.pause()
            return

        print()
        for kind, path in paths.items():
            size = path.stat().st_size if path.exists() else 0
            print(ui.ok(f"{kind:<9} → {path.name}  ({size:,} bytes)"))
        print()
        print(ui.info(f"Files written to {config.EXPORT_DIR}"))
        storage.audit("EXPORT", ",".join(p.name for p in paths.values()))
        validation.pause()

    # ------------------------------------------------------------------
    # 11. Charts
    # ------------------------------------------------------------------
    def generate_charts(self) -> None:
        students = self.repo.all()
        ui.clear()
        print(ui.banner())
        print(ui.section("CHARTS"))
        print()
        if not students:
            print(ui.warn("No records to chart."))
            validation.pause()
            return

        s = analytics.build_summary(students)
        print(charts.ascii_bar_chart("Students per grade", s.grade_distribution))
        print()
        print(charts.ascii_bar_chart("Fee status", s.status_distribution))
        print()

        if charts.HAS_MPL:
            paths = charts.generate_all(students)
            if paths:
                print(ui.ok(f"Saved {len(paths)} PNG chart(s) to {config.EXPORT_DIR}:"))
                for p in paths:
                    print(f"    {C.GREY}·{C.RESET} {p.name}")
            else:
                print(ui.warn("Chart generation produced no files."))
        else:
            print(ui.info("matplotlib is not installed - showing ASCII charts only."))
            print(f"  {C.GREY}Install it with: pip install matplotlib{C.RESET}")
        print()
        validation.pause()

    # ------------------------------------------------------------------
    # 12. Import CSV
    # ------------------------------------------------------------------
    def import_csv(self) -> None:
        ui.clear()
        print(ui.banner())
        print(ui.section("IMPORT LEGACY CSV"))
        print()
        print(f"  {C.GREY}Required columns: roll_no, name. "
              f"Optional: grade, section, email, phone, attendance, gpa, "
              f"fee_status, fee_due_date, status, notes{C.RESET}")
        print(f"  {C.GREY}Default path: {config.CSV_PATH}{C.RESET}")
        print()
        try:
            raw = validation.ask_text("CSV path (Enter for default)", min_len=0,
                                      max_len=200, field="Path", default=str(config.CSV_PATH))
        except Cancelled:
            return

        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = config.BASE_DIR / path
        if not path.exists():
            print(ui.err(f"File not found: {path}"))
            validation.pause()
            return

        students, errors = storage.load_csv(path)
        print()
        print(ui.info(f"Parsed {len(students)} valid row(s), {len(errors)} error(s)."))

        if errors:
            print()
            print(ui.section("ROW-BY-ROW ERROR LOG", C.RED))
            for e in errors[:25]:
                print(f"  {C.RED}row {e['row']:>3}{C.RESET}  {e['reason']}")
            if len(errors) > 25:
                print(f"  {C.GREY}… and {len(errors) - 25} more{C.RESET}")
            print()

        if not students:
            print(ui.warn("Nothing to import."))
            validation.pause()
            return

        if not validation.ask_yes_no(f"Import {len(students)} record(s)?", default="y"):
            print(ui.info("Import cancelled."))
            validation.pause()
            return

        added, skipped = self.repo.bulk_add(students)
        print()
        print(ui.ok(f"Imported {added} record(s)."))
        if skipped:
            print(ui.warn(f"Skipped {len(skipped)} duplicate(s):"))
            for line in skipped[:10]:
                print(f"    {C.GREY}·{C.RESET} {line}")
        validation.pause()


# ==========================================================================
# Small formatting helpers
# ==========================================================================
def _pct(n: int, total: int) -> str:
    if not total:
        return "0%"
    return f"{n / total * 100:.0f}%"


def _att_note(value: float) -> str:
    if value >= 90:
        return f"{C.GREEN}excellent{C.RESET}"
    if value >= config.MIN_ATTENDANCE:
        return f"{C.GREEN}healthy{C.RESET}"
    if value >= config.CRITICAL_ATTENDANCE:
        return f"{C.YELLOW}below target{C.RESET}"
    return f"{C.RED}critical{C.RESET}"


def _gpa_note(value: float) -> str:
    if value >= 8.5:
        return f"{C.GREEN}excellent{C.RESET}"
    if value >= config.MIN_GPA:
        return f"{C.GREEN}healthy{C.RESET}"
    if value >= config.CRITICAL_GPA:
        return f"{C.YELLOW}at risk{C.RESET}"
    return f"{C.RED}critical{C.RESET}"


def main() -> int:
    try:
        App().run()
    except KeyboardInterrupt:
        print("\nInterrupted.")
    return 0
